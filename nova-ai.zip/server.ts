import 'dotenv/config';
import express, { type Request, type Response, type NextFunction } from 'express';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import db, { generateId } from './server/db.ts';
import { isSupportedFile, processUploadedFile } from './server/fileParser.ts';
import {
  buildSystemPrompt,
  clearGroqModelsCache,
  extractChartsFromMarkdown,
  generateImageWithProvider,
  getAvailableModelsAsync,
  getProviderStatuses,
  streamChatResponse,
  testGroqConnection,
  type InputTurn,
} from './server/ai.ts';
import type {
  Attachment,
  ChatMessage,
  Conversation,
  ToolId,
  UserProfile,
  UserSettings,
} from './src/types/nova.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure a stable JWT secret even if JWT_SECRET is not set in env
function resolveJwtSecret(): string {
  if (process.env.JWT_SECRET && process.env.JWT_SECRET !== 'change-this-to-a-secure-random-string') {
    return process.env.JWT_SECRET;
  }
  const secretPath = path.resolve(process.cwd(), 'data', '.jwt_secret');
  if (fs.existsSync(secretPath)) {
    return fs.readFileSync(secretPath, 'utf-8').trim();
  }
  const generated = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(secretPath, generated, { mode: 0o600 });
  return generated;
}

const JWT_SECRET = resolveJwtSecret();
const COOKIE_NAME = 'nova_session';

interface AuthenticatedRequest extends Request {
  user?: UserProfile;
}

interface DbUserRow {
  id: string;
  name: string;
  email: string;
  password_hash: string;
  role: 'user' | 'admin';
  avatar_color: string;
  created_at: string;
}

function mapUser(row: DbUserRow): UserProfile {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
    avatarColor: row.avatar_color,
    createdAt: row.created_at,
  };
}

function signToken(user: UserProfile): string {
  return jwt.sign({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, {
    expiresIn: '14d',
  });
}

function setSessionCookie(req: Request, res: Response, token: string): void {
  const isHttps =
    req.secure || req.headers['x-forwarded-proto'] === 'https' || process.env.NODE_ENV === 'production';
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: isHttps ? 'none' : 'lax',
    secure: isHttps,
    maxAge: 14 * 24 * 60 * 60 * 1000,
    path: '/',
  });
}

function extractToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  const cookieToken = req.cookies?.[COOKIE_NAME];
  return typeof cookieToken === 'string' && cookieToken ? cookieToken : null;
}

function attachUserOptional(req: AuthenticatedRequest, _res: Response, next: NextFunction): void {
  const token = extractToken(req);
  if (!token) {
    next();
    return;
  }
  try {
    const payload = jwt.verify(token, JWT_SECRET) as { sub?: string };
    if (payload.sub) {
      const row = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub) as DbUserRow | undefined;
      if (row) {
        req.user = mapUser(row);
      }
    }
  } catch {
    // Invalid/expired token treated as guest
  }
  next();
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.user) {
    res.status(401).json({ error: 'Authentication required. Please sign in.' });
    return;
  }
  next();
}

function ensureUserSettings(userId: string): UserSettings {
  const row = db.prepare('SELECT * FROM user_settings WHERE user_id = ?').get(userId) as
    | {
        theme: string;
        language: string;
        default_model: string;
        custom_instructions_about: string;
        custom_instructions_style: string;
        memory_enabled: number;
        enter_to_send: number;
        font_size: string;
        voice_lang: string;
        tts_voice: string;
        tts_rate: number;
        tts_auto_play: number;
      }
    | undefined;

  if (!row) {
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO user_settings (user_id, default_model, updated_at) VALUES (?, 'auto', ?)`
    ).run(userId, now);
    return {
      theme: 'system',
      language: 'English',
      defaultModel: 'auto',
      customInstructionsAbout: '',
      customInstructionsStyle: '',
      memoryEnabled: true,
      enterToSend: true,
      fontSize: 'standard',
      voiceLang: 'en-US',
      ttsVoice: '',
      ttsRate: 1.0,
      ttsAutoPlay: false,
    };
  }

  return {
    theme: (row.theme as UserSettings['theme']) || 'system',
    language: row.language || 'English',
    defaultModel: row.default_model || 'auto',
    customInstructionsAbout: row.custom_instructions_about || '',
    customInstructionsStyle: row.custom_instructions_style || '',
    memoryEnabled: row.memory_enabled === 1,
    enterToSend: row.enter_to_send === 1,
    fontSize: (row.font_size as UserSettings['fontSize']) || 'standard',
    voiceLang: row.voice_lang || 'en-US',
    ttsVoice: row.tts_voice || '',
    ttsRate: typeof row.tts_rate === 'number' ? row.tts_rate : 1.0,
    ttsAutoPlay: row.tts_auto_play === 1,
  };
}

const AVATAR_PALETTE = ['#4F46E5', '#6D28D9', '#7C3AED', '#2563EB', '#4338CA', '#5B21B6'];

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '16mb' }));
app.use(cookieParser());
app.use(attachUserOptional);

// Serve static public files (favicon.svg, robots.txt, sitemap.xml)
const publicDir = path.resolve(__dirname, 'public');
if (fs.existsSync(publicDir)) {
  app.use(express.static(publicDir));
}

// Rate limiting
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many authentication attempts. Please try again in a few minutes.' },
});

const chatLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 35,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Rate limit exceeded. Please wait a moment before sending another prompt.' },
});

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 15 * 1024 * 1024, // 15MB
    files: 5,
  },
  fileFilter: (_req, file, cb) => {
    if (isSupportedFile(file.originalname, file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Unsupported file format: ${file.originalname}`));
    }
  },
});

// ==================== HEALTH ====================
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', service: 'nova-ai', timestamp: new Date().toISOString() });
});

// ==================== AUTH ROUTES ====================
app.get('/api/auth/providers', (_req, res) => {
  const googleConfigured = Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
  res.json({
    google: googleConfigured,
  });
});

app.post('/api/auth/signup', authLimiter, async (req, res) => {
  try {
    const name = String(req.body?.name || '').trim();
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');

    if (!name || name.length < 2) {
      res.status(400).json({ error: 'Name must be at least 2 characters.' });
      return;
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: 'Please provide a valid email address.' });
      return;
    }
    if (password.length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters.' });
      return;
    }

    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
    const role = userCount === 0 ? 'admin' : 'user';
    const id = generateId('usr');
    const passwordHash = await bcrypt.hash(password, 10);
    const avatarColor = AVATAR_PALETTE[Math.floor(Math.random() * AVATAR_PALETTE.length)];
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO users (id, name, email, password_hash, role, avatar_color, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(id, name, email, passwordHash, role, avatarColor, now);

    ensureUserSettings(id);

    const user: UserProfile = { id, name, email, role, avatarColor, createdAt: now };
    const token = signToken(user);
    setSessionCookie(req, res, token);

    res.status(201).json({ user, token });
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).json({ error: 'Unable to create account right now.' });
  }
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const password = String(req.body?.password || '');

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as DbUserRow | undefined;
    if (!row || !row.password_hash) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const valid = await bcrypt.compare(password, row.password_hash);
    if (!valid) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const user = mapUser(row);
    const token = signToken(user);
    setSessionCookie(req, res, token);

    res.json({ user, token });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Unable to log in right now.' });
  }
});

app.post('/api/auth/logout', (req, res) => {
  const isHttps =
    req.secure || req.headers['x-forwarded-proto'] === 'https' || process.env.NODE_ENV === 'production';
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    sameSite: isHttps ? 'none' : 'lax',
    secure: isHttps,
    path: '/',
  });
  res.json({ ok: true });
});

app.get('/api/auth/me', (req: AuthenticatedRequest, res) => {
  if (!req.user) {
    res.json({ user: null });
    return;
  }
  res.json({ user: req.user });
});

app.patch('/api/auth/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  const name = String(req.body?.name || '').trim();
  const avatarColor = String(req.body?.avatarColor || '').trim();
  if (!name || name.length < 2) {
    res.status(400).json({ error: 'Display name must be at least 2 characters.' });
    return;
  }
  const colorToUse = /^#[0-9A-Fa-f]{6}$/.test(avatarColor) ? avatarColor : req.user!.avatarColor;
  db.prepare('UPDATE users SET name = ?, avatar_color = ? WHERE id = ?').run(
    name,
    colorToUse,
    req.user!.id
  );
  res.json({
    user: {
      ...req.user!,
      name,
      avatarColor: colorToUse,
    },
  });
});

app.post('/api/auth/change-password', requireAuth, async (req: AuthenticatedRequest, res) => {
  const currentPassword = String(req.body?.currentPassword || '');
  const newPassword = String(req.body?.newPassword || '');
  if (newPassword.length < 8) {
    res.status(400).json({ error: 'New password must be at least 8 characters.' });
    return;
  }
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user!.id) as DbUserRow | undefined;
  if (!row) {
    res.status(404).json({ error: 'Account not found.' });
    return;
  }
  const ok = await bcrypt.compare(currentPassword, row.password_hash);
  if (!ok) {
    res.status(400).json({ error: 'Current password is incorrect.' });
    return;
  }
  const nextHash = await bcrypt.hash(newPassword, 10);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(nextHash, req.user!.id);
  res.json({ ok: true });
});

app.post('/api/auth/forgot-password', authLimiter, (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  if (!email) {
    res.status(400).json({ error: 'Email is required.' });
    return;
  }
  const row = db.prepare('SELECT id FROM users WHERE email = ?').get(email) as { id: string } | undefined;
  if (!row) {
    // Return uniform response without leaking account existence, no fake token
    res.json({
      ok: true,
      message: 'If an account matches that email, a password reset code has been generated.',
    });
    return;
  }
  const resetToken = crypto.randomBytes(4).toString('hex').toUpperCase();
  const expiresAt = Date.now() + 30 * 60 * 1000;
  db.prepare('INSERT INTO password_resets (token, user_id, expires_at, used) VALUES (?, ?, ?, 0)').run(
    resetToken,
    row.id,
    expiresAt
  );
  // In self-hosted/local mode without SMTP configured, return resetCode for direct verification
  res.json({
    ok: true,
    message: 'Reset code generated (valid for 30 minutes).',
    resetCode: resetToken,
  });
});

app.post('/api/auth/reset-password', authLimiter, async (req, res) => {
  const code = String(req.body?.code || '').trim().toUpperCase();
  const newPassword = String(req.body?.newPassword || '');
  if (!code || newPassword.length < 8) {
    res.status(400).json({ error: 'Valid reset code and password (8+ chars) are required.' });
    return;
  }
  const resetRow = db
    .prepare('SELECT * FROM password_resets WHERE token = ? AND used = 0')
    .get(code) as { token: string; user_id: string; expires_at: number; used: number } | undefined;

  if (!resetRow || resetRow.expires_at < Date.now()) {
    res.status(400).json({ error: 'Invalid or expired reset code.' });
    return;
  }

  const hash = await bcrypt.hash(newPassword, 10);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, resetRow.user_id);
  db.prepare('UPDATE password_resets SET used = 1 WHERE token = ?').run(code);
  res.json({ ok: true });
});

app.delete('/api/auth/account', requireAuth, (req: AuthenticatedRequest, res) => {
  db.prepare('DELETE FROM users WHERE id = ?').run(req.user!.id);
  res.clearCookie(COOKIE_NAME, { path: '/' });
  res.json({ ok: true });
});

// Optional Google OAuth endpoint if credentials are configured in env
app.get('/api/auth/google', (req, res) => {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  if (!clientId) {
    res.status(501).json({ error: 'Google OAuth credentials are not configured on the server.' });
    return;
  }
  const baseUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  const redirectUri = `${baseUrl.replace(/\/+$/, '')}/api/auth/google/callback`;
  const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  authUrl.searchParams.set('client_id', clientId);
  authUrl.searchParams.set('redirect_uri', redirectUri);
  authUrl.searchParams.set('response_type', 'code');
  authUrl.searchParams.set('scope', 'openid email profile');
  res.redirect(authUrl.toString());
});

app.get('/api/auth/google/callback', async (req, res) => {
  const code = String(req.query.code || '');
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  if (!code || !clientId || !clientSecret) {
    res.redirect('/?auth_error=google_not_configured');
    return;
  }
  try {
    const baseUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
    const redirectUri = `${baseUrl.replace(/\/+$/, '')}/api/auth/google/callback`;
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
    });
    const tokenJson = (await tokenRes.json()) as { access_token?: string };
    if (!tokenJson.access_token) {
      res.redirect('/?auth_error=google_token_failed');
      return;
    }
    const profileRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${tokenJson.access_token}` },
    });
    const profile = (await profileRes.json()) as { id?: string; email?: string; name?: string };
    if (!profile.email) {
      res.redirect('/?auth_error=google_profile_failed');
      return;
    }

    const email = profile.email.toLowerCase();
    let userRow = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as DbUserRow | undefined;
    if (!userRow) {
      const id = generateId('usr');
      const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
      const role = userCount === 0 ? 'admin' : 'user';
      const now = new Date().toISOString();
      db.prepare(
        `INSERT INTO users (id, name, email, password_hash, role, avatar_color, google_id, created_at)
         VALUES (?, ?, ?, '', ?, ?, ?, ?)`
      ).run(id, profile.name || email.split('@')[0], email, role, '#4F46E5', profile.id || null, now);
      ensureUserSettings(id);
      userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(id) as DbUserRow;
    }
    const user = mapUser(userRow);
    const token = signToken(user);
    setSessionCookie(req, res, token);
    res.redirect(`/?oauth_token=${encodeURIComponent(token)}`);
  } catch {
    res.redirect('/?auth_error=google_callback_error');
  }
});

// ==================== MODELS & ADMIN PROVIDERS ====================
app.get('/api/models', async (_req, res) => {
  const catalog = await getAvailableModelsAsync();
  res.json(catalog);
});

app.get('/api/admin/providers', (_req: AuthenticatedRequest, res) => {
  // Never expose raw secrets; only return masked indicators & non-sensitive metadata
  res.json({ providers: getProviderStatuses() });
});

app.put('/api/admin/providers/:providerId', async (req: AuthenticatedRequest, res) => {
  const providerId = req.params.providerId;
  if (!['groq', 'image'].includes(providerId)) {
    res.status(400).json({ error: 'Only Groq and Image generation providers can be configured here.' });
    return;
  }

  const existing = db
    .prepare('SELECT * FROM provider_configs WHERE provider_id = ?')
    .get(providerId) as { api_key?: string; base_url?: string; enabled?: number; custom_models_json?: string; image_model?: string } | undefined;

  const incomingKey = typeof req.body?.apiKey === 'string' ? req.body.apiKey.trim() : undefined;
  const clearKey = req.body?.clearKey === true;
  const apiKey = clearKey ? null : incomingKey ? incomingKey : existing?.api_key ?? null;
  const baseUrl = typeof req.body?.baseUrl === 'string' ? req.body.baseUrl.trim() : existing?.base_url ?? null;
  const enabled = typeof req.body?.enabled === 'boolean' ? (req.body.enabled ? 1 : 0) : existing?.enabled ?? 1;
  const imageModel =
    typeof req.body?.imageModel === 'string' ? req.body.imageModel.trim() : existing?.image_model ?? null;
  const customModelsJson = Array.isArray(req.body?.customModels)
    ? JSON.stringify(req.body.customModels)
    : existing?.custom_models_json ?? '[]';
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO provider_configs (provider_id, api_key, base_url, enabled, custom_models_json, image_model, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(provider_id) DO UPDATE SET
       api_key = excluded.api_key,
       base_url = excluded.base_url,
       enabled = excluded.enabled,
       custom_models_json = excluded.custom_models_json,
       image_model = excluded.image_model,
       updated_at = excluded.updated_at`
  ).run(providerId, apiKey, baseUrl, enabled, customModelsJson, imageModel, now);

  clearGroqModelsCache();
  const catalog = await getAvailableModelsAsync();
  res.json({ providers: getProviderStatuses(), models: catalog.models, defaultModel: catalog.defaultModel });
});

app.post('/api/admin/providers/groq/test', async (req, res) => {
  const result = await testGroqConnection(req.body?.apiKey, req.body?.baseUrl);
  res.json(result);
});

app.get('/api/usage', (req: AuthenticatedRequest, res) => {
  const userFilter = req.user ? 'WHERE user_id = ?' : '';
  const args = req.user ? [req.user.id] : [];

  const totals = db
    .prepare(
      `SELECT
         COUNT(*) as totalRequests,
         SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successfulRequests,
         SUM(CASE WHEN status != 'success' THEN 1 ELSE 0 END) as failedRequests,
         ROUND(AVG(latency_ms)) as avgLatencyMs
       FROM api_usage ${userFilter}`
    )
    .get(...args) as {
    totalRequests: number;
    successfulRequests: number;
    failedRequests: number;
    avgLatencyMs: number | null;
  };

  const byModel = db
    .prepare(
      `SELECT model, COUNT(*) as count, ROUND(AVG(latency_ms)) as avgLatencyMs
       FROM api_usage ${userFilter}
       GROUP BY model
       ORDER BY count DESC
       LIMIT 10`
    )
    .all(...args) as Array<{ model: string; count: number; avgLatencyMs: number }>;

  const recent = db
    .prepare(
      `SELECT id, provider, model, latency_ms as latencyMs, status, created_at as createdAt
       FROM api_usage ${userFilter}
       ORDER BY created_at DESC
       LIMIT 15`
    )
    .all(...args) as Array<{
    id: string;
    provider: string;
    model: string;
    latencyMs: number;
    status: string;
    createdAt: string;
  }>;

  res.json({
    totalRequests: totals.totalRequests || 0,
    successfulRequests: totals.successfulRequests || 0,
    failedRequests: totals.failedRequests || 0,
    avgLatencyMs: totals.avgLatencyMs || 0,
    byModel,
    recent,
  });
});

// ==================== SETTINGS & MEMORY ====================
app.get('/api/settings', requireAuth, (req: AuthenticatedRequest, res) => {
  res.json({ settings: ensureUserSettings(req.user!.id) });
});

app.put('/api/settings', requireAuth, (req: AuthenticatedRequest, res) => {
  const current = ensureUserSettings(req.user!.id);
  const next: UserSettings = {
    theme: ['light', 'dark', 'system'].includes(req.body?.theme) ? req.body.theme : current.theme,
    language: typeof req.body?.language === 'string' ? req.body.language : current.language,
    defaultModel: typeof req.body?.defaultModel === 'string' ? req.body.defaultModel : current.defaultModel,
    customInstructionsAbout:
      typeof req.body?.customInstructionsAbout === 'string'
        ? req.body.customInstructionsAbout.slice(0, 2000)
        : current.customInstructionsAbout,
    customInstructionsStyle:
      typeof req.body?.customInstructionsStyle === 'string'
        ? req.body.customInstructionsStyle.slice(0, 2000)
        : current.customInstructionsStyle,
    memoryEnabled: typeof req.body?.memoryEnabled === 'boolean' ? req.body.memoryEnabled : current.memoryEnabled,
    enterToSend: typeof req.body?.enterToSend === 'boolean' ? req.body.enterToSend : current.enterToSend,
    fontSize: ['compact', 'standard', 'comfortable'].includes(req.body?.fontSize)
      ? req.body.fontSize
      : current.fontSize,
    voiceLang: typeof req.body?.voiceLang === 'string' ? req.body.voiceLang : current.voiceLang,
    ttsVoice: typeof req.body?.ttsVoice === 'string' ? req.body.ttsVoice : current.ttsVoice,
    ttsRate: typeof req.body?.ttsRate === 'number' ? Math.min(2, Math.max(0.5, req.body.ttsRate)) : current.ttsRate,
    ttsAutoPlay: typeof req.body?.ttsAutoPlay === 'boolean' ? req.body.ttsAutoPlay : current.ttsAutoPlay,
  };

  db.prepare(
    `UPDATE user_settings SET
      theme = ?, language = ?, default_model = ?,
      custom_instructions_about = ?, custom_instructions_style = ?,
      memory_enabled = ?, enter_to_send = ?, font_size = ?,
      voice_lang = ?, tts_voice = ?, tts_rate = ?, tts_auto_play = ?,
      updated_at = ?
     WHERE user_id = ?`
  ).run(
    next.theme,
    next.language,
    next.defaultModel,
    next.customInstructionsAbout,
    next.customInstructionsStyle,
    next.memoryEnabled ? 1 : 0,
    next.enterToSend ? 1 : 0,
    next.fontSize,
    next.voiceLang,
    next.ttsVoice,
    next.ttsRate,
    next.ttsAutoPlay ? 1 : 0,
    new Date().toISOString(),
    req.user!.id
  );

  res.json({ settings: next });
});

app.get('/api/memories', requireAuth, (req: AuthenticatedRequest, res) => {
  const rows = db
    .prepare('SELECT id, content, created_at as createdAt FROM memories WHERE user_id = ? ORDER BY created_at DESC')
    .all(req.user!.id);
  res.json({ memories: rows });
});

app.post('/api/memories', requireAuth, (req: AuthenticatedRequest, res) => {
  const content = String(req.body?.content || '').trim();
  if (!content) {
    res.status(400).json({ error: 'Memory content cannot be empty.' });
    return;
  }
  const id = generateId('mem');
  const createdAt = new Date().toISOString();
  db.prepare('INSERT INTO memories (id, user_id, content, created_at) VALUES (?, ?, ?, ?)').run(
    id,
    req.user!.id,
    content.slice(0, 500),
    createdAt
  );
  res.status(201).json({ memory: { id, content: content.slice(0, 500), createdAt } });
});

app.delete('/api/memories/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  db.prepare('DELETE FROM memories WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
  res.json({ ok: true });
});

// ==================== CONVERSATIONS & MESSAGES ====================
function mapMessageRow(r: Record<string, unknown>): ChatMessage {
  const parseJson = <T,>(raw: unknown): T | undefined => {
    if (typeof raw !== 'string' || !raw) return undefined;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return undefined;
    }
  };
  return {
    id: String(r.id),
    conversationId: String(r.conversation_id),
    role: r.role as ChatMessage['role'],
    content: String(r.content || ''),
    model: typeof r.model === 'string' ? r.model : undefined,
    toolUsed: (r.tool_used as ToolId) || 'none',
    attachments: parseJson(r.attachments_json),
    sources: parseJson(r.sources_json),
    charts: parseJson(r.charts_json),
    generatedImages: parseJson(r.generated_images_json),
    feedback: (r.feedback as 'up' | 'down' | null) ?? null,
    createdAt: String(r.created_at),
  };
}

app.get('/api/conversations', requireAuth, (req: AuthenticatedRequest, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  const rows = db
    .prepare(
      `SELECT id, title, model, pinned, share_id as shareId, created_at as createdAt, updated_at as updatedAt
       FROM conversations
       WHERE user_id = ?
       ORDER BY pinned DESC, updated_at DESC`
    )
    .all(req.user!.id) as Array<Conversation & { pinned: number | boolean }>;

  let list: Conversation[] = rows.map((r) => ({ ...r, pinned: Boolean(r.pinned) }));

  if (q) {
    const matchingMessageConvIds = new Set(
      (
        db
          .prepare(
            `SELECT DISTINCT m.conversation_id
             FROM messages m
             JOIN conversations c ON c.id = m.conversation_id
             WHERE c.user_id = ? AND LOWER(m.content) LIKE ?`
          )
          .all(req.user!.id, `%${q}%`) as Array<{ conversation_id: string }>
      ).map((r) => r.conversation_id)
    );

    list = list.filter((c) => c.title.toLowerCase().includes(q) || matchingMessageConvIds.has(c.id));
  }

  res.json({ conversations: list });
});

app.get('/api/conversations/export', requireAuth, (req: AuthenticatedRequest, res) => {
  const convs = db
    .prepare(
      `SELECT id, title, model, pinned, share_id as shareId, created_at as createdAt, updated_at as updatedAt
       FROM conversations WHERE user_id = ? ORDER BY updated_at DESC`
    )
    .all(req.user!.id) as Array<Conversation & { pinned: number | boolean }>;

  const result = convs.map((c) => {
    const msgs = db
      .prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC')
      .all(c.id) as Record<string, unknown>[];
    return {
      ...c,
      pinned: Boolean(c.pinned),
      messages: msgs.map(mapMessageRow),
    };
  });

  res.json({ exportedAt: new Date().toISOString(), conversations: result });
});

app.post('/api/conversations/import', requireAuth, (req: AuthenticatedRequest, res) => {
  const incoming = Array.isArray(req.body?.conversations) ? req.body.conversations : [];
  let importedCount = 0;

  const insertConv = db.prepare(
    `INSERT OR IGNORE INTO conversations (id, user_id, title, model, pinned, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );
  const insertMsg = db.prepare(
    `INSERT OR IGNORE INTO messages (id, conversation_id, role, content, model, tool_used, attachments_json, sources_json, charts_json, generated_images_json, feedback, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );

  const tx = db.transaction(() => {
    for (const c of incoming) {
      if (!c || typeof c.title !== 'string') continue;
      const convId = generateId('conv');
      const now = new Date().toISOString();
      insertConv.run(
        convId,
        req.user!.id,
        c.title.slice(0, 140),
        c.model || 'gemini-4-hydrogen',
        c.pinned ? 1 : 0,
        c.createdAt || now,
        c.updatedAt || now
      );
      if (Array.isArray(c.messages)) {
        for (const m of c.messages) {
          if (!m || !m.role) continue;
          insertMsg.run(
            generateId('msg'),
            convId,
            m.role,
            String(m.content || ''),
            m.model || null,
            m.toolUsed || 'none',
            m.attachments ? JSON.stringify(m.attachments) : null,
            m.sources ? JSON.stringify(m.sources) : null,
            m.charts ? JSON.stringify(m.charts) : null,
            m.generatedImages ? JSON.stringify(m.generatedImages) : null,
            m.feedback || null,
            m.createdAt || now
          );
        }
      }
      importedCount++;
    }
  });

  tx();
  res.json({ ok: true, importedCount });
});

app.post('/api/conversations', requireAuth, (req: AuthenticatedRequest, res) => {
  const id = generateId('conv');
  const title = String(req.body?.title || 'New Chat').slice(0, 140);
  const model = String(req.body?.model || 'gemini-4-hydrogen');
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO conversations (id, user_id, title, model, pinned, created_at, updated_at)
     VALUES (?, ?, ?, ?, 0, ?, ?)`
  ).run(id, req.user!.id, title, model, now, now);

  res.status(201).json({
    conversation: {
      id,
      title,
      model,
      pinned: false,
      shareId: null,
      createdAt: now,
      updatedAt: now,
      messages: [],
    },
  });
});

app.get('/api/conversations/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const conv = db
    .prepare(
      `SELECT id, title, model, pinned, share_id as shareId, created_at as createdAt, updated_at as updatedAt
       FROM conversations WHERE id = ? AND user_id = ?`
    )
    .get(req.params.id, req.user!.id) as (Conversation & { pinned: number | boolean }) | undefined;

  if (!conv) {
    res.status(404).json({ error: 'Conversation not found.' });
    return;
  }

  const msgs = db
    .prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC')
    .all(conv.id) as Record<string, unknown>[];

  res.json({
    conversation: {
      ...conv,
      pinned: Boolean(conv.pinned),
      messages: msgs.map(mapMessageRow),
    },
  });
});

app.patch('/api/conversations/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const conv = db
    .prepare('SELECT id, title, model, pinned FROM conversations WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user!.id) as
    | { id: string; title: string; model: string; pinned: number }
    | undefined;

  if (!conv) {
    res.status(404).json({ error: 'Conversation not found.' });
    return;
  }

  const title = typeof req.body?.title === 'string' ? req.body.title.trim().slice(0, 140) || conv.title : conv.title;
  const pinned = typeof req.body?.pinned === 'boolean' ? (req.body.pinned ? 1 : 0) : conv.pinned;
  const model = typeof req.body?.model === 'string' ? req.body.model : conv.model;

  db.prepare('UPDATE conversations SET title = ?, pinned = ?, model = ? WHERE id = ? AND user_id = ?').run(
    title,
    pinned,
    model,
    conv.id,
    req.user!.id
  );

  res.json({ ok: true, title, pinned: Boolean(pinned), model });
});

app.delete('/api/conversations/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  db.prepare('DELETE FROM conversations WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
  res.json({ ok: true });
});

app.delete('/api/conversations', requireAuth, (req: AuthenticatedRequest, res) => {
  db.prepare('DELETE FROM conversations WHERE user_id = ?').run(req.user!.id);
  res.json({ ok: true });
});

app.post('/api/conversations/:id/share', requireAuth, (req: AuthenticatedRequest, res) => {
  const conv = db
    .prepare('SELECT id, share_id FROM conversations WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user!.id) as { id: string; share_id: string | null } | undefined;

  if (!conv) {
    res.status(404).json({ error: 'Conversation not found.' });
    return;
  }

  const shareId = conv.share_id || crypto.randomBytes(8).toString('hex');
  if (!conv.share_id) {
    db.prepare('UPDATE conversations SET share_id = ? WHERE id = ?').run(shareId, conv.id);
  }
  res.json({ shareId });
});

app.get('/api/share/:shareId', (req, res) => {
  const conv = db
    .prepare(
      `SELECT id, title, model, created_at as createdAt, updated_at as updatedAt
       FROM conversations WHERE share_id = ?`
    )
    .get(req.params.shareId) as Conversation | undefined;

  if (!conv) {
    res.status(404).json({ error: 'Shared conversation not found.' });
    return;
  }

  const msgs = db
    .prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC')
    .all(conv.id) as Record<string, unknown>[];

  res.json({
    conversation: {
      ...conv,
      pinned: false,
      messages: msgs.map(mapMessageRow),
    },
  });
});

app.patch('/api/messages/:id/feedback', requireAuth, (req: AuthenticatedRequest, res) => {
  const feedback = req.body?.feedback === 'up' || req.body?.feedback === 'down' ? req.body.feedback : null;
  const msg = db
    .prepare(
      `SELECT m.id FROM messages m
       JOIN conversations c ON c.id = m.conversation_id
       WHERE m.id = ? AND c.user_id = ?`
    )
    .get(req.params.id, req.user!.id);

  if (!msg) {
    res.status(404).json({ error: 'Message not found.' });
    return;
  }

  db.prepare('UPDATE messages SET feedback = ? WHERE id = ?').run(feedback, req.params.id);
  res.json({ ok: true, feedback });
});

app.delete('/api/messages/from/:messageId', requireAuth, (req: AuthenticatedRequest, res) => {
  const target = db
    .prepare(
      `SELECT m.id, m.conversation_id, m.created_at FROM messages m
       JOIN conversations c ON c.id = m.conversation_id
       WHERE m.id = ? AND c.user_id = ?`
    )
    .get(req.params.messageId, req.user!.id) as
    | { id: string; conversation_id: string; created_at: string }
    | undefined;

  if (!target) {
    res.status(404).json({ error: 'Message not found.' });
    return;
  }

  const inclusive = req.query.inclusive !== 'false';
  if (inclusive) {
    db.prepare('DELETE FROM messages WHERE conversation_id = ? AND created_at >= ?').run(
      target.conversation_id,
      target.created_at
    );
  } else {
    db.prepare('DELETE FROM messages WHERE conversation_id = ? AND created_at > ?').run(
      target.conversation_id,
      target.created_at
    );
  }
  res.json({ ok: true });
});

// ==================== FILE UPLOADS ====================
app.post('/api/upload', (req, res) => {
  upload.array('files', 5)(req, res, async (err) => {
    if (err) {
      res.status(400).json({ error: err.message || 'File upload failed.' });
      return;
    }
    const files = (req.files as Express.Multer.File[]) || [];
    if (files.length === 0) {
      res.status(400).json({ error: 'No files provided.' });
      return;
    }

    try {
      const attachments: Attachment[] = [];
      for (const f of files) {
        const processed = await processUploadedFile(f);
        attachments.push(processed);
      }
      res.json({ attachments });
    } catch (parseErr) {
      console.error('File parsing error:', parseErr);
      res.status(422).json({
        error: parseErr instanceof Error ? parseErr.message : 'Unable to parse uploaded file.',
      });
    }
  });
});

// ==================== IMAGE GENERATION TOOL ====================
app.post('/api/tools/generate-image', chatLimiter, async (req: AuthenticatedRequest, res) => {
  const prompt = String(req.body?.prompt || '').trim();
  if (!prompt) {
    res.status(400).json({ error: 'Image prompt is required.' });
    return;
  }
  try {
    const result = await generateImageWithProvider(prompt);
    res.json({ image: { url: result.url, prompt, provider: result.provider } });
  } catch (err) {
    const code = (err as Error & { code?: string }).code;
    res.status(code === 'PROVIDER_REQUIRED' ? 412 : 502).json({
      error: err instanceof Error ? err.message : 'Image generation failed.',
      code: code || 'IMAGE_GEN_ERROR',
    });
  }
});

// ==================== CHAT STREAMING (SSE) ====================
app.post('/api/chat/stream', chatLimiter, async (req: AuthenticatedRequest, res) => {
  const startedAt = Date.now();
  const abortController = new AbortController();
  res.on('close', () => {
    if (!res.writableEnded && !res.writableFinished) {
      abortController.abort();
    }
  });

  const conversationId = String(req.body?.conversationId || '').trim();
  const prompt = String(req.body?.prompt || '');
  const modelId = String(req.body?.model || 'gemini-4-hydrogen');
  const tool = (String(req.body?.tool || 'none') as ToolId) || 'none';
  const attachments: Attachment[] = Array.isArray(req.body?.attachments) ? req.body.attachments : [];
  const clientHistory: InputTurn[] = Array.isArray(req.body?.history) ? req.body.history : [];
  const clientSettings = req.body?.settings as Partial<UserSettings> | undefined;
  const clientMemories: string[] = Array.isArray(req.body?.memories) ? req.body.memories : [];
  const replaceFromMessageId =
    typeof req.body?.replaceFromMessageId === 'string' ? req.body.replaceFromMessageId : undefined;

  if (!prompt.trim() && attachments.length === 0) {
    res.status(400).json({ error: 'Message prompt or attachment is required.' });
    return;
  }

  // Setup SSE headers (disable nginx proxy buffering)
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  const sendEvent = (event: string, data: unknown) => {
    if (res.writableEnded) return;
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  let activeConvId = conversationId;
  let userMessageId = generateId('msg');
  const assistantMessageId = generateId('msg');

  try {
    // Load settings & memory
    let settings: Partial<UserSettings> = clientSettings || {};
    let memories: string[] = clientMemories;

    if (req.user) {
      settings = ensureUserSettings(req.user.id);
      if (settings.memoryEnabled) {
        const memRows = db
          .prepare('SELECT content FROM memories WHERE user_id = ? ORDER BY created_at DESC LIMIT 20')
          .all(req.user.id) as Array<{ content: string }>;
        memories = memRows.map((m) => m.content);
      } else {
        memories = [];
      }

      // Ensure conversation exists in DB for authenticated user
      let conv = activeConvId
        ? (db
            .prepare('SELECT id, title FROM conversations WHERE id = ? AND user_id = ?')
            .get(activeConvId, req.user.id) as { id: string; title: string } | undefined)
        : undefined;

      if (!conv) {
        activeConvId = activeConvId || generateId('conv');
        const autoTitle =
          (prompt.trim() || attachments[0]?.name || 'New Chat').replace(/\s+/g, ' ').slice(0, 56) +
          ((prompt.trim().length > 56) ? '…' : '');
        const now = new Date().toISOString();
        db.prepare(
          `INSERT INTO conversations (id, user_id, title, model, pinned, created_at, updated_at)
           VALUES (?, ?, ?, ?, 0, ?, ?)`
        ).run(activeConvId, req.user.id, autoTitle, modelId, now, now);
        conv = { id: activeConvId, title: autoTitle };
        sendEvent('conversation', { id: activeConvId, title: autoTitle, isNew: true });
      } else if (conv.title === 'New Chat' && prompt.trim()) {
        const autoTitle =
          prompt.trim().replace(/\s+/g, ' ').slice(0, 56) + (prompt.trim().length > 56 ? '…' : '');
        db.prepare('UPDATE conversations SET title = ? WHERE id = ?').run(autoTitle, activeConvId);
        sendEvent('conversation', { id: activeConvId, title: autoTitle, isNew: false });
      }

      // If editing or regenerating, prune subsequent messages
      if (replaceFromMessageId) {
        const target = db
          .prepare('SELECT created_at FROM messages WHERE id = ? AND conversation_id = ?')
          .get(replaceFromMessageId, activeConvId) as { created_at: string } | undefined;
        if (target) {
          db.prepare('DELETE FROM messages WHERE conversation_id = ? AND created_at >= ?').run(
            activeConvId,
            target.created_at
          );
        }
      }

      // Persist user message (unless regenerating directly from assistant turn where user message stays)
      const userMsgTimestamp = new Date().toISOString();
      const skipSavingUser = req.body?.regenerate === true;
      if (!skipSavingUser) {
        db.prepare(
          `INSERT INTO messages (id, conversation_id, role, content, model, tool_used, attachments_json, created_at)
           VALUES (?, ?, 'user', ?, ?, ?, ?, ?)`
        ).run(
          userMessageId,
          activeConvId,
          prompt,
          modelId,
          tool,
          attachments.length > 0 ? JSON.stringify(attachments) : null,
          userMsgTimestamp
        );
      }
    }

    // Build full history
    let history: InputTurn[] = [];
    if (req.user && activeConvId) {
      const dbMsgs = db
        .prepare('SELECT role, content, attachments_json FROM messages WHERE conversation_id = ? ORDER BY created_at ASC')
        .all(activeConvId) as Array<{ role: 'user' | 'assistant'; content: string; attachments_json: string | null }>;
      history = dbMsgs.map((m) => ({
        role: m.role,
        content: m.content,
        attachments: m.attachments_json ? (JSON.parse(m.attachments_json) as Attachment[]) : undefined,
      }));
    } else {
      history = [
        ...clientHistory,
        ...(req.body?.regenerate ? [] : [{ role: 'user' as const, content: prompt, attachments }]),
      ];
    }

    const hasDataAttachment = history.some((t) =>
      (t.attachments || []).some((a) => a.kind === 'data')
    );

    const systemPrompt = buildSystemPrompt({
      tool,
      language: settings.language,
      customAbout: settings.customInstructionsAbout,
      customStyle: settings.customInstructionsStyle,
      memories: settings.memoryEnabled === false ? [] : memories,
      hasDataAttachment,
    });

    sendEvent('meta', {
      conversationId: activeConvId,
      userMessageId,
      assistantMessageId,
      model: modelId,
      tool,
    });

    const result = await streamChatResponse({
      modelId,
      tool,
      systemPrompt,
      history,
      signal: abortController.signal,
      callbacks: {
        onToken: (token) => sendEvent('token', { text: token }),
        onSources: (sources) => sendEvent('sources', { sources }),
      },
    });

    const charts = extractChartsFromMarkdown(result.fullText);
    if (charts.length > 0) {
      sendEvent('charts', { charts });
    }

    const now = new Date().toISOString();
    if (req.user && activeConvId && result.fullText.trim()) {
      db.prepare(
        `INSERT INTO messages (id, conversation_id, role, content, model, tool_used, sources_json, charts_json, created_at)
         VALUES (?, ?, 'assistant', ?, ?, ?, ?, ?, ?)`
      ).run(
        assistantMessageId,
        activeConvId,
        result.fullText,
        result.actualModel,
        tool,
        result.sources.length > 0 ? JSON.stringify(result.sources) : null,
        charts.length > 0 ? JSON.stringify(charts) : null,
        now
      );
      db.prepare('UPDATE conversations SET updated_at = ?, model = ? WHERE id = ?').run(
        now,
        result.actualModel,
        activeConvId
      );
    }

    // Record usage telemetry
    db.prepare(
      `INSERT INTO api_usage (id, user_id, provider, model, prompt_chars, response_chars, latency_ms, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      generateId('use'),
      req.user?.id || null,
      result.provider,
      result.actualModel,
      prompt.length,
      result.fullText.length,
      Date.now() - startedAt,
      abortController.signal.aborted ? 'aborted' : 'success',
      now
    );

    sendEvent('done', {
      assistantMessageId,
      actualModel: result.actualModel,
      provider: result.provider,
      charts,
      sources: result.sources,
      aborted: abortController.signal.aborted,
    });
    res.end();
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unable to generate response.';
    db.prepare(
      `INSERT INTO api_usage (id, user_id, provider, model, prompt_chars, response_chars, latency_ms, status, created_at)
       VALUES (?, ?, ?, ?, ?, 0, ?, 'error', ?)`
    ).run(
      generateId('use'),
      req.user?.id || null,
      modelId.startsWith('gemini-') ? 'gemini' : 'groq',
      modelId,
      prompt.length,
      Date.now() - startedAt,
      new Date().toISOString()
    );

    sendEvent('error', { error: message });
    res.end();
  }
});

// ==================== VITE / STATIC SPA ====================
async function startServer() {
  const PORT = Number(process.env.PORT || 3000);

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NOVA AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
