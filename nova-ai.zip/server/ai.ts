import { GoogleGenAI, ThinkingLevel, type Content, type Part } from '@google/genai';
import db from './db.ts';
import type {
  AIModelInfo,
  Attachment,
  ChartSpec,
  GroundingSource,
  ProviderStatus,
  ToolId,
} from '../src/types/nova.ts';

function getGeminiClient(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY?.trim();
  if (!key || key === 'MY_GEMINI_API_KEY') return null;
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

interface ProviderRow {
  provider_id: string;
  api_key: string | null;
  base_url: string | null;
  enabled: number;
  custom_models_json: string | null;
  image_model: string | null;
}

function getProviderRow(providerId: string): ProviderRow | undefined {
  return db
    .prepare('SELECT * FROM provider_configs WHERE provider_id = ?')
    .get(providerId) as ProviderRow | undefined;
}

export function getGroqConfig(): {
  apiKey: string;
  baseUrl: string;
  enabled: boolean;
  source: 'env' | 'database' | 'none';
  customModels: Array<{ id: string; name: string; contextWindow?: string; supportsVision?: boolean }>;
} {
  const row = getProviderRow('groq');
  const dbKey = row?.api_key?.trim() || '';
  const envKey = process.env.GROQ_API_KEY?.trim() || '';
  const apiKey = dbKey || (envKey && envKey !== 'MY_GROQ_API_KEY' ? envKey : '');
  const baseUrl = (row?.base_url?.trim() || process.env.GROQ_BASE_URL?.trim() || 'https://api.groq.com/openai/v1').replace(/\/+$/, '');
  const enabled = row ? row.enabled === 1 : true;
  let customModels: Array<{ id: string; name: string; contextWindow?: string; supportsVision?: boolean }> = [];
  try {
    if (row?.custom_models_json) {
      customModels = JSON.parse(row.custom_models_json);
    }
  } catch {
    customModels = [];
  }
  return {
    apiKey,
    baseUrl,
    enabled,
    source: dbKey ? 'database' : envKey && envKey !== 'MY_GROQ_API_KEY' ? 'env' : 'none',
    customModels,
  };
}

export function getImageProviderConfig(): {
  apiKey: string;
  baseUrl: string;
  model: string;
  enabled: boolean;
  source: 'env' | 'database' | 'none';
} {
  const row = getProviderRow('image');
  const dbKey = row?.api_key?.trim() || '';
  const envKey = process.env.IMAGE_GEN_API_KEY?.trim() || '';
  const apiKey = dbKey || (envKey && envKey !== 'MY_IMAGE_GEN_API_KEY' ? envKey : '');
  const rawBaseUrl = (
    row?.base_url?.trim() ||
    process.env.IMAGE_GEN_ENDPOINT?.trim() ||
    'https://api.openai.com/v1/images/generations'
  ).trim();
  const baseUrl = /^https?:\/\//i.test(rawBaseUrl)
    ? rawBaseUrl
    : 'https://api.openai.com/v1/images/generations';
  const model = row?.image_model?.trim() || process.env.IMAGE_GEN_MODEL?.trim() || 'dall-e-3';
  const enabled = row ? row.enabled === 1 : true;
  return {
    apiKey,
    baseUrl,
    model,
    enabled,
    source: dbKey ? 'database' : envKey ? 'env' : 'none',
  };
}

export function maskSecret(key: string): string | null {
  if (!key) return null;
  if (key.length <= 8) return '••••••••';
  return `${key.slice(0, 4)}••••••${key.slice(-4)}`;
}

export function getProviderStatuses(): ProviderStatus[] {
  const groq = getGroqConfig();
  const image = getImageProviderConfig();
  return [
    {
      providerId: 'groq',
      label: 'Groq Cloud API',
      configured: Boolean(groq.apiKey),
      maskedKey: maskSecret(groq.apiKey),
      baseUrl: groq.baseUrl,
      enabled: groq.enabled,
      source: groq.source,
      customModels: groq.customModels,
    },
    {
      providerId: 'gemini',
      label: 'NOVA Core Engine',
      configured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'),
      maskedKey: process.env.GEMINI_API_KEY ? 'Managed by runtime' : null,
      baseUrl: 'Managed Runtime',
      enabled: true,
      source: process.env.GEMINI_API_KEY ? 'env' : 'none',
      customModels: [],
    },
    {
      providerId: 'image',
      label: 'Image Generation Provider',
      configured: Boolean(image.apiKey),
      maskedKey: maskSecret(image.apiKey),
      baseUrl: image.baseUrl,
      enabled: image.enabled,
      source: image.source,
      customModels: [],
      imageModel: image.model,
    },
  ];
}

interface GroqRemoteModel {
  id: string;
  owned_by?: string;
  active?: boolean;
  context_window?: number;
}

let groqModelsCache: {
  cacheKey: string;
  fetchedAt: number;
  models: GroqRemoteModel[];
} | null = null;

export function clearGroqModelsCache(): void {
  groqModelsCache = null;
}

function formatGroqDisplayName(id: string): string {
  const short = id.includes('/') ? id.split('/').pop()! : id;
  return short
    .split('-')
    .map((part) => {
      if (/^\d+[bmBM]?$/i.test(part) || part === 'it' || part === 'oss' || part === 'r1') {
        return part.toUpperCase();
      }
      return part.charAt(0).toUpperCase() + part.slice(1);
    })
    .join(' ');
}

function isChatCapableGroqModel(id: string): boolean {
  const lower = id.toLowerCase();
  if (
    lower.includes('whisper') ||
    lower.includes('tts') ||
    lower.includes('guard') ||
    lower.includes('safeguard') ||
    lower.includes('orpheus')
  ) {
    return false;
  }
  return true;
}

async function fetchLiveGroqModels(apiKey: string, baseUrl: string): Promise<GroqRemoteModel[]> {
  const cacheKey = `${baseUrl}::${apiKey.slice(-8)}`;
  if (groqModelsCache && groqModelsCache.cacheKey === cacheKey && Date.now() - groqModelsCache.fetchedAt < 60000) {
    return groqModelsCache.models;
  }
  try {
    const res = await fetch(`${baseUrl}/models`, {
      headers: { Authorization: `Bearer ${apiKey}` },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return [];
    const json = (await res.json()) as { data?: GroqRemoteModel[] };
    const list = Array.isArray(json.data)
      ? json.data.filter((m) => m && typeof m.id === 'string' && m.active !== false && isChatCapableGroqModel(m.id))
      : [];
    groqModelsCache = { cacheKey, fetchedAt: Date.now(), models: list };
    return list;
  } catch {
    return [];
  }
}

export async function getAvailableModelsAsync(): Promise<{
  models: AIModelInfo[];
  defaultModel: string;
}> {
  const groq = getGroqConfig();
  const groqReady = Boolean(groq.apiKey) && groq.enabled;
  const geminiReady = Boolean(getGeminiClient());

  const novaModel: AIModelInfo = {
    id: 'gemini-4-hydrogen',
    name: 'NOVA Core',
    provider: 'gemini',
    providerLabel: 'NOVA Engine',
    description: 'Multimodal intelligence with vision, document synthesis, and live web search grounding.',
    contextWindow: '1M ctx',
    supportsVision: true,
    supportsSearch: true,
    available: geminiReady,
  };

  let groqModels: AIModelInfo[] = [];

  if (groqReady) {
    const liveModels = await fetchLiveGroqModels(groq.apiKey, groq.baseUrl);
    if (liveModels.length > 0) {
      groqModels = liveModels.map((m) => {
        const lower = m.id.toLowerCase();
        const supportsVision = lower.includes('vision') || lower.includes('llama-4');
        const ctx = m.context_window
          ? `${Math.round(m.context_window / 1024)}K ctx`
          : '128K ctx';
        return {
          id: m.id,
          name: formatGroqDisplayName(m.id),
          provider: 'groq',
          providerLabel: `Groq${m.owned_by ? ` · ${m.owned_by}` : ''}`,
          description: supportsVision
            ? 'Ultra-fast Groq LPU multimodal model supporting text and vision.'
            : 'Ultra-fast Groq LPU inference for real-time chat, coding, and reasoning.',
          contextWindow: ctx,
          supportsVision,
          supportsSearch: false,
          available: true,
        };
      });
    }
  }

  // Fallback display list when Groq key is not configured yet
  if (groqModels.length === 0) {
    groqModels = [
      {
        id: 'llama-3.3-70b-versatile',
        name: 'Llama 3.3 70B',
        provider: 'groq',
        providerLabel: 'Groq',
        description: 'High-accuracy flagship open model on Groq LPU for reasoning, writing, and complex coding.',
        contextWindow: '128K ctx',
        supportsVision: false,
        supportsSearch: false,
        available: groqReady,
        requiresKey: !groqReady,
      },
      {
        id: 'llama-3.1-8b-instant',
        name: 'Llama 3.1 8B Instant',
        provider: 'groq',
        providerLabel: 'Groq',
        description: 'Ultra-low-latency Groq inference for rapid brainstorming, translation, and quick Q&A.',
        contextWindow: '128K ctx',
        supportsVision: false,
        supportsSearch: false,
        available: groqReady,
        requiresKey: !groqReady,
      },
    ];
  }

  const existingIds = new Set(groqModels.map((m) => m.id));
  const customGroqModels: AIModelInfo[] = groq.customModels
    .filter((m) => !existingIds.has(m.id))
    .map((m) => ({
      id: m.id,
      name: m.name || m.id,
      provider: 'groq',
      providerLabel: 'Groq Custom',
      description: 'Administrator-configured Groq model.',
      contextWindow: m.contextWindow || '128K ctx',
      supportsVision: Boolean(m.supportsVision),
      supportsSearch: false,
      available: groqReady,
      requiresKey: !groqReady,
      isCustom: true,
    }));

  const preferredOrder = [
    'llama-3.3-70b-versatile',
    'meta-llama/llama-4-maverick-17b-128e-instruct',
    'meta-llama/llama-4-scout-17b-16e-instruct',
    'openai/gpt-oss-120b',
    'qwen/qwen3-32b',
    'llama-3.1-8b-instant',
  ];

  const activeGroq = [...groqModels, ...customGroqModels].filter((m) => m.available);
  let defaultModel = 'gemini-4-hydrogen';
  if (activeGroq.length > 0) {
    const preferred = preferredOrder.find((id) => activeGroq.some((m) => m.id === id));
    defaultModel = preferred || activeGroq[0].id;
  }

  return {
    models: [...activeGroq, novaModel, ...groqModels.filter((m) => !m.available), ...customGroqModels.filter((m) => !m.available)],
    defaultModel,
  };
}

export function getAvailableModels(): AIModelInfo[] {
  const groq = getGroqConfig();
  const groqReady = Boolean(groq.apiKey) && groq.enabled;
  const geminiReady = Boolean(getGeminiClient());
  const cachedGroq: AIModelInfo[] =
    groqReady && groqModelsCache
      ? groqModelsCache.models.map((m) => ({
          id: m.id,
          name: formatGroqDisplayName(m.id),
          provider: 'groq',
          providerLabel: 'Groq',
          description: 'Groq LPU inference model.',
          contextWindow: m.context_window ? `${Math.round(m.context_window / 1024)}K ctx` : '128K ctx',
          supportsVision: m.id.toLowerCase().includes('vision') || m.id.toLowerCase().includes('llama-4'),
          supportsSearch: false,
          available: true,
        }))
      : [];

  const customGroqModels: AIModelInfo[] = groq.customModels.map((m) => ({
    id: m.id,
    name: m.name || m.id,
    provider: 'groq',
    providerLabel: 'Groq Custom',
    description: 'Administrator-configured Groq model.',
    contextWindow: m.contextWindow || '128K ctx',
    supportsVision: Boolean(m.supportsVision),
    supportsSearch: false,
    available: groqReady,
    requiresKey: !groqReady,
    isCustom: true,
  }));

  return [
    ...cachedGroq,
    ...customGroqModels,
    {
      id: 'gemini-4-hydrogen',
      name: 'NOVA Core',
      provider: 'gemini',
      providerLabel: 'NOVA Engine',
      description: 'Multimodal intelligence with vision, document synthesis, and live web search grounding.',
      contextWindow: '1M ctx',
      supportsVision: true,
      supportsSearch: true,
      available: geminiReady,
    },
  ];
}

export function buildSystemPrompt(options: {
  tool: ToolId;
  language?: string;
  customAbout?: string;
  customStyle?: string;
  memories?: string[];
  hasDataAttachment?: boolean;
}): string {
  const parts: string[] = [
    'You are NOVA AI, an intelligent, modern, articulate AI assistant.',
    'Respond clearly with well-structured Markdown when helpful (headings, bullet lists, tables, and fenced code blocks with language tags).',
    'Never refer to yourself as ChatGPT or OpenAI. Your identity is NOVA AI.',
  ];

  if (options.language && options.language !== 'English') {
    parts.push(`Respond primarily in ${options.language} unless the user explicitly asks for another language.`);
  }

  if (options.customAbout?.trim()) {
    parts.push(`User profile & background provided by the user:\n${options.customAbout.trim()}`);
  }

  if (options.customStyle?.trim()) {
    parts.push(`User style & formatting preferences:\n${options.customStyle.trim()}`);
  }

  if (options.memories && options.memories.length > 0) {
    parts.push(
      `Persistent user memory facts (use naturally when relevant):\n${options.memories
        .map((m) => `- ${m}`)
        .join('\n')}`
    );
  }

  switch (options.tool) {
    case 'web-search':
      parts.push(
        'Mode: Web Search Research. Provide an accurate, up-to-date synthesis grounded in retrieved search sources. Cite facts clearly and stay factual.'
      );
      break;
    case 'data-analysis':
      parts.push(
        `Mode: Data Analysis. Analyze any attached CSV/tabular data with precision, identifying trends, outliers, and key metrics.
When a visualization would clarify the data, include one or more valid JSON chart specifications inside a fenced code block labeled \`\`\`nova-chart using this exact schema:
{
  "title": "Chart Title",
  "type": "bar" | "line" | "area" | "pie",
  "xKey": "category_field",
  "yKeys": ["numeric_field_1"],
  "data": [{ "category_field": "A", "numeric_field_1": 42 }]
}
Ensure all values in yKeys are numeric and data has at most 20 clean rows.`
      );
      break;
    case 'code-assistant':
      parts.push(
        'Mode: Code Assistant. Provide clean, production-quality, well-typed code with brief architectural explanations, edge-case handling, and syntax-tagged fenced code blocks.'
      );
      break;
    case 'document-assistant':
      parts.push(
        'Mode: Document Assistant. Carefully analyze the attached document text, answer questions strictly grounded in the document contents, quote relevant sections accurately, and flag if something is absent from the file.'
      );
      break;
    default:
      if (options.hasDataAttachment) {
        parts.push(
          `If the user asks for charts or visualization of the attached dataset, you may output a \`\`\`nova-chart JSON block with keys: title, type ("bar"|"line"|"area"|"pie"), xKey, yKeys, data.`
        );
      }
      break;
  }

  return parts.join('\n\n');
}

export function extractChartsFromMarkdown(markdown: string): ChartSpec[] {
  const charts: ChartSpec[] = [];
  const regex = /```nova-chart\s*\n([\s\S]*?)```/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(markdown)) !== null) {
    try {
      const parsed = JSON.parse(match[1].trim());
      if (
        parsed &&
        typeof parsed.title === 'string' &&
        ['bar', 'line', 'area', 'pie'].includes(parsed.type) &&
        typeof parsed.xKey === 'string' &&
        Array.isArray(parsed.yKeys) &&
        Array.isArray(parsed.data) &&
        parsed.data.length > 0
      ) {
        charts.push(parsed as ChartSpec);
      }
    } catch {
      // Ignore malformed chart blocks gracefully
    }
  }
  return charts;
}

export interface StreamCallbacks {
  onToken: (token: string) => void;
  onSources?: (sources: GroundingSource[]) => void;
}

export interface InputTurn {
  role: 'user' | 'assistant';
  content: string;
  attachments?: Attachment[];
}

function formatMessageTextWithAttachments(text: string, attachments?: Attachment[]): string {
  if (!attachments || attachments.length === 0) return text;
  const docSections = attachments
    .filter((a) => a.kind !== 'image' && a.extractedText)
    .map((a) => `[Attached File: ${a.name} (${a.mimeType})]\n${a.extractedText}\n[End of ${a.name}]`);
  if (docSections.length === 0) return text;
  return `${docSections.join('\n\n')}\n\nUser Message:\n${text}`;
}

export async function streamChatResponse(params: {
  modelId: string;
  tool: ToolId;
  systemPrompt: string;
  history: InputTurn[];
  signal: AbortSignal;
  callbacks: StreamCallbacks;
}): Promise<{ fullText: string; sources: GroundingSource[]; actualModel: string; provider: string }> {
  const { models, defaultModel } = await getAvailableModelsAsync();
  const resolvedModelId = !params.modelId || params.modelId === 'auto' ? defaultModel : params.modelId;
  const modelMeta = models.find((m) => m.id === resolvedModelId);
  const provider = modelMeta?.provider || (resolvedModelId.startsWith('gemini-') ? 'gemini' : 'groq');

  // If Web Search tool is requested on a Groq model, or vision image is attached on a non-vision model,
  // check capabilities cleanly.
  const thinkingLevel =
    params.tool === 'code-assistant' ||
    params.tool === 'data-analysis' ||
    params.tool === 'document-assistant'
      ? ThinkingLevel.MEDIUM
      : ThinkingLevel.LOW;

  if (provider === 'groq' && params.tool === 'web-search') {
    if (!getGeminiClient()) {
      throw new Error('Web Search grounding requires NOVA Core (Gemini) engine to be configured.');
    }
    return streamViaGemini({
      modelId: 'gemini-4-hydrogen',
      useSearch: true,
      thinkingLevel: ThinkingLevel.LOW,
      systemPrompt: params.systemPrompt,
      history: params.history,
      signal: params.signal,
      callbacks: params.callbacks,
    });
  }

  if (provider === 'groq') {
    const groq = getGroqConfig();
    if (!groq.apiKey || !groq.enabled) {
      throw new Error(
        'GROQ_KEY_MISSING: Groq API key is not configured. Add GROQ_API_KEY in your environment or Settings → API & Providers, or switch to NOVA Core.'
      );
    }
    return streamViaGroq({
      apiKey: groq.apiKey,
      baseUrl: groq.baseUrl,
      modelId: resolvedModelId,
      supportsVision: Boolean(modelMeta?.supportsVision),
      systemPrompt: params.systemPrompt,
      history: params.history,
      signal: params.signal,
      callbacks: params.callbacks,
    });
  }

  return streamViaGemini({
    modelId: 'gemini-4-hydrogen',
    useSearch: params.tool === 'web-search',
    thinkingLevel,
    systemPrompt: params.systemPrompt,
    history: params.history,
    signal: params.signal,
    callbacks: params.callbacks,
  });
}

async function streamViaGroq(params: {
  apiKey: string;
  baseUrl: string;
  modelId: string;
  supportsVision: boolean;
  systemPrompt: string;
  history: InputTurn[];
  signal: AbortSignal;
  callbacks: StreamCallbacks;
}): Promise<{ fullText: string; sources: GroundingSource[]; actualModel: string; provider: string }> {
  const messages: Array<{ role: string; content: unknown }> = [
    { role: 'system', content: params.systemPrompt },
  ];

  for (const turn of params.history) {
    const textContent = formatMessageTextWithAttachments(turn.content, turn.attachments);
    const images = (turn.attachments || []).filter((a) => a.kind === 'image' && a.dataUrl);
    if (images.length > 0 && params.supportsVision && turn.role === 'user') {
      const contentParts: Array<Record<string, unknown>> = [
        { type: 'text', text: textContent || 'Please analyze the attached image(s).' },
      ];
      for (const img of images) {
        contentParts.push({
          type: 'image_url',
          image_url: { url: img.dataUrl },
        });
      }
      messages.push({ role: turn.role, content: contentParts });
    } else {
      const imageNote =
        images.length > 0 && !params.supportsVision
          ? `\n[Note: User attached ${images.length} image(s). This text-only model cannot view pixels; suggest switching to NOVA Core or Llama 3.2 90B Vision for image inspection.]`
          : '';
      messages.push({ role: turn.role, content: `${textContent}${imageNote}` });
    }
  }

  const response = await fetch(`${params.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${params.apiKey}`,
    },
    body: JSON.stringify({
      model: params.modelId,
      messages,
      stream: true,
      temperature: 0.7,
    }),
    signal: params.signal,
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => '');
    let parsedMsg = `Groq API error (${response.status})`;
    try {
      const parsed = JSON.parse(errText);
      parsedMsg = parsed?.error?.message || parsedMsg;
    } catch {
      if (errText) parsedMsg = `${parsedMsg}: ${errText.slice(0, 240)}`;
    }
    throw new Error(parsedMsg);
  }

  if (!response.body) {
    throw new Error('Groq API did not return a readable stream.');
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let fullText = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line || !line.startsWith('data:')) continue;
      const payload = line.slice(5).trim();
      if (payload === '[DONE]') continue;
      try {
        const json = JSON.parse(payload);
        const delta = json.choices?.[0]?.delta?.content;
        if (typeof delta === 'string' && delta.length > 0) {
          fullText += delta;
          params.callbacks.onToken(delta);
        }
      } catch {
        // Skip incomplete JSON line
      }
    }
  }

  return {
    fullText,
    sources: [],
    actualModel: params.modelId,
    provider: 'groq',
  };
}

function formatApiError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err || 'Unknown AI provider error.');
  try {
    const outer = JSON.parse(raw);
    const innerRaw = outer?.error?.message || outer?.message;
    if (typeof innerRaw === 'string') {
      try {
        const inner = JSON.parse(innerRaw);
        if (inner?.error?.message) return String(inner.error.message);
      } catch {
        return innerRaw;
      }
    }
    if (outer?.error?.message) return String(outer.error.message);
  } catch {
    // not JSON
  }
  return raw;
}

async function streamViaGemini(params: {
  modelId: string;
  useSearch: boolean;
  thinkingLevel: ThinkingLevel;
  systemPrompt: string;
  history: InputTurn[];
  signal: AbortSignal;
  callbacks: StreamCallbacks;
}): Promise<{ fullText: string; sources: GroundingSource[]; actualModel: string; provider: string }> {
  const geminiClient = getGeminiClient();
  if (!geminiClient) {
    throw new Error('NOVA Core engine is not configured on the server.');
  }

  const contents: Content[] = params.history.map((turn) => {
    const parts: Part[] = [];
    const textContent = formatMessageTextWithAttachments(turn.content, turn.attachments);
    if (textContent) {
      parts.push({ text: textContent });
    }
    if (turn.role === 'user' && turn.attachments) {
      for (const att of turn.attachments) {
        if (att.kind === 'image' && att.dataUrl) {
          const commaIdx = att.dataUrl.indexOf(',');
          const b64 = commaIdx >= 0 ? att.dataUrl.slice(commaIdx + 1) : att.dataUrl;
          parts.push({
            inlineData: {
              mimeType: att.mimeType || 'image/png',
              data: b64,
            },
          });
        }
      }
    }
    if (parts.length === 0) {
      parts.push({ text: ' ' });
    }
    return {
      role: turn.role === 'assistant' ? 'model' : 'user',
      parts,
    };
  });

  const maxAttempts = 3;
  let lastError: unknown;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (params.signal.aborted) {
      return { fullText: '', sources: [], actualModel: params.modelId, provider: 'gemini' };
    }

    let fullText = '';
    const sourceMap = new Map<string, GroundingSource>();

    try {
      const stream = await Promise.race([
        geminiClient.models.generateContentStream({
          model: params.modelId,
          contents,
          config: {
            systemInstruction: params.systemPrompt,
            thinkingConfig: { thinkingLevel: params.thinkingLevel },
            ...(params.useSearch ? { tools: [{ googleSearch: {} }] } : {}),
          },
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('NOVA Core request timed out (20s) due to upstream demand. Switch to a Groq model or try again.')), 20000)
        ),
      ]);

      for await (const chunk of stream) {
        if (params.signal.aborted) {
          break;
        }
        const delta = chunk.text;
        if (typeof delta === 'string' && delta.length > 0) {
          fullText += delta;
          params.callbacks.onToken(delta);
        }

        const groundingChunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (Array.isArray(groundingChunks)) {
          for (const gc of groundingChunks) {
            const uri = gc?.web?.uri;
            const title = gc?.web?.title || uri;
            if (uri && !sourceMap.has(uri)) {
              sourceMap.set(uri, { uri, title: title || 'Source' });
            }
          }
        }
      }

      const sources = Array.from(sourceMap.values());
      if (sources.length > 0 && params.callbacks.onSources) {
        params.callbacks.onSources(sources);
      }

      return {
        fullText,
        sources,
        actualModel: params.modelId,
        provider: 'gemini',
      };
    } catch (err) {
      lastError = err;
      const readable = formatApiError(err);
      const isTransient =
        !fullText &&
        (readable.includes('503') ||
          readable.toLowerCase().includes('high demand') ||
          readable.toLowerCase().includes('unavailable'));

      if (isTransient && attempt < maxAttempts - 1 && !params.signal.aborted) {
        await new Promise((r) => setTimeout(r, 700 * Math.pow(2, attempt)));
        continue;
      }
      throw new Error(readable);
    }
  }

  throw new Error(formatApiError(lastError));
}

export async function generateImageWithProvider(prompt: string): Promise<{
  url: string;
  provider: string;
}> {
  const imgCfg = getImageProviderConfig();
  if (!imgCfg.apiKey || !imgCfg.enabled) {
    const err = new Error(
      'Image generation requires a connected image provider key. Configure an OpenAI-compatible or Together AI image endpoint in Settings → API & Providers.'
    ) as Error & { code?: string };
    err.code = 'PROVIDER_REQUIRED';
    throw err;
  }

  const response = await fetch(imgCfg.baseUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${imgCfg.apiKey}`,
    },
    body: JSON.stringify({
      model: imgCfg.model,
      prompt,
      n: 1,
      size: '1024x1024',
      response_format: 'b64_json',
    }),
  });

  if (!response.ok) {
    const txt = await response.text().catch(() => '');
    throw new Error(`Image provider returned HTTP ${response.status}: ${txt.slice(0, 240)}`);
  }

  const data = (await response.json()) as {
    data?: Array<{ b64_json?: string; url?: string }>;
  };
  const first = data?.data?.[0];
  if (first?.b64_json) {
    return {
      url: `data:image/png;base64,${first.b64_json}`,
      provider: imgCfg.model,
    };
  }
  if (first?.url) {
    return {
      url: first.url,
      provider: imgCfg.model,
    };
  }
  throw new Error('Image provider did not return an image payload.');
}

export async function testGroqConnection(overrideKey?: string, overrideBaseUrl?: string): Promise<{
  ok: boolean;
  modelsCount?: number;
  error?: string;
}> {
  const groq = getGroqConfig();
  const key = overrideKey?.trim() || groq.apiKey;
  const baseUrl = (overrideBaseUrl?.trim() || groq.baseUrl).replace(/\/+$/, '');
  if (!key) {
    return { ok: false, error: 'No Groq API key provided.' };
  }
  try {
    const res = await fetch(`${baseUrl}/models`, {
      headers: { Authorization: `Bearer ${key}` },
    });
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      return { ok: false, error: `Groq responded with HTTP ${res.status}: ${body.slice(0, 180)}` };
    }
    const json = (await res.json()) as { data?: unknown[] };
    return { ok: true, modelsCount: Array.isArray(json.data) ? json.data.length : 0 };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Connection failed' };
  }
}
