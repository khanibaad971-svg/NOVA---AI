import path from 'path';
import mammoth from 'mammoth';
import Papa from 'papaparse';
import { extractText } from 'unpdf';
import { generateId } from './db.ts';
import type { Attachment } from '../src/types/nova.ts';

const MAX_EXTRACTED_CHARS = 70000;

const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif']);
const TEXT_EXTENSIONS = new Set([
  '.txt',
  '.md',
  '.markdown',
  '.json',
  '.js',
  '.jsx',
  '.ts',
  '.tsx',
  '.py',
  '.html',
  '.css',
  '.sql',
  '.yaml',
  '.yml',
  '.xml',
  '.log',
  '.env',
]);

export function isSupportedFile(filename: string, mimeType: string): boolean {
  const ext = path.extname(filename).toLowerCase();
  if (IMAGE_EXTENSIONS.has(ext) || mimeType.startsWith('image/')) return true;
  if (ext === '.pdf' || mimeType === 'application/pdf') return true;
  if (
    ext === '.docx' ||
    mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ) {
    return true;
  }
  if (ext === '.csv' || mimeType === 'text/csv') return true;
  if (TEXT_EXTENSIONS.has(ext) || mimeType.startsWith('text/')) return true;
  return false;
}

export async function processUploadedFile(file: {
  originalname: string;
  mimetype: string;
  size: number;
  buffer: Buffer;
}): Promise<Attachment> {
  const ext = path.extname(file.originalname).toLowerCase();
  const id = generateId('att');

  // 1. Images
  if (IMAGE_EXTENSIONS.has(ext) || file.mimetype.startsWith('image/')) {
    const mime = file.mimetype.startsWith('image/') ? file.mimetype : `image/${ext.slice(1) || 'png'}`;
    const base64 = file.buffer.toString('base64');
    return {
      id,
      name: file.originalname,
      mimeType: mime,
      size: file.size,
      kind: 'image',
      dataUrl: `data:${mime};base64,${base64}`,
    };
  }

  // 2. PDF
  if (ext === '.pdf' || file.mimetype === 'application/pdf') {
    const result = await extractText(new Uint8Array(file.buffer), { mergePages: true });
    const rawText = Array.isArray(result.text) ? result.text.join('\n\n') : String(result.text || '');
    const cleaned = rawText.trim().slice(0, MAX_EXTRACTED_CHARS);
    return {
      id,
      name: file.originalname,
      mimeType: 'application/pdf',
      size: file.size,
      kind: 'document',
      pageCount: result.totalPages || undefined,
      extractedText:
        cleaned ||
        '[This PDF did not contain selectable text. It may be a scanned document; please upload page images if visual OCR is needed.]',
    };
  }

  // 3. DOCX
  if (
    ext === '.docx' ||
    file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ) {
    const { value } = await mammoth.extractRawText({ buffer: file.buffer });
    const cleaned = (value || '').trim().slice(0, MAX_EXTRACTED_CHARS);
    return {
      id,
      name: file.originalname,
      mimeType: file.mimetype,
      size: file.size,
      kind: 'document',
      extractedText: cleaned || '[Empty DOCX document]',
    };
  }

  // 4. CSV
  if (ext === '.csv' || file.mimetype === 'text/csv') {
    const text = file.buffer.toString('utf-8');
    const parsed = Papa.parse<Record<string, unknown>>(text, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
    });

    const headers = parsed.meta.fields || [];
    const rows = parsed.data || [];
    const numericStats: Array<{
      column: string;
      min: number;
      max: number;
      mean: number;
      sum: number;
    }> = [];

    for (const col of headers.slice(0, 20)) {
      const nums: number[] = [];
      for (const r of rows) {
        const val = r[col];
        if (typeof val === 'number' && Number.isFinite(val)) {
          nums.push(val);
        }
      }
      if (nums.length > 0) {
        const sum = nums.reduce((a, b) => a + b, 0);
        numericStats.push({
          column: col,
          min: Math.min(...nums),
          max: Math.max(...nums),
          mean: Number((sum / nums.length).toFixed(4)),
          sum: Number(sum.toFixed(4)),
        });
      }
    }

    const sampleRows = rows.slice(0, 50);
    const summaryText = [
      `CSV Dataset: ${file.originalname}`,
      `Columns (${headers.length}): ${headers.join(', ')}`,
      `Total Rows: ${rows.length}`,
      numericStats.length > 0
        ? `Numeric Summary:\n${numericStats
            .map((s) => `- ${s.column}: min=${s.min}, max=${s.max}, mean=${s.mean}, sum=${s.sum}`)
            .join('\n')}`
        : '',
      `Sample Rows (first ${Math.min(rows.length, 40)}):\n${JSON.stringify(rows.slice(0, 40), null, 2)}`,
    ]
      .filter(Boolean)
      .join('\n\n')
      .slice(0, MAX_EXTRACTED_CHARS);

    return {
      id,
      name: file.originalname,
      mimeType: 'text/csv',
      size: file.size,
      kind: 'data',
      extractedText: summaryText,
      csvSummary: {
        headers,
        rowCount: rows.length,
        numericStats,
        sampleRows: sampleRows.slice(0, 20),
      },
    };
  }

  // 5. Plain text / code / JSON
  const text = file.buffer.toString('utf-8').slice(0, MAX_EXTRACTED_CHARS);
  return {
    id,
    name: file.originalname,
    mimeType: file.mimetype || 'text/plain',
    size: file.size,
    kind: 'document',
    extractedText: text || '[Empty text file]',
  };
}
