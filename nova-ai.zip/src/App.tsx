import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  ArrowDown,
  Code2,
  Globe,
  BarChart3,
  BookOpen,
} from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { MessageItem } from './components/MessageItem';
import { Composer } from './components/Composer';
import { NovaMark } from './components/NovaLogo';
import { SettingsModal } from './components/SettingsModal';
import { AuthModal } from './components/AuthModal';
import { ShareModal } from './components/ShareModal';
import { SharedView } from './components/SharedView';
import {
  THEME_STORAGE_KEY,
  loadGuestConversations,
  loadGuestMemories,
  loadGuestSettings,
  novaApi,
  saveGuestConversations,
  saveGuestMemories,
  saveGuestSettings,
  setAuthToken,
  streamChat,
} from './lib/api';
import type {
  AIModelInfo,
  Attachment,
  ChatMessage,
  Conversation,
  MemoryItem,
  ToolId,
  UserProfile,
  UserSettings,
} from './types/nova';

const STARTER_PROMPTS: Array<{
  title: string;
  subtitle: string;
  prompt: string;
  tool: ToolId;
  icon: typeof Code2;
}> = [
  {
    title: 'Debug or architect code',
    subtitle: 'Write clean TypeScript, Python, or SQL with explanations',
    prompt: 'Design a rate-limited token bucket middleware in TypeScript for Express with unit test cases.',
    tool: 'code-assistant',
    icon: Code2,
  },
  {
    title: 'Research the web',
    subtitle: 'Summarize current topics with verifiable source citations',
    prompt: 'Summarize the latest breakthroughs in open-weights reasoning models and list key sources.',
    tool: 'web-search',
    icon: Globe,
  },
  {
    title: 'Analyze data & visualize',
    subtitle: 'Generate interactive charts and statistical summaries',
    prompt:
      'Create a sample quarterly SaaS revenue breakdown by region (North America, Europe, APAC) and visualize it as a bar chart.',
    tool: 'data-analysis',
    icon: BarChart3,
  },
  {
    title: 'Synthesize documents',
    subtitle: 'Extract insights from PDF, DOCX, CSV, or text files',
    prompt: 'Explain how to structure an executive summary from a dense technical report in 5 clear steps.',
    tool: 'document-assistant',
    icon: BookOpen,
  },
];

function createLocalId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export default function App() {
  // Check if viewing a public shared conversation URL (/share/:shareId)
  const [sharedRouteId, setSharedRouteId] = useState<string | null>(() => {
    const m = window.location.pathname.match(/^\/share\/([a-zA-Z0-9_-]+)$/);
    return m ? m[1] : null;
  });

  // Core user & settings state
  const [user, setUser] = useState<UserProfile | null>(null);
  const [settings, setSettings] = useState<UserSettings>(() => loadGuestSettings());
  const [memories, setMemories] = useState<MemoryItem[]>(() => loadGuestMemories());
  const [models, setModels] = useState<AIModelInfo[]>([]);
  const [serverDefaultModel, setServerDefaultModel] = useState<string>('gemini-4-hydrogen');
  const [selectedModel, setSelectedModel] = useState<string>(() => {
    const saved = loadGuestSettings().defaultModel;
    return saved && saved !== 'auto' ? saved : 'gemini-4-hydrogen';
  });
  const [activeTool, setActiveTool] = useState<ToolId>('none');

  // Theme resolution
  const [systemDark, setSystemDark] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.matchMedia('(prefers-color-scheme: dark)').matches : true
  );
  const isDark = settings.theme === 'dark' || (settings.theme === 'system' && systemDark);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    if (isDark) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    try {
      localStorage.setItem(THEME_STORAGE_KEY, settings.theme);
    } catch {}
  }, [isDark, settings.theme]);

  // Layout & modals
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.innerWidth >= 768 : true
  );
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState('general');
  const [authOpen, setAuthOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [renameModalOpen, setRenameModalOpen] = useState(false);
  const [renameDraft, setRenameDraft] = useState('');

  // Conversations & streaming
  const [conversations, setConversations] = useState<Conversation[]>(() => loadGuestConversations());
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  // Scroll behavior
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const stickToBottomRef = useRef(true);

  // Text-to-Speech state
  const [ttsActiveId, setTtsActiveId] = useState<string | null>(null);
  const [ttsPaused, setTtsPaused] = useState(false);

  const activeConversation = useMemo(
    () => conversations.find((c) => c.id === activeConvId) || null,
    [conversations, activeConvId]
  );

  // Bootstrap models & session
  const loadAuthenticatedWorkspace = useCallback(async (fallbackDefault?: string) => {
    try {
      const [convRes, setRes, memRes] = await Promise.all([
        novaApi.listConversations(),
        novaApi.getSettings(),
        novaApi.getMemories(),
      ]);
      setConversations(convRes.conversations);
      setSettings(setRes.settings);
      const dm = setRes.settings.defaultModel;
      if (dm && dm !== 'auto') {
        setSelectedModel(dm);
      } else if (fallbackDefault) {
        setSelectedModel(fallbackDefault);
      }
      setMemories(memRes.memories);
    } catch {
      // ignore if session expired
    }
  }, []);

  useEffect(() => {
    // Handle Google OAuth redirect token if present
    const params = new URLSearchParams(window.location.search);
    const oauthToken = params.get('oauth_token');
    if (oauthToken) {
      setAuthToken(oauthToken);
      window.history.replaceState({}, '', window.location.pathname);
    }

    (async () => {
      let resolvedDefault = 'gemini-4-hydrogen';
      try {
        const res = await novaApi.getModels();
        setModels(res.models);
        resolvedDefault = res.defaultModel || 'gemini-4-hydrogen';
        setServerDefaultModel(resolvedDefault);

        const guestDefault = loadGuestSettings().defaultModel;
        const activeIds = new Set(res.models.filter((m) => m.available).map((m) => m.id));
        // If user uses auto or previously defaulted to gemini-4-hydrogen while a fast Groq default is active
        if (!guestDefault || guestDefault === 'auto' || (guestDefault === 'gemini-4-hydrogen' && resolvedDefault !== 'gemini-4-hydrogen') || !activeIds.has(guestDefault)) {
          setSelectedModel(resolvedDefault);
        }
      } catch {
        // ignore model fetch error
      }

      try {
        const meRes = await novaApi.getMe();
        if (meRes.user) {
          setUser(meRes.user);
          await loadAuthenticatedWorkspace(resolvedDefault);
        }
      } catch {
        // ignore auth check error
      }
    })();
  }, [loadAuthenticatedWorkspace]);

  // Persist guest conversations when unauthenticated
  useEffect(() => {
    if (!user) {
      saveGuestConversations(conversations);
    }
  }, [conversations, user]);

  // Load full messages when selecting a server conversation
  const handleSelectConversation = async (id: string) => {
    setActiveConvId(id);
    const existing = conversations.find((c) => c.id === id);
    if (existing?.model) {
      setSelectedModel(existing.model);
    }
    if (user && (!existing?.messages || existing.messages.length === 0)) {
      try {
        const res = await novaApi.getConversation(id);
        setConversations((prev) =>
          prev.map((c) => (c.id === id ? { ...res.conversation } : c))
        );
        if (res.conversation.model) {
          setSelectedModel(res.conversation.model);
        }
      } catch {
        // ignore fetch error
      }
    }
  };

  // Smart scrolling
  const scrollToBottom = useCallback((smooth = true) => {
    const el = scrollContainerRef.current;
    if (!el) return;
    el.scrollTo({
      top: el.scrollHeight,
      behavior: smooth ? 'smooth' : 'auto',
    });
  }, []);

  const handleScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const nearBottom = distFromBottom < 120;
    stickToBottomRef.current = nearBottom;
    setShowScrollBottom(!nearBottom && el.scrollHeight > el.clientHeight + 200);
  };

  useEffect(() => {
    if (stickToBottomRef.current) {
      scrollToBottom(false);
    }
  }, [activeConversation?.messages?.length, scrollToBottom]);

  // TTS Handlers
  const stopSpeak = useCallback(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setTtsActiveId(null);
    setTtsPaused(false);
  }, []);

  const speakMessage = useCallback(
    (messageId: string, rawText: string) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
      window.speechSynthesis.cancel();

      const plain = rawText
        .replace(/```[\s\S]*?```/g, ' Code block omitted. ')
        .replace(/[#*_`>~]/g, '')
        .trim();

      if (!plain) return;
      const utterance = new SpeechSynthesisUtterance(plain);
      utterance.rate = settings.ttsRate || 1.0;
      if (settings.ttsVoice) {
        const found = window.speechSynthesis.getVoices().find((v) => v.name === settings.ttsVoice);
        if (found) utterance.voice = found;
      }
      utterance.onend = () => {
        setTtsActiveId(null);
        setTtsPaused(false);
      };
      utterance.onerror = () => {
        setTtsActiveId(null);
        setTtsPaused(false);
      };
      setTtsActiveId(messageId);
      setTtsPaused(false);
      window.speechSynthesis.speak(utterance);
    },
    [settings.ttsRate, settings.ttsVoice]
  );

  const pauseResumeSpeak = () => {
    if (!('speechSynthesis' in window)) return;
    if (ttsPaused) {
      window.speechSynthesis.resume();
      setTtsPaused(false);
    } else {
      window.speechSynthesis.pause();
      setTtsPaused(true);
    }
  };

  // Send / Stream Chat Message
  const sendMessage = async (
    prompt: string,
    attachments: Attachment[] = [],
    tool: ToolId = activeTool,
    options?: {
      conversationIdOverride?: string;
      regenerateAssistantId?: string;
      editUserMessageId?: string;
    }
  ) => {
    if (isStreaming) return;
    stopSpeak();

    const now = new Date().toISOString();
    let targetConvId = options?.conversationIdOverride ?? activeConvId;
    const isNewConv = !targetConvId;

    if (!targetConvId) {
      targetConvId = createLocalId('conv');
      const initialTitle =
        (prompt || attachments[0]?.name || 'New Chat').replace(/\s+/g, ' ').slice(0, 56) +
        (prompt.length > 56 ? '…' : '');
      const newConv: Conversation = {
        id: targetConvId,
        title: initialTitle,
        model: selectedModel,
        pinned: false,
        createdAt: now,
        updatedAt: now,
        messages: [],
      };
      setConversations((prev) => [newConv, ...prev]);
      setActiveConvId(targetConvId);
    }

    // Handle Image Generation Tool cleanly
    if (tool === 'image-gen' && !options?.regenerateAssistantId) {
      const userMsg: ChatMessage = {
        id: createLocalId('msg'),
        conversationId: targetConvId,
        role: 'user',
        content: prompt,
        attachments,
        toolUsed: tool,
        createdAt: now,
      };
      const assistantId = createLocalId('msg');
      const placeholder: ChatMessage = {
        id: assistantId,
        conversationId: targetConvId,
        role: 'assistant',
        content: 'Generating image...',
        model: selectedModel,
        toolUsed: tool,
        isStreaming: true,
        createdAt: new Date().toISOString(),
      };

      setConversations((prev) =>
        prev.map((c) =>
          c.id === targetConvId
            ? { ...c, updatedAt: now, messages: [...(c.messages || []), userMsg, placeholder] }
            : c
        )
      );
      setIsStreaming(true);

      try {
        const res = await novaApi.generateImage(prompt);
        setConversations((prev) =>
          prev.map((c) =>
            c.id === targetConvId
              ? {
                  ...c,
                  messages: (c.messages || []).map((m) =>
                    m.id === assistantId
                      ? {
                          ...m,
                          isStreaming: false,
                          content: `Generated image for: *${prompt}*`,
                          generatedImages: [res.image],
                        }
                      : m
                  ),
                }
              : c
          )
        );
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : 'Image generation failed.';
        setConversations((prev) =>
          prev.map((c) =>
            c.id === targetConvId
              ? {
                  ...c,
                  messages: (c.messages || []).map((m) =>
                    m.id === assistantId
                      ? {
                          ...m,
                          isStreaming: false,
                          content: '',
                          error: errMsg,
                        }
                      : m
                  ),
                }
              : c
          )
        );
      } finally {
        setIsStreaming(false);
      }
      return;
    }

    // Prepare history & optimistic UI messages
    const currentConv = conversations.find((c) => c.id === targetConvId);
    let existingMessages = currentConv?.messages || [];
    let replaceFromMessageId: string | undefined;

    if (options?.editUserMessageId) {
      const idx = existingMessages.findIndex((m) => m.id === options.editUserMessageId);
      if (idx >= 0) {
        replaceFromMessageId = existingMessages[idx].id;
        attachments = existingMessages[idx].attachments || [];
        existingMessages = existingMessages.slice(0, idx);
      }
    } else if (options?.regenerateAssistantId) {
      const idx = existingMessages.findIndex((m) => m.id === options.regenerateAssistantId);
      if (idx >= 0) {
        replaceFromMessageId = existingMessages[idx].id;
        existingMessages = existingMessages.slice(0, idx);
      }
    }

    const userMessageId = createLocalId('msg');
    const assistantMessageId = createLocalId('msg');

    const nextMessages: ChatMessage[] = [...existingMessages];
    if (!options?.regenerateAssistantId) {
      nextMessages.push({
        id: userMessageId,
        conversationId: targetConvId,
        role: 'user',
        content: prompt,
        attachments,
        toolUsed: tool,
        createdAt: now,
      });
    }

    nextMessages.push({
      id: assistantMessageId,
      conversationId: targetConvId,
      role: 'assistant',
      content: '',
      model: selectedModel,
      toolUsed: tool,
      isStreaming: true,
      createdAt: new Date().toISOString(),
    });

    setConversations((prev) =>
      prev.map((c) =>
        c.id === targetConvId ? { ...c, updatedAt: now, messages: nextMessages } : c
      )
    );

    stickToBottomRef.current = true;
    setIsStreaming(true);
    const controller = new AbortController();
    abortRef.current = controller;

    const historyForRequest = existingMessages
      .filter((m) => m.role === 'user' || m.role === 'assistant')
      .map((m) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
        attachments: m.attachments,
      }));

    let accumulatedText = '';
    let resolvedConvId = targetConvId;
    let resolvedAssistantId = assistantMessageId;
    let streamSettled = false;

    try {
      await streamChat(
        {
          conversationId: user && isNewConv ? '' : targetConvId,
          prompt,
          model: selectedModel,
          tool,
          attachments,
          history: historyForRequest,
          settings,
          memories: memories.map((m) => m.content),
          regenerate: Boolean(options?.regenerateAssistantId),
          replaceFromMessageId,
        },
        controller.signal,
        {
          onConversation: (serverConv) => {
            const oldId = resolvedConvId;
            resolvedConvId = serverConv.id;
            setActiveConvId(serverConv.id);
            setConversations((prev) =>
              prev.map((c) =>
                c.id === oldId ? { ...c, id: serverConv.id, title: serverConv.title } : c
              )
            );
          },
          onMeta: (meta) => {
            if (meta.conversationId && meta.conversationId !== resolvedConvId) {
              const oldId = resolvedConvId;
              resolvedConvId = meta.conversationId;
              setActiveConvId(meta.conversationId);
              setConversations((prev) =>
                prev.map((c) => (c.id === oldId ? { ...c, id: meta.conversationId } : c))
              );
            }
          },
          onToken: (delta) => {
            accumulatedText += delta;
            setConversations((prev) =>
              prev.map((c) =>
                c.id === resolvedConvId
                  ? {
                      ...c,
                      messages: (c.messages || []).map((m) =>
                        m.id === resolvedAssistantId ? { ...m, content: accumulatedText } : m
                      ),
                    }
                  : c
              )
            );
            if (stickToBottomRef.current) {
              scrollToBottom(false);
            }
          },
          onSources: (sources) => {
            setConversations((prev) =>
              prev.map((c) =>
                c.id === resolvedConvId
                  ? {
                      ...c,
                      messages: (c.messages || []).map((m) =>
                        m.id === resolvedAssistantId ? { ...m, sources } : m
                      ),
                    }
                  : c
              )
            );
          },
          onCharts: (charts) => {
            setConversations((prev) =>
              prev.map((c) =>
                c.id === resolvedConvId
                  ? {
                      ...c,
                      messages: (c.messages || []).map((m) =>
                        m.id === resolvedAssistantId ? { ...m, charts } : m
                      ),
                    }
                  : c
              )
            );
          },
          onDone: (done) => {
            streamSettled = true;
            const finalId = done.assistantMessageId || resolvedAssistantId;
            setConversations((prev) =>
              prev.map((c) =>
                c.id === resolvedConvId
                  ? {
                      ...c,
                      updatedAt: new Date().toISOString(),
                      messages: (c.messages || []).map((m) =>
                        m.id === resolvedAssistantId
                          ? {
                              ...m,
                              id: user && finalId ? finalId : resolvedAssistantId,
                              model: done.actualModel || m.model,
                              isStreaming: false,
                              ...(!accumulatedText && !done.aborted && !m.error
                                ? { error: 'No response was received from the AI provider. Please try again.' }
                                : {}),
                            }
                          : m
                      ),
                    }
                  : c
              )
            );
            if (settings.ttsAutoPlay && accumulatedText && !done.aborted) {
              speakMessage(user && finalId ? finalId : resolvedAssistantId, accumulatedText);
            }
          },
          onError: (errMsg) => {
            streamSettled = true;
            setConversations((prev) =>
              prev.map((c) =>
                c.id === resolvedConvId
                  ? {
                      ...c,
                      messages: (c.messages || []).map((m) =>
                        m.id === resolvedAssistantId
                          ? { ...m, isStreaming: false, error: errMsg }
                          : m
                      ),
                    }
                  : c
              )
            );
          },
        }
      );
    } finally {
      if (!streamSettled) {
        setConversations((prev) =>
          prev.map((c) =>
            c.id === resolvedConvId
              ? {
                  ...c,
                  messages: (c.messages || []).map((m) =>
                    m.id === resolvedAssistantId
                      ? {
                          ...m,
                          isStreaming: false,
                          ...(!accumulatedText && !controller.signal.aborted && !m.error
                            ? { error: 'Connection closed before a response was received. Please try again.' }
                            : {}),
                        }
                      : m
                  ),
                }
              : c
          )
        );
      }
      setIsStreaming(false);
      abortRef.current = null;
    }
  };

  const handleStopGenerating = () => {
    abortRef.current?.abort();
    setIsStreaming(false);
    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConvId
          ? {
              ...c,
              messages: (c.messages || []).map((m) =>
                m.isStreaming ? { ...m, isStreaming: false } : m
              ),
            }
          : c
      )
    );
  };

  const handleRegenerate = (assistantMessageId: string) => {
    if (!activeConversation) return;
    const msgs = activeConversation.messages || [];
    const idx = msgs.findIndex((m) => m.id === assistantMessageId);
    if (idx <= 0) return;
    const prevUser = [...msgs.slice(0, idx)].reverse().find((m) => m.role === 'user');
    if (!prevUser) return;
    sendMessage(prevUser.content, prevUser.attachments || [], prevUser.toolUsed || activeTool, {
      conversationIdOverride: activeConversation.id,
      regenerateAssistantId: assistantMessageId,
    });
  };

  const handleEditUserMessage = (userMessageId: string, newText: string) => {
    if (!activeConversation) return;
    sendMessage(newText, [], activeTool, {
      conversationIdOverride: activeConversation.id,
      editUserMessageId: userMessageId,
    });
  };

  const handleFeedback = async (messageId: string, feedback: 'up' | 'down' | null) => {
    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConvId
          ? {
              ...c,
              messages: (c.messages || []).map((m) =>
                m.id === messageId ? { ...m, feedback } : m
              ),
            }
          : c
      )
    );
    if (user) {
      novaApi.setFeedback(messageId, feedback).catch(() => {});
    }
  };

  const handleRenameConversation = async (id: string, title: string) => {
    setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, title } : c)));
    if (user) {
      await novaApi.updateConversation(id, { title }).catch(() => {});
    }
  };

  const handleTogglePin = async (id: string, pinned: boolean) => {
    setConversations((prev) => {
      const next = prev.map((c) => (c.id === id ? { ...c, pinned } : c));
      return next.sort((a, b) => Number(b.pinned) - Number(a.pinned));
    });
    if (user) {
      await novaApi.updateConversation(id, { pinned }).catch(() => {});
    }
  };

  const handleDeleteConversation = async (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeConvId === id) setActiveConvId(null);
    if (user) {
      await novaApi.deleteConversation(id).catch(() => {});
    }
  };

  const handleExportMarkdown = (conv: Conversation | null) => {
    if (!conv) return;
    const md = (conv.messages || [])
      .map((m) => `### ${m.role === 'user' ? 'User' : 'NOVA AI'}\n\n${m.content}`)
      .join('\n\n---\n\n');
    const blob = new Blob([`# ${conv.title}\n\n${md}`], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${conv.title.replace(/[^a-z0-9-_]+/gi, '_').toLowerCase()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSaveSettings = async (next: UserSettings) => {
    setSettings(next);
    if (user) {
      const res = await novaApi.saveSettings(next);
      setSettings(res.settings);
    } else {
      saveGuestSettings(next);
    }
  };

  const handleAddMemory = async (content: string) => {
    if (user) {
      const res = await novaApi.addMemory(content);
      setMemories((prev) => [res.memory, ...prev]);
    } else {
      const item: MemoryItem = {
        id: createLocalId('mem'),
        content,
        createdAt: new Date().toISOString(),
      };
      const next = [item, ...memories];
      setMemories(next);
      saveGuestMemories(next);
    }
  };

  const handleDeleteMemory = async (id: string) => {
    const next = memories.filter((m) => m.id !== id);
    setMemories(next);
    if (user) {
      await novaApi.deleteMemory(id).catch(() => {});
    } else {
      saveGuestMemories(next);
    }
  };

  const handleAuthenticated = async (loggedInUser: UserProfile) => {
    setUser(loggedInUser);
    // Sync any guest conversations created before login
    const guestConvs = loadGuestConversations();
    if (guestConvs.length > 0) {
      await novaApi.importConversations(guestConvs).catch(() => {});
      saveGuestConversations([]);
    }
    await loadAuthenticatedWorkspace(serverDefaultModel);
    setActiveConvId(null);
  };

  const handleUserUpdated = (nextUser: UserProfile | null) => {
    setUser(nextUser);
    if (!nextUser) {
      setAuthToken(null);
      setConversations(loadGuestConversations());
      const guestSettings = loadGuestSettings();
      setSettings(guestSettings);
      setSelectedModel(
        guestSettings.defaultModel && guestSettings.defaultModel !== 'auto'
          ? guestSettings.defaultModel
          : serverDefaultModel
      );
      setMemories(loadGuestMemories());
      setActiveConvId(null);
    }
  };

  const cycleTheme = () => {
    const order: UserSettings['theme'][] = ['light', 'dark', 'system'];
    const idx = order.indexOf(settings.theme);
    const next = order[(idx + 1) % order.length];
    handleSaveSettings({ ...settings, theme: next });
  };

  // Public shared conversation view
  if (sharedRouteId) {
    return (
      <SharedView
        shareId={sharedRouteId}
        isDark={isDark}
        onBackToApp={() => {
          window.history.pushState({}, '', '/');
          setSharedRouteId(null);
        }}
      />
    );
  }

  const messages = activeConversation?.messages || [];
  const isWelcomeScreen = !activeConversation || messages.length === 0;

  return (
    <div className="h-screen w-full flex overflow-hidden bg-[#FCFCFD] dark:bg-[#0B0D13] text-slate-900 dark:text-slate-100 transition-colors duration-150">
      <Sidebar
        open={sidebarOpen}
        onCloseMobile={() => setSidebarOpen(false)}
        onCollapseDesktop={() => setSidebarOpen(false)}
        conversations={conversations}
        activeId={activeConvId}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSelectConversation={handleSelectConversation}
        onNewChat={() => {
          setActiveConvId(null);
          setActiveTool('none');
          stopSpeak();
        }}
        onRenameConversation={handleRenameConversation}
        onTogglePin={handleTogglePin}
        onDeleteConversation={handleDeleteConversation}
        onShareConversation={(id) => {
          setActiveConvId(id);
          setShareOpen(true);
        }}
        user={user}
        onOpenSettings={() => {
          setSettingsTab('general');
          setSettingsOpen(true);
        }}
        onOpenAuth={() => setAuthOpen(true)}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 h-full relative bg-white dark:bg-[#0F111A]">
        <TopBar
          sidebarOpen={sidebarOpen}
          onToggleSidebar={() => setSidebarOpen((o) => !o)}
          models={models}
          selectedModel={selectedModel}
          onSelectModel={(mId) => {
            setSelectedModel(mId);
            if (activeConversation) {
              setConversations((prev) =>
                prev.map((c) => (c.id === activeConversation.id ? { ...c, model: mId } : c))
              );
              if (user) {
                novaApi.updateConversation(activeConversation.id, { model: mId }).catch(() => {});
              }
            }
          }}
          activeConversation={activeConversation}
          onNewChat={() => {
            setActiveConvId(null);
            setActiveTool('none');
            stopSpeak();
          }}
          onShare={() => setShareOpen(true)}
          onTogglePin={() => {
            if (activeConversation) {
              handleTogglePin(activeConversation.id, !activeConversation.pinned);
            }
          }}
          onRenamePrompt={() => {
            if (!activeConversation) return;
            setRenameDraft(activeConversation.title);
            setRenameModalOpen(true);
          }}
          onExportMarkdown={() => handleExportMarkdown(activeConversation)}
          onDeleteConversation={() => {
            if (activeConversation) handleDeleteConversation(activeConversation.id);
          }}
          theme={settings.theme}
          onCycleTheme={cycleTheme}
          onOpenSettings={(tabName) => {
            setSettingsTab(tabName || 'general');
            setSettingsOpen(true);
          }}
        />

        {isWelcomeScreen ? (
          /* Welcome Screen with Centered Composer */
          <main className="flex-1 overflow-y-auto flex flex-col items-center justify-center px-4 py-8">
            <div className="w-full max-w-3xl mx-auto flex flex-col items-center text-center space-y-6">
              <div className="flex flex-col items-center gap-3">
                <NovaMark size={44} />
                <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white text-balance">
                  How can NOVA AI help you today?
                </h1>
              </div>

              <div className="w-full">
                <Composer
                  onSend={(t, atts, tool) => sendMessage(t, atts, tool)}
                  onStop={handleStopGenerating}
                  isStreaming={isStreaming}
                  activeTool={activeTool}
                  onSelectTool={setActiveTool}
                  enterToSend={settings.enterToSend}
                  voiceLang={settings.voiceLang}
                  centered
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full pt-2 text-left">
                {STARTER_PROMPTS.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.title}
                      type="button"
                      onClick={() => sendMessage(item.prompt, [], item.tool)}
                      className="group flex items-start gap-3 p-3.5 rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-[#FCFCFD] dark:bg-[#141724] hover:border-indigo-400 dark:hover:border-indigo-500/60 hover:bg-indigo-50/40 dark:hover:bg-[#191E30] transition-colors"
                    >
                      <Icon className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                          {item.title}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                          {item.subtitle}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </main>
        ) : (
          /* Active Conversation Area */
          <>
            <div
              ref={scrollContainerRef}
              onScroll={handleScroll}
              className="flex-1 overflow-y-auto px-3 sm:px-6 pt-4 pb-6"
            >
              <div className="max-w-3xl mx-auto divide-y divide-transparent">
                {messages.map((msg) => (
                  <MessageItem
                    key={msg.id}
                    message={msg}
                    isDark={isDark}
                    fontSize={settings.fontSize}
                    isStreamingGlobal={isStreaming}
                    ttsActiveId={ttsActiveId}
                    ttsPaused={ttsPaused}
                    onCopy={(text) => navigator.clipboard.writeText(text)}
                    onRegenerate={handleRegenerate}
                    onEditUserMessage={handleEditUserMessage}
                    onFeedback={handleFeedback}
                    onSpeak={speakMessage}
                    onPauseResumeSpeak={pauseResumeSpeak}
                    onStopSpeak={stopSpeak}
                    onOpenProviderSettings={() => {
                      setSettingsTab('providers');
                      setSettingsOpen(true);
                    }}
                  />
                ))}
              </div>
            </div>

            {showScrollBottom && (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    stickToBottomRef.current = true;
                    scrollToBottom(true);
                  }}
                  className="absolute left-1/2 -translate-x-1/2 -top-12 z-10 w-9 h-9 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] shadow-md flex items-center justify-center text-slate-600 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                  aria-label="Scroll to latest message"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
              </div>
            )}

            <Composer
              onSend={(t, atts, tool) => sendMessage(t, atts, tool)}
              onStop={handleStopGenerating}
              isStreaming={isStreaming}
              activeTool={activeTool}
              onSelectTool={setActiveTool}
              enterToSend={settings.enterToSend}
              voiceLang={settings.voiceLang}
            />
          </>
        )}
      </div>

      {/* Modals */}
      <SettingsModal
        open={settingsOpen}
        initialTab={settingsTab}
        onClose={() => setSettingsOpen(false)}
        user={user}
        onUserUpdated={handleUserUpdated}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        memories={memories}
        onAddMemory={handleAddMemory}
        onDeleteMemory={handleDeleteMemory}
        models={models}
        onModelsUpdated={setModels}
        conversations={conversations}
        onImportConversations={async (convs) => {
          if (user) {
            await novaApi.importConversations(convs);
            await loadAuthenticatedWorkspace();
          } else {
            setConversations((prev) => [...convs, ...prev]);
          }
        }}
        onClearAllConversations={async () => {
          setConversations([]);
          setActiveConvId(null);
          if (user) {
            await novaApi.clearConversations();
          } else {
            saveGuestConversations([]);
          }
        }}
        onOpenAuth={() => setAuthOpen(true)}
      />

      <AuthModal
        open={authOpen}
        onClose={() => setAuthOpen(false)}
        onAuthenticated={handleAuthenticated}
      />

      <ShareModal
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        conversation={activeConversation}
        isAuthenticated={Boolean(user)}
        onExportMarkdown={() => handleExportMarkdown(activeConversation)}
      />

      {renameModalOpen && activeConversation && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-[2px] flex items-center justify-center p-4"
          onClick={() => setRenameModalOpen(false)}
        >
          <form
            onClick={(e) => e.stopPropagation()}
            onSubmit={(e) => {
              e.preventDefault();
              if (renameDraft.trim()) {
                handleRenameConversation(activeConversation.id, renameDraft.trim());
                setRenameModalOpen(false);
              }
            }}
            className="w-full max-w-sm rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#141724] shadow-2xl p-5 space-y-4"
          >
            <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Rename Conversation
            </h3>
            <input
              type="text"
              autoFocus
              value={renameDraft}
              onChange={(e) => setRenameDraft(e.target.value)}
              className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] px-3.5 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setRenameModalOpen(false)}
                className="px-3.5 py-1.5 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
              >
                Save
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
