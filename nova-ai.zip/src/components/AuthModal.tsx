import { useState, useEffect } from 'react';
import { X, Loader2, ArrowLeft } from 'lucide-react';
import { NovaLogo } from './NovaLogo';
import { novaApi, setAuthToken } from '../lib/api';
import type { UserProfile } from '../types/nova';

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  onAuthenticated: (user: UserProfile) => void;
}

type AuthMode = 'login' | 'signup' | 'forgot' | 'reset';

export function AuthModal({ open, onClose, onAuthenticated }: AuthModalProps) {
  const [mode, setMode] = useState<AuthMode>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [generatedCodeHint, setGeneratedCodeHint] = useState<string | null>(null);
  const [googleAvailable, setGoogleAvailable] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setError(null);
      setInfo(null);
      novaApi
        .getAuthProviders()
        .then((res) => setGoogleAvailable(res.google))
        .catch(() => {});
    }
  }, [open]);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);
    try {
      if (mode === 'login') {
        const res = await novaApi.login(email, password);
        setAuthToken(res.token);
        onAuthenticated(res.user);
        onClose();
      } else if (mode === 'signup') {
        const res = await novaApi.signup(name, email, password);
        setAuthToken(res.token);
        onAuthenticated(res.user);
        onClose();
      } else if (mode === 'forgot') {
        const res = await novaApi.forgotPassword(email);
        setInfo(res.message);
        if (res.resetCode) {
          setGeneratedCodeHint(res.resetCode);
          setResetCode(res.resetCode);
        }
        setMode('reset');
      } else if (mode === 'reset') {
        await novaApi.resetPassword(resetCode, password);
        setInfo('Password updated. You can now sign in with your new password.');
        setPassword('');
        setMode('login');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-[2px] flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#141724] shadow-2xl p-6 space-y-5"
      >
        <div className="flex items-center justify-between">
          <NovaLogo size={26} />
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div>
          <h2 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">
            {mode === 'login'
              ? 'Welcome back'
              : mode === 'signup'
                ? 'Create your NOVA AI account'
                : mode === 'forgot'
                  ? 'Reset your password'
                  : 'Enter reset code'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {mode === 'login'
              ? 'Sign in to access your synced chat history, memory, and settings.'
              : mode === 'signup'
                ? 'Save conversations securely and sync across devices.'
                : mode === 'forgot'
                  ? 'Enter your account email to generate a password reset code.'
                  : 'Use your reset code and choose a new password.'}
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-xs text-rose-700 dark:text-rose-200">
            {error}
          </div>
        )}

        {info && (
          <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 text-xs text-indigo-700 dark:text-indigo-200 space-y-1">
            <div>{info}</div>
            {generatedCodeHint && (
              <div className="font-mono font-semibold">
                Reset Code: {generatedCodeHint}
              </div>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === 'signup' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Alex Rivera"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          )}

          {(mode === 'login' || mode === 'signup' || mode === 'forgot') && (
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          )}

          {mode === 'reset' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Reset Code
              </label>
              <input
                type="text"
                required
                value={resetCode}
                onChange={(e) => setResetCode(e.target.value)}
                placeholder="8-character code"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] px-3.5 py-2.5 text-sm font-mono uppercase text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          )}

          {(mode === 'login' || mode === 'signup' || mode === 'reset') && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                  {mode === 'reset' ? 'New Password' : 'Password'}
                </label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => {
                      setError(null);
                      setInfo(null);
                      setMode('forgot');
                    }}
                    className="text-[11px] font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <input
                type="password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 8 characters"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] px-3.5 py-2.5 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#5B21B6] hover:bg-[#4C1D95] dark:bg-[#7C3AED] dark:hover:bg-[#6D28D9] text-white text-sm font-semibold transition-colors disabled:opacity-60"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>
              {mode === 'login'
                ? 'Sign in'
                : mode === 'signup'
                  ? 'Create account'
                  : mode === 'forgot'
                    ? 'Generate reset code'
                    : 'Reset password'}
            </span>
          </button>
        </form>

        {googleAvailable && (mode === 'login' || mode === 'signup') && (
          <>
            <div className="relative flex items-center py-1">
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800" />
              <span className="shrink mx-3 text-[11px] text-slate-400">or</span>
              <div className="flex-grow border-t border-slate-200 dark:border-slate-800" />
            </div>
            <a
              href="/api/auth/google"
              className="w-full flex items-center justify-center gap-2.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-[#1A1E2E] text-xs font-semibold text-slate-800 dark:text-slate-100 transition-colors"
            >
              Continue with Google
            </a>
          </>
        )}

        <div className="pt-2 text-center text-xs text-slate-500 dark:text-slate-400">
          {mode === 'login' ? (
            <>
              Don&apos;t have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setMode('signup');
                }}
                className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Sign up
              </button>
            </>
          ) : mode === 'signup' ? (
            <>
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setMode('login');
                }}
                className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Sign in
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => {
                setError(null);
                setMode('login');
              }}
              className="inline-flex items-center gap-1 font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back to sign in
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
