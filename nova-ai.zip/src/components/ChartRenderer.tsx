import { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { BarChart3, Table2 } from 'lucide-react';
import type { ChartSpec } from '../types/nova';

const CHART_COLORS = ['#6366F1', '#8B5CF6', '#3B82F6', '#0EA5E9', '#A855F7', '#4338CA'];

export function ChartRenderer({ spec }: { spec: ChartSpec }) {
  const [viewMode, setViewMode] = useState<'chart' | 'table'>('chart');

  return (
    <div className="my-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#141824] overflow-hidden">
      <div className="flex items-center justify-between gap-3 px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#181D2B]">
        <div className="flex items-center gap-2 min-w-0">
          <BarChart3 className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
          <span className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
            {spec.title}
          </span>
        </div>
        <div className="flex items-center gap-1 p-0.5 rounded-lg bg-slate-200/70 dark:bg-slate-800/80 shrink-0">
          <button
            type="button"
            onClick={() => setViewMode('chart')}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              viewMode === 'chart'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Chart
          </button>
          <button
            type="button"
            onClick={() => setViewMode('table')}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
              viewMode === 'table'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Table2 className="w-3 h-3" />
            Table
          </button>
        </div>
      </div>

      {viewMode === 'chart' ? (
        <div className="h-72 w-full p-4">
          <ResponsiveContainer width="100%" height="100%">
            {spec.type === 'bar' ? (
              <BarChart data={spec.data} margin={{ top: 8, right: 16, left: 0, bottom: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                <XAxis dataKey={spec.xKey} tick={{ fontSize: 12, fill: '#94A3B8' }} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#131622',
                    border: '1px solid rgba(148,163,184,0.2)',
                    borderRadius: '10px',
                    color: '#F1F5F9',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                {spec.yKeys.map((key, idx) => (
                  <Bar
                    key={key}
                    dataKey={key}
                    fill={CHART_COLORS[idx % CHART_COLORS.length]}
                    radius={[6, 6, 0, 0]}
                  />
                ))}
              </BarChart>
            ) : spec.type === 'line' ? (
              <LineChart data={spec.data} margin={{ top: 8, right: 16, left: 0, bottom: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                <XAxis dataKey={spec.xKey} tick={{ fontSize: 12, fill: '#94A3B8' }} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#131622',
                    border: '1px solid rgba(148,163,184,0.2)',
                    borderRadius: '10px',
                    color: '#F1F5F9',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                {spec.yKeys.map((key, idx) => (
                  <Line
                    key={key}
                    type="monotone"
                    dataKey={key}
                    stroke={CHART_COLORS[idx % CHART_COLORS.length]}
                    strokeWidth={2.5}
                    dot={{ r: 3 }}
                  />
                ))}
              </LineChart>
            ) : spec.type === 'area' ? (
              <AreaChart data={spec.data} margin={{ top: 8, right: 16, left: 0, bottom: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                <XAxis dataKey={spec.xKey} tick={{ fontSize: 12, fill: '#94A3B8' }} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#131622',
                    border: '1px solid rgba(148,163,184,0.2)',
                    borderRadius: '10px',
                    color: '#F1F5F9',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                {spec.yKeys.map((key, idx) => (
                  <Area
                    key={key}
                    type="monotone"
                    dataKey={key}
                    stroke={CHART_COLORS[idx % CHART_COLORS.length]}
                    fill={CHART_COLORS[idx % CHART_COLORS.length]}
                    fillOpacity={0.2}
                    strokeWidth={2}
                  />
                ))}
              </AreaChart>
            ) : (
              <PieChart>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#131622',
                    border: '1px solid rgba(148,163,184,0.2)',
                    borderRadius: '10px',
                    color: '#F1F5F9',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Pie
                  data={spec.data}
                  dataKey={spec.yKeys[0]}
                  nameKey={spec.xKey}
                  cx="50%"
                  cy="50%"
                  outerRadius={92}
                  label
                >
                  {spec.data.map((_entry, idx) => (
                    <Cell key={idx} fill={CHART_COLORS[idx % CHART_COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            )}
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="max-h-72 overflow-auto">
          <table className="w-full text-xs tabular-nums">
            <thead className="bg-slate-50 dark:bg-[#181D2B] text-slate-600 dark:text-slate-300 sticky top-0">
              <tr>
                <th className="px-4 py-2 text-left font-medium">{spec.xKey}</th>
                {spec.yKeys.map((yk) => (
                  <th key={yk} className="px-4 py-2 text-right font-medium">
                    {yk}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/70 dark:divide-slate-800/70">
              {spec.data.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                  <td className="px-4 py-2 text-slate-800 dark:text-slate-200">
                    {String(row[spec.xKey] ?? '')}
                  </td>
                  {spec.yKeys.map((yk) => (
                    <td key={yk} className="px-4 py-2 text-right font-mono text-slate-700 dark:text-slate-300">
                      {String(row[yk] ?? '')}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
