import { useState, useRef, useEffect } from 'react';
import {
  Plus,
  Image as ImageIcon,
  FileText,
  Mic,
  MicOff,
  ArrowUp,
  Square,
  Globe,
  Wand2,
  BarChart3,
  Code2,
  BookOpen,
  X,
  Wrench,
  Loader2,
  Table2,
} from 'lucide-react';
import { novaApi } from '../lib/api';
import type { Attachment, ToolId } from '../types/nova';

interface ComposerProps {
  onSend: (text: string, attachments: Attachment[], tool: ToolId) => void;
  onStop: () => void;
  isStreaming: boolean;
  activeTool: ToolId;
  onSelectTool: (tool: ToolId) => void;
  enterToSend: boolean;
  voiceLang: string;
  centered?: boolean;
}

const TOOL_OPTIONS: Array<{
  id: ToolId;
  label: string;
  description: string;
  icon: typeof Globe;
}> = [
  {
    id: 'web-search',
    label: 'Web Search',
    description: 'Search the web and cite live sources',
    icon: Globe,
  },
  {
    id: 'image-gen',
    label: 'Image Generation',
    description: 'Generate visuals via connected image provider',
    icon: Wand2,
  },
  {
    id: 'data-analysis',
    label: 'Data Analysis',
    description: 'Analyze CSV datasets & render charts',
    icon: BarChart3,
  },
  {
    id: 'code-assistant',
    label: 'Code Assistant',
    description: 'Write, debug, and preview code',
    icon: Code2,
  },
  {
    id: 'document-assistant',
    label: 'Document Assistant',
    description: 'Summarize and query uploaded files',
    icon: BookOpen,
  },
];

export function Composer({
  onSend,
  onStop,
  isStreaming,
  activeTool,
  onSelectTool,
  enterToSend,
  voiceLang,
  centered = false,
}: ComposerProps) {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [attachMenuOpen, setAttachMenuOpen] = useState(false);
  const [toolsMenuOpen, setToolsMenuOpen] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);
  const attachMenuRef = useRef<HTMLDivElement>(null);
  const toolsMenuRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const timerRef = useRef<number | null>(null);

  // Auto-expand textarea
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 210)}px`;
  }, [text]);

  // Close menus on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (attachMenuRef.current && !attachMenuRef.current.contains(e.target as Node)) {
        setAttachMenuOpen(false);
      }
      if (toolsMenuRef.current && !toolsMenuRef.current.contains(e.target as Node)) {
        setToolsMenuOpen(false);
      }
    };
    window.addEventListener('mousedown', handler);
    return () => window.removeEventListener('mousedown', handler);
  }, []);

  // Cleanup speech recognition
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, []);

  const handleFilesSelected = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    setUploadError(null);
    setUploading(true);
    try {
      const files = Array.from(fileList).slice(0, 5);
      const uploaded = await novaApi.uploadFiles(files);
      setAttachments((prev) => [...prev, ...uploaded].slice(0, 5));
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Failed to process file.');
    } finally {
      setUploading(false);
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    const files: File[] = [];
    for (const item of Array.from(items)) {
      if (item.kind === 'file') {
        const f = item.getAsFile();
        if (f) files.push(f);
      }
    }
    if (files.length > 0) {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      handleFilesSelected(dt.files);
    }
  };

  const toggleVoiceRecording = () => {
    setVoiceError(null);
    if (recording) {
      try {
        recognitionRef.current?.stop();
      } catch {}
      setRecording(false);
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      setVoiceError('Speech recognition is not supported in this browser. Try Chrome or Edge.');
      return;
    }

    try {
      const rec = new SpeechRec();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = voiceLang || 'en-US';
      const baseText = text ? `${text.trimEnd()} ` : '';

      rec.onresult = (event: any) => {
        let transcript = '';
        for (let i = 0; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setText(`${baseText}${transcript}`);
      };

      rec.onerror = (event: any) => {
        setVoiceError(
          event.error === 'not-allowed'
            ? 'Microphone permission denied. Please allow microphone access.'
            : `Voice input error: ${event.error}`
        );
        setRecording(false);
        if (timerRef.current) {
          window.clearInterval(timerRef.current);
          timerRef.current = null;
        }
      };

      rec.onend = () => {
        setRecording(false);
        if (timerRef.current) {
          window.clearInterval(timerRef.current);
          timerRef.current = null;
        }
      };

      recognitionRef.current = rec;
      rec.start();
      setRecording(true);
      setRecordSeconds(0);
      timerRef.current = window.setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    } catch {
      setVoiceError('Could not start microphone recording.');
    }
  };

  const submitMessage = () => {
    if (isStreaming || uploading) return;
    if (!text.trim() && attachments.length === 0) return;
    if (recording) toggleVoiceRecording();
    onSend(text.trim(), attachments, activeTool);
    setText('');
    setAttachments([]);
    setUploadError(null);
  };

  const activeToolMeta = TOOL_OPTIONS.find((t) => t.id === activeTool);

  return (
    <div className={`w-full max-w-3xl mx-auto ${centered ? '' : 'px-3 sm:px-4 pb-3 sm:pb-5 pt-2'}`}>
      {(uploadError || voiceError) && (
        <div className="mb-2 flex items-center justify-between gap-2 px-3.5 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-xs text-rose-700 dark:text-rose-200">
          <span>{uploadError || voiceError}</span>
          <button
            type="button"
            onClick={() => {
              setUploadError(null);
              setVoiceError(null);
            }}
            className="p-0.5 hover:opacity-75"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      <div className="rounded-2xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-[#181C2A] shadow-sm focus-within:border-indigo-500/70 dark:focus-within:border-indigo-400/70 transition-colors">
        {/* Attachments Strip */}
        {(attachments.length > 0 || uploading) && (
          <div className="flex flex-wrap items-center gap-2 px-3.5 pt-3">
            {attachments.map((att) => (
              <div
                key={att.id}
                className="relative group flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#131622] px-2.5 py-1.5"
              >
                {att.kind === 'image' && att.dataUrl ? (
                  <img
                    src={att.dataUrl}
                    alt={att.name}
                    className="w-9 h-9 rounded-lg object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : att.kind === 'data' ? (
                  <Table2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                ) : (
                  <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                )}
                <div className="min-w-0 max-w-[140px]">
                  <div className="text-xs font-medium text-slate-800 dark:text-slate-100 truncate">
                    {att.name}
                  </div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400">
                    {att.kind === 'data' && att.csvSummary
                      ? `${att.csvSummary.rowCount} rows`
                      : att.pageCount
                        ? `${att.pageCount} pages`
                        : att.kind}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setAttachments((prev) => prev.filter((a) => a.id !== att.id))}
                  className="p-1 rounded-md text-slate-400 hover:text-slate-800 dark:hover:text-white"
                  aria-label={`Remove ${att.name}`}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            {uploading && (
              <div className="flex items-center gap-2 px-3 py-2 text-xs text-slate-500 dark:text-slate-400">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                <span>Processing file...</span>
              </div>
            )}
          </div>
        )}

        {/* Active Tool Bar */}
        {activeToolMeta && (
          <div className="flex items-center justify-between px-3.5 pt-2.5">
            <div className="inline-flex items-center gap-1.5 text-xs font-medium text-indigo-700 dark:text-indigo-300">
              <activeToolMeta.icon className="w-3.5 h-3.5" />
              <span>{activeToolMeta.label} active</span>
            </div>
            <button
              type="button"
              onClick={() => onSelectTool('none')}
              className="text-xs text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 inline-flex items-center gap-1"
            >
              <X className="w-3 h-3" />
              <span>Clear tool</span>
            </button>
          </div>
        )}

        {/* Expanding Textarea */}
        <div className="px-3.5 pt-3 pb-1.5">
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onPaste={handlePaste}
            onKeyDown={(e) => {
              if (enterToSend && e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                submitMessage();
              }
            }}
            rows={1}
            placeholder={
              activeTool === 'image-gen'
                ? 'Describe the image you want to generate...'
                : activeTool === 'web-search'
                  ? 'Ask anything to search the web with citations...'
                  : activeTool === 'data-analysis'
                    ? 'Upload a CSV or ask NOVA AI to analyze and chart your data...'
                    : 'Message NOVA AI...'
            }
            className="w-full max-h-[210px] resize-none bg-transparent text-[15px] text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none leading-relaxed"
          />
        </div>

        {/* Bottom Controls */}
        <div className="flex items-center justify-between gap-2 px-2.5 pb-2.5 pt-1">
          <div className="flex items-center gap-1">
            {/* Hidden file inputs */}
            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => {
                handleFilesSelected(e.target.files);
                e.target.value = '';
              }}
            />
            <input
              ref={docInputRef}
              type="file"
              accept=".pdf,.docx,.txt,.md,.csv,.json,.js,.ts,.tsx,.py,.html,.css,.sql,.yaml,.yml"
              multiple
              className="hidden"
              onChange={(e) => {
                handleFilesSelected(e.target.files);
                e.target.value = '';
              }}
            />

            {/* + Attachment Button */}
            <div ref={attachMenuRef} className="relative">
              <button
                type="button"
                onClick={() => {
                  setAttachMenuOpen((o) => !o);
                  setToolsMenuOpen(false);
                }}
                className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#23283B] transition-colors"
                title="Attach files or images"
                aria-label="Attach files or images"
              >
                <Plus className="w-4 h-4" />
              </button>

              {attachMenuOpen && (
                <div className="absolute left-0 bottom-11 w-56 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-[#151926] shadow-xl py-1.5 text-xs z-40">
                  <button
                    type="button"
                    onClick={() => {
                      setAttachMenuOpen(false);
                      imageInputRef.current?.click();
                    }}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <ImageIcon className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span>Upload image</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAttachMenuOpen(false);
                      docInputRef.current?.click();
                    }}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span>Upload PDF, DOCX, CSV, TXT</span>
                  </button>
                </div>
              )}
            </div>

            {/* Tools Menu */}
            <div ref={toolsMenuRef} className="relative">
              <button
                type="button"
                onClick={() => {
                  setToolsMenuOpen((o) => !o);
                  setAttachMenuOpen(false);
                }}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition-colors ${
                  activeTool !== 'none'
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#23283B]'
                }`}
                title="AI Tools"
              >
                <Wrench className="w-3.5 h-3.5" />
                <span>Tools</span>
              </button>

              {toolsMenuOpen && (
                <div className="absolute left-0 bottom-11 w-68 rounded-2xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-[#151926] shadow-xl p-1.5 z-40">
                  {TOOL_OPTIONS.map((tool) => {
                    const Icon = tool.icon;
                    const selected = activeTool === tool.id;
                    return (
                      <button
                        key={tool.id}
                        type="button"
                        onClick={() => {
                          onSelectTool(selected ? 'none' : tool.id);
                          setToolsMenuOpen(false);
                        }}
                        className={`w-full flex items-start gap-2.5 p-2 rounded-xl text-left transition-colors ${
                          selected
                            ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-200'
                            : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Icon className="w-4 h-4 shrink-0 mt-0.5 text-indigo-600 dark:text-indigo-400" />
                        <div>
                          <div className="text-xs font-semibold">{tool.label}</div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">
                            {tool.description}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Voice Input */}
            <button
              type="button"
              onClick={toggleVoiceRecording}
              className={`inline-flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-xs font-medium transition-colors ${
                recording
                  ? 'bg-rose-600 text-white hover:bg-rose-700'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#23283B]'
              }`}
              title={recording ? 'Stop voice recording' : 'Voice input (speech-to-text)'}
              aria-label={recording ? 'Stop voice recording' : 'Start voice input'}
            >
              {recording ? (
                <>
                  <MicOff className="w-4 h-4" />
                  <span className="tabular-nums font-mono">{recordSeconds}s</span>
                </>
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </button>

            {/* Send or Stop */}
            {isStreaming ? (
              <button
                type="button"
                onClick={onStop}
                className="inline-flex items-center justify-center w-9 h-9 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:opacity-90 transition-opacity"
                title="Stop generating"
                aria-label="Stop generating"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
              </button>
            ) : (
              <button
                type="button"
                onClick={submitMessage}
                disabled={uploading || (!text.trim() && attachments.length === 0)}
                className="inline-flex items-center justify-center w-9 h-9 rounded-xl bg-[#5B21B6] hover:bg-[#4C1D95] dark:bg-[#7C3AED] dark:hover:bg-[#6D28D9] text-white disabled:opacity-35 disabled:cursor-not-allowed transition-colors"
                title="Send message"
                aria-label="Send message"
              >
                <ArrowUp className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      <p className="mt-2 text-center text-[11px] text-slate-400 dark:text-slate-500">
        NOVA AI can make mistakes. Verify important facts, code, and financial data.
      </p>
    </div>
  );
}
