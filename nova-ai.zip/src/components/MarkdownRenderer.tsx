import { useState, useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Check, Copy, Eye, Code2 } from 'lucide-react';
import { ChartRenderer } from './ChartRenderer';
import type { ChartSpec } from '../types/nova';

interface CodeBlockProps {
  language: string;
  value: string;
  isDark: boolean;
}

function CodeBlock({ language, value, isDark }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const canPreview = language === 'html' || language === 'svg';

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // ignore clipboard errors
    }
  };

  return (
    <div className="my-3 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0D1018]">
      <div className="flex items-center justify-between px-3.5 py-2 bg-slate-100/90 dark:bg-[#151926] border-b border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400">
        <span className="font-mono font-medium lowercase">{language || 'text'}</span>
        <div className="flex items-center gap-2">
          {canPreview && (
            <button
              type="button"
              onClick={() => setShowPreview((p) => !p)}
              className="inline-flex items-center gap-1 px-2 py-1 rounded-md hover:bg-slate-200/70 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors"
            >
              {showPreview ? <Code2 className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{showPreview ? 'Code' : 'Preview'}</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-slate-200/70 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors"
            aria-label="Copy code"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      </div>

      {showPreview && canPreview ? (
        <div className="bg-white p-2">
          <iframe
            title="NOVA Code Preview"
            sandbox="allow-scripts"
            srcDoc={
              language === 'svg'
                ? `<html><body style="margin:0;display:flex;justify-content:center;align-items:center;min-height:180px;">${value}</body></html>`
                : value
            }
            className="w-full h-72 border-0 rounded"
          />
        </div>
      ) : (
        <SyntaxHighlighter
          style={isDark ? oneDark : oneLight}
          language={language || 'text'}
          PreTag="div"
          customStyle={{
            margin: 0,
            padding: '0.9rem 1rem',
            fontSize: '0.84rem',
            lineHeight: '1.55',
            background: 'transparent',
          }}
        >
          {value}
        </SyntaxHighlighter>
      )}
    </div>
  );
}

interface MarkdownRendererProps {
  content: string;
  charts?: ChartSpec[];
  isDark: boolean;
  fontSize?: 'compact' | 'standard' | 'comfortable';
}

export function MarkdownRenderer({
  content,
  charts,
  isDark,
  fontSize = 'standard',
}: MarkdownRendererProps) {
  // Remove fenced nova-chart blocks from visible markdown text so they render cleanly as ChartRenderer
  const { cleanMarkdown, inlineCharts } = useMemo(() => {
    const parsedCharts: ChartSpec[] = [];
    const cleaned = content.replace(/```nova-chart\s*\n([\s\S]*?)```/g, (_full, inner) => {
      try {
        const obj = JSON.parse(String(inner).trim());
        if (obj && obj.title && obj.type && obj.xKey && Array.isArray(obj.yKeys) && Array.isArray(obj.data)) {
          parsedCharts.push(obj as ChartSpec);
          return '';
        }
      } catch {
        // Wait until block finishes streaming
      }
      return '';
    });
    return {
      cleanMarkdown: cleaned.trim(),
      inlineCharts: charts && charts.length > 0 ? charts : parsedCharts,
    };
  }, [content, charts]);

  const sizeClass =
    fontSize === 'compact'
      ? 'text-[14px]'
      : fontSize === 'comfortable'
        ? 'text-[16.5px]'
        : 'text-[15.25px]';

  return (
    <div className={`nova-prose ${sizeClass} text-slate-800 dark:text-slate-100`}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={{
          code(props) {
            const { children, className, ...rest } = props;
            const match = /language-(\w+)/.exec(className || '');
            const text = String(children).replace(/\n$/, '');
            const isBlock = Boolean(match) || text.includes('\n');
            if (isBlock) {
              return <CodeBlock language={match ? match[1] : 'text'} value={text} isDark={isDark} />;
            }
            return (
              <code
                {...rest}
                className="px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800/90 text-indigo-700 dark:text-indigo-300 font-mono text-[0.86em]"
              >
                {children}
              </code>
            );
          },
          a(props) {
            return (
              <a
                {...props}
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 dark:text-indigo-400 underline underline-offset-2 hover:text-indigo-500"
              />
            );
          },
          table(props) {
            return (
              <div className="my-3 overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
                <table {...props} className="w-full !my-0" />
              </div>
            );
          },
        }}
      >
        {cleanMarkdown}
      </ReactMarkdown>

      {inlineCharts.map((spec, idx) => (
        <ChartRenderer key={`${spec.title}-${idx}`} spec={spec} />
      ))}
    </div>
  );
}
