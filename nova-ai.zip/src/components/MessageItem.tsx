import { useState } from 'react';
import {
  Copy,
  Check,
  RotateCcw,
  ThumbsUp,
  ThumbsDown,
  Pencil,
  Volume2,
  Pause,
  Square,
  FileText,
  Table2,
  ExternalLink,
  Download,
  X,
  AlertCircle,
} from 'lucide-react';
import { NovaMark } from './NovaLogo';
import { MarkdownRenderer } from './MarkdownRenderer';
import type { Attachment, ChatMessage } from '../types/nova';

interface MessageItemProps {
  message: ChatMessage;
  isDark: boolean;
  fontSize: 'compact' | 'standard' | 'comfortable';
  isStreamingGlobal: boolean;
  ttsActiveId: string | null;
  ttsPaused: boolean;
  onCopy: (text: string) => void;
  onRegenerate: (assistantMessageId: string) => void;
  onEditUserMessage: (userMessageId: string, newText: string) => void;
  onFeedback: (messageId: string, feedback: 'up' | 'down' | null) => void;
  onSpeak: (messageId: string, text: string) => void;
  onPauseResumeSpeak: () => void;
  onStopSpeak: () => void;
  onOpenProviderSettings: () => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function MessageItem({
  message,
  isDark,
  fontSize,
  isStreamingGlobal,
  ttsActiveId,
  ttsPaused,
  onCopy,
  onRegenerate,
  onEditUserMessage,
  onFeedback,
  onSpeak,
  onPauseResumeSpeak,
  onStopSpeak,
  onOpenProviderSettings,
}: MessageItemProps) {
  const [copied, setCopied] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editValue, setEditValue] = useState(message.content);
  const [inspectAttachment, setInspectAttachment] = useState<Attachment | null>(null);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);

  const isUser = message.role === 'user';
  const isThisSpeaking = ttsActiveId === message.id;

  const handleCopyClick = async () => {
    await onCopy(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  if (isUser) {
    return (
      <div className="group flex flex-col items-end gap-2 py-3">
        {/* Attachments */}
        {message.attachments && message.attachments.length > 0 && (
          <div className="flex flex-wrap justify-end gap-2 max-w-[85%]">
            {message.attachments.map((att) =>
              att.kind === 'image' && att.dataUrl ? (
                <button
                  key={att.id}
                  type="button"
                  onClick={() => setLightboxUrl(att.dataUrl!)}
                  className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700/80 hover:opacity-95 transition-opacity"
                >
                  <img
                    src={att.dataUrl}
                    alt={att.name}
                    className="max-h-56 max-w-xs object-cover"
                    referrerPolicy="no-referrer"
                  />
                </button>
              ) : (
                <button
                  key={att.id}
                  type="button"
                  onClick={() => setInspectAttachment(att)}
                  className="flex items-center gap-2.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-[#171B29] text-left hover:border-indigo-400 dark:hover:border-indigo-500/60 transition-colors"
                >
                  {att.kind === 'data' ? (
                    <Table2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                  ) : (
                    <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                  )}
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-slate-800 dark:text-slate-100 truncate max-w-[180px]">
                      {att.name}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                      {formatBytes(att.size)}
                      {att.pageCount ? ` · ${att.pageCount} pages` : ''}
                      {att.csvSummary ? ` · ${att.csvSummary.rowCount} rows` : ''}
                    </div>
                  </div>
                </button>
              )
            )}
          </div>
        )}

        {editing ? (
          <div className="w-full max-w-[85%] rounded-2xl border border-indigo-500/70 bg-white dark:bg-[#171B29] p-3 shadow-sm">
            <textarea
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              rows={3}
              className="w-full bg-transparent text-sm text-slate-900 dark:text-slate-100 focus:outline-none resize-y"
              autoFocus
            />
            <div className="flex justify-end gap-2 mt-2">
              <button
                type="button"
                onClick={() => {
                  setEditing(false);
                  setEditValue(message.content);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (editValue.trim()) {
                    onEditUserMessage(message.id, editValue.trim());
                    setEditing(false);
                  }
                }}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white"
              >
                Save & Send
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-start gap-2 max-w-[88%] sm:max-w-[78%]">
            {!isStreamingGlobal && (
              <button
                type="button"
                onClick={() => {
                  setEditValue(message.content);
                  setEditing(true);
                }}
                className="opacity-0 group-hover:opacity-100 focus:opacity-100 p-1.5 mt-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-opacity"
                title="Edit message"
                aria-label="Edit message"
              >
                <Pencil className="w-3.5 h-3.5" />
              </button>
            )}
            {message.content && (
              <div className="rounded-2xl rounded-tr-sm px-4 py-2.5 bg-indigo-50/90 dark:bg-[#1C2135] border border-indigo-100 dark:border-indigo-500/20 text-[15px] leading-relaxed text-slate-900 dark:text-slate-100 whitespace-pre-wrap break-words">
                {message.content}
              </div>
            )}
          </div>
        )}

        {/* Attachment Inspector Modal */}
        {inspectAttachment && (
          <div
            className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4"
            onClick={() => setInspectAttachment(null)}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl max-h-[80vh] flex flex-col rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#151926] shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    {inspectAttachment.name}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    {inspectAttachment.mimeType} · {formatBytes(inspectAttachment.size)}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setInspectAttachment(null)}
                  className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <pre className="flex-1 overflow-auto p-4 text-xs font-mono text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                {inspectAttachment.extractedText || 'No text content available.'}
              </pre>
            </div>
          </div>
        )}

        {/* Image Lightbox */}
        {lightboxUrl && (
          <div
            className="fixed inset-0 z-50 bg-slate-950/85 flex items-center justify-center p-4"
            onClick={() => setLightboxUrl(null)}
          >
            <img
              src={lightboxUrl}
              alt="Attachment preview"
              className="max-w-full max-h-[90vh] rounded-xl shadow-2xl"
              referrerPolicy="no-referrer"
            />
          </div>
        )}
      </div>
    );
  }

  // Assistant Message
  const isGroqKeyMissing = message.error?.includes('GROQ_KEY_MISSING');

  return (
    <div className="group flex items-start gap-3.5 py-4">
      <div className="mt-0.5 shrink-0">
        <NovaMark size={28} />
      </div>

      <div className="flex-1 min-w-0">
        {message.error ? (
          <div className="rounded-xl border border-rose-200 dark:border-rose-800/70 bg-rose-50/70 dark:bg-rose-950/30 p-3.5 text-sm text-rose-800 dark:text-rose-200">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              <div className="space-y-2">
                <p>{message.error.replace('GROQ_KEY_MISSING: ', '')}</p>
                {isGroqKeyMissing && (
                  <button
                    type="button"
                    onClick={onOpenProviderSettings}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors"
                  >
                    Open API & Provider Settings
                  </button>
                )}
              </div>
            </div>
          </div>
        ) : (
          <>
            {message.content ? (
              <MarkdownRenderer
                content={message.content}
                charts={message.charts}
                isDark={isDark}
                fontSize={fontSize}
              />
            ) : message.isStreaming ? (
              <div className="flex items-center gap-2 py-2 text-sm text-slate-500 dark:text-slate-400">
                <span className="inline-block w-2 h-4 bg-indigo-500 rounded-xs animate-pulse" />
                <span>Thinking...</span>
              </div>
            ) : null}

            {/* Generated Images */}
            {message.generatedImages && message.generatedImages.length > 0 && (
              <div className="mt-3 space-y-2">
                {message.generatedImages.map((img, i) => (
                  <div
                    key={i}
                    className="inline-block rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#141824]"
                  >
                    <img
                      src={img.url}
                      alt={img.prompt}
                      className="max-w-full max-h-[420px] object-contain"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex items-center justify-between px-3.5 py-2 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                      <span className="truncate max-w-xs">{img.prompt}</span>
                      <a
                        href={img.url}
                        download={`nova-image-${i + 1}.png`}
                        className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400 font-medium hover:underline"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Web Search Grounding Citations */}
            {message.sources && message.sources.length > 0 && (
              <div className="mt-3 pt-2.5 border-t border-slate-200/70 dark:border-slate-800/70">
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
                  Sources
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs">
                  {message.sources.map((src, idx) => {
                    let host = '';
                    try {
                      host = new URL(src.uri).hostname.replace(/^www\./, '');
                    } catch {
                      host = src.uri;
                    }
                    return (
                      <a
                        key={`${src.uri}-${idx}`}
                        href={src.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400 hover:underline max-w-[260px]"
                      >
                        <span className="tabular-nums text-slate-400">[{idx + 1}]</span>
                        <span className="truncate">{src.title || host}</span>
                        <ExternalLink className="w-3 h-3 shrink-0 opacity-75" />
                      </a>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Action Toolbar */}
            {!message.isStreaming && message.content && (
              <div className="mt-2.5 flex flex-wrap items-center gap-1 text-slate-500 dark:text-slate-400">
                <button
                  type="button"
                  onClick={handleCopyClick}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-[#181D2C] hover:text-slate-800 dark:hover:text-slate-200 text-xs transition-colors"
                  title="Copy response"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>

                {!isThisSpeaking ? (
                  <button
                    type="button"
                    onClick={() => onSpeak(message.id, message.content)}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-[#181D2C] hover:text-slate-800 dark:hover:text-slate-200 text-xs transition-colors"
                    title="Read aloud"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Listen</span>
                  </button>
                ) : (
                  <div className="inline-flex items-center gap-1">
                    <button
                      type="button"
                      onClick={onPauseResumeSpeak}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-xs"
                    >
                      <Pause className="w-3.5 h-3.5" />
                      <span>{ttsPaused ? 'Resume' : 'Pause'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={onStopSpeak}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-[#181D2C] text-xs"
                      title="Stop audio"
                    >
                      <Square className="w-3 h-3" />
                      <span>Stop</span>
                    </button>
                  </div>
                )}

                {!isStreamingGlobal && (
                  <button
                    type="button"
                    onClick={() => onRegenerate(message.id)}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-[#181D2C] hover:text-slate-800 dark:hover:text-slate-200 text-xs transition-colors"
                    title="Regenerate response"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Regenerate</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => onFeedback(message.id, message.feedback === 'up' ? null : 'up')}
                  className={`p-1.5 rounded-lg transition-colors ${
                    message.feedback === 'up'
                      ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50'
                      : 'hover:bg-slate-100 dark:hover:bg-[#181D2C] hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                  title="Good response"
                  aria-label="Thumbs up"
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => onFeedback(message.id, message.feedback === 'down' ? null : 'down')}
                  className={`p-1.5 rounded-lg transition-colors ${
                    message.feedback === 'down'
                      ? 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40'
                      : 'hover:bg-slate-100 dark:hover:bg-[#181D2C] hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                  title="Needs improvement"
                  aria-label="Thumbs down"
                >
                  <ThumbsDown className="w-3.5 h-3.5" />
                </button>

                {message.model && (
                  <span className="ml-auto text-[11px] text-slate-400 dark:text-slate-500">
                    {message.model === 'gemini-4-hydrogen' ? 'NOVA Core' : message.model}
                    {message.toolUsed && message.toolUsed !== 'none' ? ` · ${message.toolUsed.replace('-', ' ')}` : ''}
                  </span>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
