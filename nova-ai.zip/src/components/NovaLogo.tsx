interface NovaLogoProps {
  size?: number;
  showWordmark?: boolean;
  className?: string;
}

export function NovaMark({ size = 28, className = '' }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="novaLogoGrad" x1="6" y1="6" x2="58" y2="58" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#4F46E5" />
          <stop offset="55%" stopColor="#7C3AED" />
          <stop offset="100%" stopColor="#3B82F6" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill="url(#novaLogoGrad)" />
      <path
        d="M32 13C33.8 23.6 40.4 30.2 51 32C40.4 33.8 33.8 40.4 32 51C30.2 40.4 23.6 33.8 13 32C23.6 30.2 30.2 23.6 32 13Z"
        fill="#FFFFFF"
      />
      <circle cx="46" cy="18" r="2.8" fill="#DDD6FE" />
    </svg>
  );
}

export function NovaLogo({ size = 28, showWordmark = true, className = '' }: NovaLogoProps) {
  return (
    <div className={`inline-flex items-center gap-2.5 select-none whitespace-nowrap shrink-0 ${className}`}>
      <NovaMark size={size} />
      {showWordmark && (
        <span className="font-display text-[17px] font-bold tracking-tight text-slate-900 dark:text-slate-100">
          NOVA AI
        </span>
      )}
    </div>
  );
}
