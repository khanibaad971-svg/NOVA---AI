import { useState, useEffect } from 'react';
import {
  X,
  Sliders,
  Palette,
  Brain,
  Mic,
  Database,
  Cpu,
  User,
  Sun,
  Moon,
  Monitor,
  Plus,
  Trash2,
  Download,
  Upload,
  CheckCircle2,
  AlertCircle,
  Loader2,
  LogOut,
} from 'lucide-react';
import { novaApi } from '../lib/api';
import type {
  AIModelInfo,
  Conversation,
  MemoryItem,
  ProviderStatus,
  UsageSummary,
  UserProfile,
  UserSettings,
} from '../types/nova';

interface SettingsModalProps {
  open: boolean;
  initialTab?: string;
  onClose: () => void;
  user: UserProfile | null;
  onUserUpdated: (u: UserProfile | null) => void;
  settings: UserSettings;
  onSaveSettings: (next: UserSettings) => Promise<void>;
  memories: MemoryItem[];
  onAddMemory: (content: string) => Promise<void>;
  onDeleteMemory: (id: string) => Promise<void>;
  models: AIModelInfo[];
  onModelsUpdated: (models: AIModelInfo[]) => void;
  conversations: Conversation[];
  onImportConversations: (convs: Conversation[]) => Promise<void>;
  onClearAllConversations: () => Promise<void>;
  onOpenAuth: () => void;
}

const TABS = [
  { id: 'general', label: 'General', icon: Sliders },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'personalization', label: 'Personalization', icon: Brain },
  { id: 'voice', label: 'Voice', icon: Mic },
  { id: 'data', label: 'Data Controls', icon: Database },
  { id: 'providers', label: 'API & Providers', icon: Cpu },
  { id: 'account', label: 'Account', icon: User },
];

const LANGUAGES = ['English', 'Spanish', 'French', 'German', 'Portuguese', 'Japanese', 'Korean', 'Hindi', 'Arabic'];
const VOICE_LANGS = [
  { code: 'en-US', label: 'English (US)' },
  { code: 'en-GB', label: 'English (UK)' },
  { code: 'es-ES', label: 'Spanish' },
  { code: 'fr-FR', label: 'French' },
  { code: 'de-DE', label: 'German' },
  { code: 'ja-JP', label: 'Japanese' },
  { code: 'hi-IN', label: 'Hindi' },
];
const AVATAR_COLORS = ['#4F46E5', '#6D28D9', '#7C3AED', '#2563EB', '#4338CA', '#0F766E'];

export function SettingsModal({
  open,
  initialTab = 'general',
  onClose,
  user,
  onUserUpdated,
  settings,
  onSaveSettings,
  memories,
  onAddMemory,
  onDeleteMemory,
  models,
  onModelsUpdated,
  conversations,
  onImportConversations,
  onClearAllConversations,
  onOpenAuth,
}: SettingsModalProps) {
  const [tab, setTab] = useState(initialTab);
  const [draft, setDraft] = useState<UserSettings>(settings);
  const [newMemory, setNewMemory] = useState('');
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [statusMsg, setStatusMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Providers & Usage state
  const [providers, setProviders] = useState<ProviderStatus[]>([]);
  const [usage, setUsage] = useState<UsageSummary | null>(null);
  const [groqKeyInput, setGroqKeyInput] = useState('');
  const [groqBaseUrl, setGroqBaseUrl] = useState('https://api.groq.com/openai/v1');
  const [customModelId, setCustomModelId] = useState('');
  const [customModelName, setCustomModelName] = useState('');
  const [groqTesting, setGroqTesting] = useState(false);
  const [groqTestResult, setGroqTestResult] = useState<{ ok: boolean; text: string } | null>(null);

  const [imgKeyInput, setImgKeyInput] = useState('');
  const [imgEndpoint, setImgEndpoint] = useState('https://api.openai.com/v1/images/generations');
  const [imgModel, setImgModel] = useState('dall-e-3');

  // Account state
  const [profileName, setProfileName] = useState(user?.name || '');
  const [profileColor, setProfileColor] = useState(user?.avatarColor || '#4F46E5');
  const [curPass, setCurPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);
  const [confirmDeleteAccount, setConfirmDeleteAccount] = useState(false);

  useEffect(() => {
    if (open) {
      setTab(initialTab || 'general');
      setDraft(settings);
      setProfileName(user?.name || '');
      setProfileColor(user?.avatarColor || '#4F46E5');
      setStatusMsg(null);
      setGroqTestResult(null);

      // Load TTS voices
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        const load = () => setVoices(window.speechSynthesis.getVoices());
        load();
        window.speechSynthesis.onvoiceschanged = load;
      }

      // Load providers & usage
      novaApi
        .getProviders()
        .then((res) => {
          setProviders(res.providers);
          const groq = res.providers.find((p) => p.providerId === 'groq');
          if (groq?.baseUrl) setGroqBaseUrl(groq.baseUrl);
          const img = res.providers.find((p) => p.providerId === 'image');
          if (img?.baseUrl) setImgEndpoint(img.baseUrl);
          if (img?.imageModel) setImgModel(img.imageModel);
        })
        .catch(() => {});
      novaApi.getUsage().then(setUsage).catch(() => {});
    }
  }, [open, initialTab, settings, user]);

  if (!open) return null;

  const updateDraft = async (patch: Partial<UserSettings>) => {
    const next = { ...draft, ...patch };
    setDraft(next);
    await onSaveSettings(next);
  };

  const groqProvider = providers.find((p) => p.providerId === 'groq');
  const geminiProvider = providers.find((p) => p.providerId === 'gemini');
  const imageProvider = providers.find((p) => p.providerId === 'image');

  const handleSaveGroq = async () => {
    setStatusMsg(null);
    try {
      const res = await novaApi.updateProvider('groq', {
        ...(groqKeyInput.trim() ? { apiKey: groqKeyInput.trim() } : {}),
        baseUrl: groqBaseUrl.trim(),
        enabled: true,
      });
      setProviders(res.providers);
      onModelsUpdated(res.models);
      setGroqKeyInput('');
      setStatusMsg({ type: 'ok', text: 'Groq provider configuration saved.' });
    } catch (err) {
      setStatusMsg({ type: 'err', text: err instanceof Error ? err.message : 'Failed to save Groq settings.' });
    }
  };

  const handleClearGroqKey = async () => {
    const res = await novaApi.updateProvider('groq', { clearKey: true });
    setProviders(res.providers);
    onModelsUpdated(res.models);
    setStatusMsg({ type: 'ok', text: 'Saved Groq key cleared from database.' });
  };

  const handleAddCustomGroqModel = async () => {
    if (!customModelId.trim()) return;
    const existing = groqProvider?.customModels || [];
    const nextModels = [
      ...existing.filter((m) => m.id !== customModelId.trim()),
      { id: customModelId.trim(), name: customModelName.trim() || customModelId.trim() },
    ];
    const res = await novaApi.updateProvider('groq', { customModels: nextModels });
    setProviders(res.providers);
    onModelsUpdated(res.models);
    setCustomModelId('');
    setCustomModelName('');
    setStatusMsg({ type: 'ok', text: 'Custom Groq model added.' });
  };

  const handleRemoveCustomGroqModel = async (id: string) => {
    const existing = groqProvider?.customModels || [];
    const res = await novaApi.updateProvider('groq', {
      customModels: existing.filter((m) => m.id !== id),
    });
    setProviders(res.providers);
    onModelsUpdated(res.models);
  };

  const handleTestGroq = async () => {
    setGroqTesting(true);
    setGroqTestResult(null);
    try {
      const res = await novaApi.testGroq(groqKeyInput.trim() || undefined, groqBaseUrl.trim());
      setGroqTestResult({
        ok: res.ok,
        text: res.ok
          ? `Connected to Groq API (${res.modelsCount ?? 0} models available).`
          : res.error || 'Connection test failed.',
      });
    } catch (err) {
      setGroqTestResult({ ok: false, text: err instanceof Error ? err.message : 'Connection failed.' });
    } finally {
      setGroqTesting(false);
    }
  };

  const handleSaveImageProvider = async () => {
    try {
      const res = await novaApi.updateProvider('image', {
        ...(imgKeyInput.trim() ? { apiKey: imgKeyInput.trim() } : {}),
        baseUrl: imgEndpoint.trim(),
        imageModel: imgModel.trim(),
        enabled: true,
      });
      setProviders(res.providers);
      setImgKeyInput('');
      setStatusMsg({ type: 'ok', text: 'Image generation provider saved.' });
    } catch (err) {
      setStatusMsg({ type: 'err', text: err instanceof Error ? err.message : 'Save failed.' });
    }
  };

  const handleExportAll = async () => {
    try {
      const data = user
        ? await novaApi.exportConversations()
        : { exportedAt: new Date().toISOString(), conversations };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `nova-ai-export-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setStatusMsg({ type: 'ok', text: 'Conversations exported as JSON.' });
    } catch {
      setStatusMsg({ type: 'err', text: 'Export failed.' });
    }
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const convs = Array.isArray(parsed) ? parsed : parsed.conversations;
      if (!Array.isArray(convs)) throw new Error('Invalid export file format.');
      await onImportConversations(convs);
      setStatusMsg({ type: 'ok', text: `Imported ${convs.length} conversation(s).` });
    } catch (err) {
      setStatusMsg({ type: 'err', text: err instanceof Error ? err.message : 'Import failed.' });
    }
    e.target.value = '';
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-[2px] flex items-center justify-center p-3 sm:p-6"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-4xl h-[85vh] max-h-[680px] flex flex-col md:flex-row rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#131622] shadow-2xl overflow-hidden"
      >
        {/* Left Navigation */}
        <div className="md:w-56 shrink-0 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-[#0F111A] p-3 flex md:flex-col gap-1 overflow-x-auto">
          <div className="hidden md:flex items-center justify-between px-2.5 py-2 mb-1">
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
              Settings
            </h2>
          </div>

          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  setTab(t.id);
                  setStatusMsg(null);
                }}
                className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                  active
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-[#1A1E2E]'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Right Panel */}
        <div className="flex-1 flex flex-col min-w-0">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
            <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              {TABS.find((t) => t.id === tab)?.label}
            </h3>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Close settings"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm">
            {statusMsg && (
              <div
                className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs border ${
                  statusMsg.type === 'ok'
                    ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60 text-emerald-700 dark:text-emerald-300'
                    : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60 text-rose-700 dark:text-rose-300'
                }`}
              >
                {statusMsg.type === 'ok' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{statusMsg.text}</span>
              </div>
            )}

            {/* GENERAL */}
            {tab === 'general' && (
              <div className="space-y-5">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">Default AI Model</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Model selected automatically for new conversations.
                    </div>
                  </div>
                  <select
                    value={draft.defaultModel}
                    onChange={(e) => updateDraft({ defaultModel: e.target.value })}
                    className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] text-xs font-medium text-slate-900 dark:text-slate-100"
                  >
                    <option value="auto">Auto (Fastest Active Model)</option>
                    {models.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.providerLabel})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-200/70 dark:border-slate-800/70">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">Response Language</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Preferred language for NOVA AI replies.
                    </div>
                  </div>
                  <select
                    value={draft.language}
                    onChange={(e) => updateDraft({ language: e.target.value })}
                    className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] text-xs font-medium text-slate-900 dark:text-slate-100"
                  >
                    {LANGUAGES.map((l) => (
                      <option key={l} value={l}>
                        {l}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-200/70 dark:border-slate-800/70">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">Enter to Send</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Press Enter to submit, Shift+Enter for a newline.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => updateDraft({ enterToSend: !draft.enterToSend })}
                    className={`w-11 h-6 rounded-full transition-colors p-0.5 ${
                      draft.enterToSend ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                    aria-pressed={draft.enterToSend}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        draft.enterToSend ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            )}

            {/* APPEARANCE */}
            {tab === 'appearance' && (
              <div className="space-y-6">
                <div>
                  <div className="font-medium text-slate-900 dark:text-slate-100 mb-3">Theme</div>
                  <div className="grid grid-cols-3 gap-3">
                    {(
                      [
                        { id: 'light', label: 'Light', icon: Sun },
                        { id: 'dark', label: 'Dark', icon: Moon },
                        { id: 'system', label: 'System Default', icon: Monitor },
                      ] as const
                    ).map((opt) => {
                      const Icon = opt.icon;
                      const active = draft.theme === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => updateDraft({ theme: opt.id })}
                          className={`flex flex-col items-center gap-2 p-4 rounded-xl border text-xs font-medium transition-colors ${
                            active
                              ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300'
                              : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-[#181C2A]'
                          }`}
                        >
                          <Icon className="w-5 h-5" />
                          <span>{opt.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-200/70 dark:border-slate-800/70">
                  <div className="font-medium text-slate-900 dark:text-slate-100 mb-3">Reading Density</div>
                  <div className="inline-flex p-1 rounded-xl bg-slate-100 dark:bg-[#181C2A] border border-slate-200 dark:border-slate-800">
                    {(['compact', 'standard', 'comfortable'] as const).map((sz) => (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => updateDraft({ fontSize: sz })}
                        className={`px-4 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${
                          draft.fontSize === sz
                            ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                            : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* PERSONALIZATION & MEMORY */}
            {tab === 'personalization' && (
              <div className="space-y-6">
                <div className="space-y-3">
                  <div>
                    <label className="block font-medium text-slate-900 dark:text-slate-100 mb-1">
                      What would you like NOVA AI to know about you?
                    </label>
                    <textarea
                      rows={3}
                      value={draft.customInstructionsAbout}
                      onChange={(e) => setDraft({ ...draft, customInstructionsAbout: e.target.value })}
                      onBlur={() => updateDraft({ customInstructionsAbout: draft.customInstructionsAbout })}
                      placeholder="Role, expertise, preferred tech stack, or context..."
                      className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] p-3 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-900 dark:text-slate-100 mb-1">
                      How would you like NOVA AI to respond?
                    </label>
                    <textarea
                      rows={3}
                      value={draft.customInstructionsStyle}
                      onChange={(e) => setDraft({ ...draft, customInstructionsStyle: e.target.value })}
                      onBlur={() => updateDraft({ customInstructionsStyle: draft.customInstructionsStyle })}
                      placeholder="Tone, conciseness, formatting style..."
                      className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] p-3 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-200/70 dark:border-slate-800/70 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-slate-900 dark:text-slate-100">Persistent Memory</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        Include saved facts across all new conversations.
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => updateDraft({ memoryEnabled: !draft.memoryEnabled })}
                      className={`w-11 h-6 rounded-full transition-colors p-0.5 ${
                        draft.memoryEnabled ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full bg-white transition-transform ${
                          draft.memoryEnabled ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newMemory}
                      onChange={(e) => setNewMemory(e.target.value)}
                      onKeyDown={async (e) => {
                        if (e.key === 'Enter' && newMemory.trim()) {
                          await onAddMemory(newMemory.trim());
                          setNewMemory('');
                        }
                      }}
                      placeholder="Add a memory fact (e.g., I prefer TypeScript and concise answers)..."
                      className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] px-3 py-2 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        if (!newMemory.trim()) return;
                        await onAddMemory(newMemory.trim());
                        setNewMemory('');
                      }}
                      className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add
                    </button>
                  </div>

                  <div className="space-y-2 max-h-44 overflow-y-auto">
                    {memories.length === 0 ? (
                      <p className="text-xs text-slate-400">No saved memories yet.</p>
                    ) : (
                      memories.map((m) => (
                        <div
                          key={m.id}
                          className="flex items-center justify-between gap-3 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#181C2A] text-xs"
                        >
                          <span className="text-slate-800 dark:text-slate-200">{m.content}</span>
                          <button
                            type="button"
                            onClick={() => onDeleteMemory(m.id)}
                            className="p-1 text-slate-400 hover:text-rose-500"
                            aria-label="Delete memory"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* VOICE */}
            {tab === 'voice' && (
              <div className="space-y-5">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">Speech Recognition Language</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Language used for microphone voice-to-text dictation.
                    </div>
                  </div>
                  <select
                    value={draft.voiceLang}
                    onChange={(e) => updateDraft({ voiceLang: e.target.value })}
                    className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] text-xs text-slate-900 dark:text-slate-100"
                  >
                    {VOICE_LANGS.map((v) => (
                      <option key={v.code} value={v.code}>
                        {v.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-200/70 dark:border-slate-800/70">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">Text-to-Speech Voice</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Browser voice used when reading responses aloud.
                    </div>
                  </div>
                  <select
                    value={draft.ttsVoice}
                    onChange={(e) => updateDraft({ ttsVoice: e.target.value })}
                    className="max-w-[220px] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] text-xs text-slate-900 dark:text-slate-100"
                  >
                    <option value="">System Default</option>
                    {voices.map((v) => (
                      <option key={v.name} value={v.name}>
                        {v.name} ({v.lang})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-200/70 dark:border-slate-800/70">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">
                      Playback Speed ({draft.ttsRate.toFixed(1)}x)
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Adjust voice reading speed.
                    </div>
                  </div>
                  <input
                    type="range"
                    min="0.7"
                    max="1.6"
                    step="0.1"
                    value={draft.ttsRate}
                    onChange={(e) => updateDraft({ ttsRate: Number(e.target.value) })}
                    className="w-40 accent-indigo-600"
                  />
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-200/70 dark:border-slate-800/70">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">Auto-Read New Responses</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Automatically speak assistant replies once streaming finishes.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => updateDraft({ ttsAutoPlay: !draft.ttsAutoPlay })}
                    className={`w-11 h-6 rounded-full transition-colors p-0.5 ${
                      draft.ttsAutoPlay ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        draft.ttsAutoPlay ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            )}

            {/* DATA CONTROLS */}
            {tab === 'data' && (
              <div className="space-y-5">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">Export Chat History</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Download all conversations and messages as JSON.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleExportAll}
                    className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-[#181C2A] text-xs font-medium text-slate-800 dark:text-slate-100"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Export JSON
                  </button>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-200/70 dark:border-slate-800/70">
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">Import Chat History</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Restore conversations from a NOVA AI JSON export.
                    </div>
                  </div>
                  <label className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-[#181C2A] text-xs font-medium text-slate-800 dark:text-slate-100 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    Import JSON
                    <input type="file" accept=".json" className="hidden" onChange={handleImportFile} />
                  </label>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-200/70 dark:border-slate-800/70">
                  <div>
                    <div className="font-medium text-rose-600 dark:text-rose-400">Clear All Conversations</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Permanently delete every conversation in your workspace.
                    </div>
                  </div>
                  {!confirmClear ? (
                    <button
                      type="button"
                      onClick={() => setConfirmClear(true)}
                      className="px-3.5 py-2 rounded-xl border border-rose-300 dark:border-rose-800 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    >
                      Clear all chats
                    </button>
                  ) : (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          await onClearAllConversations();
                          setConfirmClear(false);
                          setStatusMsg({ type: 'ok', text: 'All conversations deleted.' });
                        }}
                        className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-semibold"
                      >
                        Confirm delete
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmClear(false)}
                        className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-xs"
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* API & PROVIDERS (ADMIN) */}
            {tab === 'providers' && (
              <div className="space-y-6">
                {/* Groq Provider Config */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3 bg-slate-50/50 dark:bg-[#171B29]">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-slate-100">Groq Cloud API</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        Status: {groqProvider?.configured ? `Configured (${groqProvider.maskedKey} via ${groqProvider.source})` : 'Not configured — add GROQ_API_KEY in .env or below'}
                      </div>
                    </div>
                    {groqProvider?.source === 'database' && (
                      <button
                        type="button"
                        onClick={handleClearGroqKey}
                        className="text-xs text-rose-600 dark:text-rose-400 hover:underline"
                      >
                        Clear stored key
                      </button>
                    )}
                  </div>

                  <div className="grid sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Groq API Key (stored server-side)
                      </label>
                      <input
                        type="password"
                        value={groqKeyInput}
                        onChange={(e) => setGroqKeyInput(e.target.value)}
                        placeholder={groqProvider?.configured ? 'Leave blank to keep existing key' : 'gsk_...'}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111420] px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Base URL
                      </label>
                      <input
                        type="text"
                        value={groqBaseUrl}
                        onChange={(e) => setGroqBaseUrl(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111420] px-3 py-2 text-xs font-mono text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={handleSaveGroq}
                      className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
                    >
                      Save Groq Config
                    </button>
                    <button
                      type="button"
                      onClick={handleTestGroq}
                      disabled={groqTesting}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-100"
                    >
                      {groqTesting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                      Test Connection
                    </button>
                  </div>

                  {groqTestResult && (
                    <div
                      className={`text-xs ${
                        groqTestResult.ok
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {groqTestResult.text}
                    </div>
                  )}

                  {/* Custom Groq Model Registry */}
                  <div className="pt-3 border-t border-slate-200/70 dark:border-slate-800/70 space-y-2">
                    <div className="text-xs font-medium text-slate-800 dark:text-slate-200">
                      Add Custom Groq Model ID
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <input
                        type="text"
                        value={customModelId}
                        onChange={(e) => setCustomModelId(e.target.value)}
                        placeholder="Model ID (e.g. qwen-qwq-32b)"
                        className="flex-1 min-w-[160px] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111420] px-3 py-1.5 text-xs font-mono text-slate-900 dark:text-slate-100"
                      />
                      <input
                        type="text"
                        value={customModelName}
                        onChange={(e) => setCustomModelName(e.target.value)}
                        placeholder="Display Name"
                        className="flex-1 min-w-[140px] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111420] px-3 py-1.5 text-xs text-slate-900 dark:text-slate-100"
                      />
                      <button
                        type="button"
                        onClick={handleAddCustomGroqModel}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 dark:bg-slate-700 text-white text-xs font-medium"
                      >
                        Add Model
                      </button>
                    </div>
                    {(groqProvider?.customModels || []).map((cm) => (
                      <div key={cm.id} className="flex items-center justify-between text-xs px-2 py-1">
                        <span className="font-mono text-slate-700 dark:text-slate-300">
                          {cm.name} ({cm.id})
                        </span>
                        <button
                          type="button"
                          onClick={() => handleRemoveCustomGroqModel(cm.id)}
                          className="text-rose-500 hover:underline"
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* NOVA Core Status (No key form) */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 flex items-center justify-between bg-slate-50/50 dark:bg-[#171B29]">
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-slate-100">NOVA Core Engine</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Status: {geminiProvider?.configured ? 'Active (Managed Server Runtime)' : 'Unavailable'}
                    </div>
                  </div>
                  <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                    {geminiProvider?.configured ? 'Ready' : 'Offline'}
                  </span>
                </div>

                {/* Image Generation Provider */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3 bg-slate-50/50 dark:bg-[#171B29]">
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-slate-100">
                      Image Generation Provider
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      Status:{' '}
                      {imageProvider?.configured
                        ? `Configured (${imageProvider.maskedKey} · ${imageProvider.imageModel})`
                        : 'Not configured (required for Image Generation tool)'}
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-3 gap-2.5">
                    <input
                      type="password"
                      value={imgKeyInput}
                      onChange={(e) => setImgKeyInput(e.target.value)}
                      placeholder="Provider API Key"
                      className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111420] px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                    />
                    <input
                      type="text"
                      value={imgEndpoint}
                      onChange={(e) => setImgEndpoint(e.target.value)}
                      placeholder="Endpoint URL"
                      className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111420] px-3 py-2 text-xs font-mono text-slate-900 dark:text-slate-100"
                    />
                    <input
                      type="text"
                      value={imgModel}
                      onChange={(e) => setImgModel(e.target.value)}
                      placeholder="Model (e.g. dall-e-3)"
                      className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111420] px-3 py-2 text-xs font-mono text-slate-900 dark:text-slate-100"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleSaveImageProvider}
                    className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
                  >
                    Save Image Provider
                  </button>
                </div>

                {/* API Usage Telemetry */}
                {usage && (
                  <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
                    <div className="font-semibold text-slate-900 dark:text-slate-100">API Usage Monitor</div>
                    <div className="grid grid-cols-3 gap-3 text-center tabular-nums">
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#171B29]">
                        <div className="text-lg font-bold text-slate-900 dark:text-white">
                          {usage.totalRequests}
                        </div>
                        <div className="text-[11px] text-slate-500">Total Requests</div>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#171B29]">
                        <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                          {usage.successfulRequests}
                        </div>
                        <div className="text-[11px] text-slate-500">Succeeded</div>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#171B29]">
                        <div className="text-lg font-bold text-indigo-600 dark:text-indigo-400">
                          {usage.avgLatencyMs}ms
                        </div>
                        <div className="text-[11px] text-slate-500">Avg Latency</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ACCOUNT */}
            {tab === 'account' && (
              <div className="space-y-6">
                {!user ? (
                  <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-5 text-center space-y-3">
                    <p className="text-sm text-slate-700 dark:text-slate-300">
                      Sign in or create an account to sync conversations, settings, and memories across devices.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenAuth();
                      }}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
                    >
                      Sign in / Create Account
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="space-y-3">
                      <div className="font-medium text-slate-900 dark:text-slate-100">Profile</div>
                      <div className="flex flex-wrap items-center gap-3">
                        <input
                          type="text"
                          value={profileName}
                          onChange={(e) => setProfileName(e.target.value)}
                          className="flex-1 min-w-[200px] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                        />
                        <div className="flex items-center gap-1.5">
                          {AVATAR_COLORS.map((col) => (
                            <button
                              key={col}
                              type="button"
                              onClick={() => setProfileColor(col)}
                              className={`w-6 h-6 rounded-full border-2 ${
                                profileColor === col ? 'border-slate-900 dark:border-white' : 'border-transparent'
                              }`}
                              style={{ backgroundColor: col }}
                              aria-label={`Select color ${col}`}
                            />
                          ))}
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const res = await novaApi.updateProfile(profileName, profileColor);
                              onUserUpdated(res.user);
                              setStatusMsg({ type: 'ok', text: 'Profile updated.' });
                            } catch (err) {
                              setStatusMsg({
                                type: 'err',
                                text: err instanceof Error ? err.message : 'Update failed.',
                              });
                            }
                          }}
                          className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
                        >
                          Save Profile
                        </button>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-slate-200/70 dark:border-slate-800/70 space-y-3">
                      <div className="font-medium text-slate-900 dark:text-slate-100">Change Password</div>
                      <div className="grid sm:grid-cols-2 gap-2.5">
                        <input
                          type="password"
                          value={curPass}
                          onChange={(e) => setCurPass(e.target.value)}
                          placeholder="Current password"
                          className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                        />
                        <input
                          type="password"
                          value={newPass}
                          onChange={(e) => setNewPass(e.target.value)}
                          placeholder="New password (8+ chars)"
                          className="rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#181C2A] px-3 py-2 text-xs text-slate-900 dark:text-slate-100"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            await novaApi.changePassword(curPass, newPass);
                            setCurPass('');
                            setNewPass('');
                            setStatusMsg({ type: 'ok', text: 'Password updated.' });
                          } catch (err) {
                            setStatusMsg({
                              type: 'err',
                              text: err instanceof Error ? err.message : 'Failed to change password.',
                            });
                          }
                        }}
                        className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-[#181C2A] text-xs font-medium"
                      >
                        Update Password
                      </button>
                    </div>

                    <div className="pt-4 border-t border-slate-200/70 dark:border-slate-800/70 flex flex-wrap items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={async () => {
                          await novaApi.logout();
                          onUserUpdated(null);
                          onClose();
                        }}
                        className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-[#181C2A] text-xs font-medium"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        Sign out
                      </button>

                      {!confirmDeleteAccount ? (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteAccount(true)}
                          className="text-xs text-rose-600 dark:text-rose-400 hover:underline"
                        >
                          Delete account
                        </button>
                      ) : (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={async () => {
                              await novaApi.deleteAccount();
                              onUserUpdated(null);
                              onClose();
                            }}
                            className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-semibold"
                          >
                            Confirm delete account
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteAccount(false)}
                            className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-xs"
                          >
                            Cancel
                          </button>
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
