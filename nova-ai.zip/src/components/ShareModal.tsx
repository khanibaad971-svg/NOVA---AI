import { useState, useEffect } from 'react';
import { X, Copy, Check, Download, Link2, Loader2 } from 'lucide-react';
import { novaApi } from '../lib/api';
import type { Conversation } from '../types/nova';

interface ShareModalProps {
  open: boolean;
  onClose: () => void;
  conversation: Conversation | null;
  isAuthenticated: boolean;
  onExportMarkdown: () => void;
}

export function ShareModal({
  open,
  onClose,
  conversation,
  isAuthenticated,
  onExportMarkdown,
}: ShareModalProps) {
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedMd, setCopiedMd] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open || !conversation) return;
    setError(null);
    if (conversation.shareId) {
      setShareUrl(`${window.location.origin}/share/${conversation.shareId}`);
    } else {
      setShareUrl(null);
    }
  }, [open, conversation]);

  if (!open || !conversation) return null;

  const generateLink = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await novaApi.shareConversation(conversation.id);
      setShareUrl(`${window.location.origin}/share/${res.shareId}`);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Sign in to create a cloud-hosted share link, or export as Markdown.'
      );
    } finally {
      setLoading(false);
    }
  };

  const copyUrl = async () => {
    if (!shareUrl) return;
    await navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 1800);
  };

  const copyMarkdown = async () => {
    const md = (conversation.messages || [])
      .map((m) => `### ${m.role === 'user' ? 'User' : 'NOVA AI'}\n\n${m.content}`)
      .join('\n\n---\n\n');
    await navigator.clipboard.writeText(`# ${conversation.title}\n\n${md}`);
    setCopiedMd(true);
    setTimeout(() => setCopiedMd(false), 1800);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-[2px] flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#141724] shadow-2xl p-5 space-y-4"
      >
        <div className="flex items-center justify-between">
          <h3 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
            Share Conversation
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          Share a read-only snapshot of <strong className="text-slate-700 dark:text-slate-200">{conversation.title}</strong> or export it locally.
        </p>

        {error && (
          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-xs text-amber-800 dark:text-amber-200">
            {error}
          </div>
        )}

        {isAuthenticated ? (
          shareUrl ? (
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#181C2A] px-3 py-2 text-xs font-mono text-slate-700 dark:text-slate-200"
              />
              <button
                type="button"
                onClick={copyUrl}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shrink-0"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedLink ? 'Copied' : 'Copy'}
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={generateLink}
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Link2 className="w-4 h-4" />}
              <span>Create public share link</span>
            </button>
          )
        ) : (
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#181C2A] border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300">
            Sign in to generate a hosted share URL, or copy/download as Markdown below.
          </div>
        )}

        <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
          <button
            type="button"
            onClick={copyMarkdown}
            className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-[#181C2A] text-xs font-medium"
          >
            {copiedMd ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedMd ? 'Copied Markdown' : 'Copy Markdown'}</span>
          </button>
          <button
            type="button"
            onClick={onExportMarkdown}
            className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-[#181C2A] text-xs font-medium"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download .md</span>
          </button>
        </div>
      </div>
    </div>
  );
}
