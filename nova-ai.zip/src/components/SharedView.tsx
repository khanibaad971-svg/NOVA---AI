import { useEffect, useState } from 'react';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { NovaLogo } from './NovaLogo';
import { MarkdownRenderer } from './MarkdownRenderer';
import { novaApi } from '../lib/api';
import type { Conversation } from '../types/nova';

interface SharedViewProps {
  shareId: string;
  isDark: boolean;
  onBackToApp: () => void;
}

export function SharedView({ shareId, isDark, onBackToApp }: SharedViewProps) {
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    novaApi
      .getSharedConversation(shareId)
      .then((res) => setConversation(res.conversation))
      .catch((err) => setError(err instanceof Error ? err.message : 'Shared conversation not found.'))
      .finally(() => setLoading(false));
  }, [shareId]);

  return (
    <div className="min-h-screen flex flex-col bg-[#FCFCFD] dark:bg-[#0B0D13] text-slate-900 dark:text-slate-100">
      <header className="h-14 flex items-center justify-between px-4 sm:px-8 border-b border-slate-200 dark:border-slate-800">
        <NovaLogo size={26} />
        <button
          type="button"
          onClick={onBackToApp}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Open NOVA AI
        </button>
      </header>

      <main className="flex-1 w-full max-w-3xl mx-auto px-4 py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20 text-sm text-slate-500 gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
            <span>Loading shared conversation...</span>
          </div>
        ) : error || !conversation ? (
          <div className="text-center py-20 space-y-3">
            <p className="text-base font-semibold">{error || 'Conversation unavailable.'}</p>
            <button
              type="button"
              onClick={onBackToApp}
              className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
            >
              Go to NOVA AI
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
              <h1 className="font-display text-2xl font-bold">{conversation.title}</h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Shared NOVA AI conversation · {new Date(conversation.createdAt).toLocaleDateString()}
              </p>
            </div>

            <div className="space-y-6">
              {(conversation.messages || []).map((m) => (
                <div key={m.id} className={m.role === 'user' ? 'flex justify-end' : ''}>
                  {m.role === 'user' ? (
                    <div className="max-w-[82%] rounded-2xl rounded-tr-sm px-4 py-2.5 bg-indigo-50 dark:bg-[#1C2135] border border-indigo-100 dark:border-indigo-500/20 text-sm whitespace-pre-wrap">
                      {m.content}
                    </div>
                  ) : (
                    <MarkdownRenderer content={m.content} charts={m.charts} isDark={isDark} />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
