import { useState, useMemo, useRef, useEffect } from 'react';
import {
  Plus,
  Search,
  PanelLeftClose,
  Pin,
  PinOff,
  Pencil,
  Trash2,
  Share2,
  MoreHorizontal,
  Settings,
  LogIn,
  Check,
  X,
  MessageSquare,
} from 'lucide-react';
import { NovaLogo } from './NovaLogo';
import type { Conversation, UserProfile } from '../types/nova';

interface SidebarProps {
  open: boolean;
  onCloseMobile: () => void;
  onCollapseDesktop: () => void;
  conversations: Conversation[];
  activeId: string | null;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onRenameConversation: (id: string, title: string) => void;
  onTogglePin: (id: string, pinned: boolean) => void;
  onDeleteConversation: (id: string) => void;
  onShareConversation: (id: string) => void;
  user: UserProfile | null;
  onOpenSettings: () => void;
  onOpenAuth: () => void;
}

interface GroupedConversations {
  pinned: Conversation[];
  today: Conversation[];
  yesterday: Conversation[];
  prev7: Conversation[];
  prev30: Conversation[];
  older: Conversation[];
}

function groupConversations(list: Conversation[]): GroupedConversations {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const oneDay = 24 * 60 * 60 * 1000;
  const startOfYesterday = startOfToday - oneDay;
  const sevenDaysAgo = startOfToday - 7 * oneDay;
  const thirtyDaysAgo = startOfToday - 30 * oneDay;

  const groups: GroupedConversations = {
    pinned: [],
    today: [],
    yesterday: [],
    prev7: [],
    prev30: [],
    older: [],
  };

  for (const conv of list) {
    if (conv.pinned) {
      groups.pinned.push(conv);
      continue;
    }
    const ts = new Date(conv.updatedAt || conv.createdAt).getTime();
    if (ts >= startOfToday) groups.today.push(conv);
    else if (ts >= startOfYesterday) groups.yesterday.push(conv);
    else if (ts >= sevenDaysAgo) groups.prev7.push(conv);
    else if (ts >= thirtyDaysAgo) groups.prev30.push(conv);
    else groups.older.push(conv);
  }

  return groups;
}

export function Sidebar({
  open,
  onCloseMobile,
  onCollapseDesktop,
  conversations,
  activeId,
  searchQuery,
  onSearchChange,
  onSelectConversation,
  onNewChat,
  onRenameConversation,
  onTogglePin,
  onDeleteConversation,
  onShareConversation,
  user,
  onOpenSettings,
  onOpenAuth,
}: SidebarProps) {
  const [menuOpenId, setMenuOpenId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const editInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingId) {
      editInputRef.current?.focus();
      editInputRef.current?.select();
    }
  }, [editingId]);

  useEffect(() => {
    const closeMenu = () => setMenuOpenId(null);
    window.addEventListener('click', closeMenu);
    return () => window.removeEventListener('click', closeMenu);
  }, []);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return conversations;
    return conversations.filter((c) => {
      if (c.title.toLowerCase().includes(q)) return true;
      return (c.messages || []).some((m) => m.content.toLowerCase().includes(q));
    });
  }, [conversations, searchQuery]);

  const grouped = useMemo(() => groupConversations(filtered), [filtered]);

  const startRename = (c: Conversation) => {
    setEditingId(c.id);
    setEditingTitle(c.title);
    setMenuOpenId(null);
  };

  const commitRename = (id: string) => {
    const trimmed = editingTitle.trim();
    if (trimmed) {
      onRenameConversation(id, trimmed);
    }
    setEditingId(null);
  };

  const renderGroup = (label: string, items: Conversation[]) => {
    if (items.length === 0) return null;
    return (
      <div className="mb-4">
        <div className="px-3 pb-1.5 text-[11px] font-semibold tracking-wide text-slate-500 dark:text-slate-400">
          {label}
        </div>
        <div className="space-y-0.5">
          {items.map((c) => {
            const isActive = c.id === activeId;
            const isEditing = editingId === c.id;
            const isDeleting = confirmDeleteId === c.id;

            return (
              <div
                key={c.id}
                className={`group relative flex items-center rounded-lg transition-colors ${
                  isActive
                    ? 'bg-indigo-50 dark:bg-[#1E2336] text-slate-900 dark:text-white'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-[#1A1E2E]'
                }`}
              >
                {isEditing ? (
                  <div className="flex items-center gap-1 w-full px-2 py-1.5">
                    <input
                      ref={editInputRef}
                      type="text"
                      value={editingTitle}
                      onChange={(e) => setEditingTitle(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') commitRename(c.id);
                        if (e.key === 'Escape') setEditingId(null);
                      }}
                      className="flex-1 min-w-0 bg-white dark:bg-[#0F111A] border border-indigo-500 rounded-md px-2 py-1 text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => commitRename(c.id)}
                      className="p-1 text-emerald-600 dark:text-emerald-400 hover:bg-slate-200/70 dark:hover:bg-slate-700 rounded"
                      aria-label="Save title"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingId(null)}
                      className="p-1 text-slate-500 hover:bg-slate-200/70 dark:hover:bg-slate-700 rounded"
                      aria-label="Cancel rename"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : isDeleting ? (
                  <div className="flex items-center justify-between gap-2 w-full px-3 py-2 text-xs bg-rose-50 dark:bg-rose-950/40 rounded-lg border border-rose-200 dark:border-rose-800/60">
                    <span className="truncate font-medium text-rose-700 dark:text-rose-300">
                      Delete chat?
                    </span>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          onDeleteConversation(c.id);
                          setConfirmDeleteId(null);
                        }}
                        className="px-2 py-0.5 rounded bg-rose-600 text-white hover:bg-rose-700 font-medium"
                      >
                        Delete
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(null)}
                        className="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        onSelectConversation(c.id);
                        onCloseMobile();
                      }}
                      className="flex-1 min-w-0 flex items-center gap-2 px-3 py-2 text-left text-[13.5px] font-medium truncate"
                    >
                      {c.pinned && (
                        <Pin className="w-3.5 h-3.5 shrink-0 text-indigo-600 dark:text-indigo-400" />
                      )}
                      <span className="truncate">{c.title}</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuOpenId(menuOpenId === c.id ? null : c.id);
                      }}
                      className={`p-1.5 mr-1 rounded-md text-slate-500 hover:text-slate-900 dark:hover:text-white transition-opacity ${
                        isActive || menuOpenId === c.id
                          ? 'opacity-100'
                          : 'opacity-0 group-hover:opacity-100 focus:opacity-100'
                      }`}
                      aria-label="Conversation options"
                    >
                      <MoreHorizontal className="w-4 h-4" />
                    </button>

                    {menuOpenId === c.id && (
                      <div
                        onClick={(e) => e.stopPropagation()}
                        className="absolute right-1 top-9 z-40 w-44 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-[#1A1E2E] shadow-lg py-1 text-xs"
                      >
                        <button
                          type="button"
                          onClick={() => {
                            onTogglePin(c.id, !c.pinned);
                            setMenuOpenId(null);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          {c.pinned ? <PinOff className="w-3.5 h-3.5" /> : <Pin className="w-3.5 h-3.5" />}
                          <span>{c.pinned ? 'Unpin' : 'Pin conversation'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => startRename(c)}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                          <span>Rename</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onShareConversation(c.id);
                            setMenuOpenId(null);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                          <span>Share link</span>
                        </button>
                        <div className="my-1 border-t border-slate-200 dark:border-slate-700/70" />
                        <button
                          type="button"
                          onClick={() => {
                            setConfirmDeleteId(c.id);
                            setMenuOpenId(null);
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const initials = user
    ? user.name
        .split(' ')
        .map((n) => n[0])
        .slice(0, 2)
        .join('')
        .toUpperCase()
    : 'G';

  return (
    <>
      {/* Mobile backdrop */}
      {open && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-30 bg-slate-950/50 backdrop-blur-[1px] md:hidden"
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 flex flex-col w-[268px] shrink-0 bg-[#F4F5F8] dark:bg-[#131622] border-r border-slate-200/80 dark:border-slate-800/80 transition-all duration-200 ease-out ${
          open ? 'translate-x-0 md:ml-0' : '-translate-x-full md:translate-x-0 md:-ml-[268px]'
        }`}
      >
        {/* Top Row */}
        <div className="flex items-center justify-between px-3.5 pt-3.5 pb-2.5">
          <button
            type="button"
            onClick={() => {
              onNewChat();
              onCloseMobile();
            }}
            className="focus:outline-none rounded-lg"
            aria-label="NOVA AI Home"
          >
            <NovaLogo size={26} />
          </button>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onCollapseDesktop}
              className="hidden md:inline-flex p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors"
              title="Collapse sidebar"
              aria-label="Collapse sidebar"
            >
              <PanelLeftClose className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onCloseMobile}
              className="md:hidden p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800"
              aria-label="Close sidebar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* New Chat + Search */}
        <div className="px-3 space-y-2 pb-3">
          <button
            type="button"
            onClick={() => {
              onNewChat();
              onCloseMobile();
            }}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-white dark:bg-[#1A1E2E] border border-slate-200/90 dark:border-slate-700/70 text-sm font-medium text-slate-800 dark:text-slate-100 hover:border-indigo-400 dark:hover:border-indigo-500/70 shadow-2xs transition-colors"
          >
            <span className="flex items-center gap-2.5">
              <Plus className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>New chat</span>
            </span>
          </button>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search conversations..."
              aria-label="Search conversations"
              className="w-full pl-8 pr-7 py-2 rounded-xl bg-slate-200/60 dark:bg-[#1A1E2E]/80 border border-transparent focus:border-indigo-500/60 focus:bg-white dark:focus:bg-[#1A1E2E] text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                aria-label="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto px-2 pb-3">
          {filtered.length === 0 ? (
            <div className="px-3 py-8 text-center">
              <MessageSquare className="w-6 h-6 mx-auto mb-2 text-slate-400 opacity-70" />
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {searchQuery ? 'No matching conversations.' : 'Your conversations will appear here.'}
              </p>
            </div>
          ) : (
            <>
              {renderGroup('Pinned', grouped.pinned)}
              {renderGroup('Today', grouped.today)}
              {renderGroup('Yesterday', grouped.yesterday)}
              {renderGroup('Previous 7 Days', grouped.prev7)}
              {renderGroup('Previous 30 Days', grouped.prev30)}
              {renderGroup('Older', grouped.older)}
            </>
          )}
        </div>

        {/* User Profile & Settings Footer */}
        <div className="p-2.5 border-t border-slate-200/80 dark:border-slate-800/80 bg-[#F4F5F8] dark:bg-[#131622]">
          <div className="flex items-center gap-2">
            {user ? (
              <button
                type="button"
                onClick={onOpenSettings}
                className="flex-1 min-w-0 flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-200/60 dark:hover:bg-[#1A1E2E] transition-colors text-left"
              >
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0"
                  style={{ backgroundColor: user.avatarColor || '#4F46E5' }}
                >
                  {initials}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {user.name}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {user.email}
                  </div>
                </div>
              </button>
            ) : (
              <button
                type="button"
                onClick={onOpenAuth}
                className="flex-1 flex items-center gap-2.5 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors"
              >
                <LogIn className="w-4 h-4 shrink-0" />
                <span className="truncate">Sign in to sync chats</span>
              </button>
            )}

            <button
              type="button"
              onClick={onOpenSettings}
              className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-[#1A1E2E] transition-colors shrink-0"
              title="Settings"
              aria-label="Open Settings"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
