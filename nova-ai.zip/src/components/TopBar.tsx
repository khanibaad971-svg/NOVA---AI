import { useState, useEffect, useRef } from 'react';
import {
  PanelLeft,
  ChevronDown,
  Share2,
  MoreHorizontal,
  Settings,
  Sun,
  Moon,
  Monitor,
  Pin,
  Pencil,
  Download,
  Trash2,
  Check,
  KeyRound,
  Plus,
} from 'lucide-react';
import { NovaLogo } from './NovaLogo';
import type { AIModelInfo, Conversation, ThemeMode } from '../types/nova';

interface TopBarProps {
  sidebarOpen: boolean;
  onToggleSidebar: () => void;
  models: AIModelInfo[];
  selectedModel: string;
  onSelectModel: (modelId: string) => void;
  activeConversation: Conversation | null;
  onNewChat: () => void;
  onShare: () => void;
  onTogglePin: () => void;
  onRenamePrompt: () => void;
  onExportMarkdown: () => void;
  onDeleteConversation: () => void;
  theme: ThemeMode;
  onCycleTheme: () => void;
  onOpenSettings: (tab?: string) => void;
}

export function TopBar({
  sidebarOpen,
  onToggleSidebar,
  models,
  selectedModel,
  onSelectModel,
  activeConversation,
  onNewChat,
  onShare,
  onTogglePin,
  onRenamePrompt,
  onExportMarkdown,
  onDeleteConversation,
  theme,
  onCycleTheme,
  onOpenSettings,
}: TopBarProps) {
  const [modelOpen, setModelOpen] = useState(false);
  const [optionsOpen, setOptionsOpen] = useState(false);
  const modelRef = useRef<HTMLDivElement>(null);
  const optionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (modelRef.current && !modelRef.current.contains(e.target as Node)) {
        setModelOpen(false);
      }
      if (optionsRef.current && !optionsRef.current.contains(e.target as Node)) {
        setOptionsOpen(false);
      }
    };
    window.addEventListener('mousedown', handleClick);
    return () => window.removeEventListener('mousedown', handleClick);
  }, []);

  const currentModel = models.find((m) => m.id === selectedModel) || models[0];
  const groqModels = models.filter((m) => m.provider === 'groq');
  const novaModels = models.filter((m) => m.provider === 'gemini');

  return (
    <header className="h-14 shrink-0 flex items-center justify-between gap-4 px-3 sm:px-5 border-b border-slate-200/70 dark:border-slate-800/70 bg-[#FCFCFD]/90 dark:bg-[#0B0D13]/90 backdrop-blur-sm z-20">
      {/* Left: Sidebar toggle + Brand (when collapsed) + Model Selector */}
      <div className="flex items-center gap-2 min-w-0">
        {!sidebarOpen && (
          <button
            type="button"
            onClick={onToggleSidebar}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors shrink-0"
            title="Open sidebar"
            aria-label="Open sidebar"
          >
            <PanelLeft className="w-4 h-4" />
          </button>
        )}

        <button
          type="button"
          onClick={onToggleSidebar}
          className="md:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors shrink-0"
          aria-label="Open menu"
        >
          <PanelLeft className="w-4 h-4" />
        </button>

        {!sidebarOpen && (
          <button
            type="button"
            onClick={onNewChat}
            className="hidden sm:inline-flex items-center mr-1"
            title="New chat"
          >
            <NovaLogo size={24} />
          </button>
        )}

        {/* Model Selector Dropdown */}
        <div ref={modelRef} className="relative">
          <button
            type="button"
            onClick={() => setModelOpen((o) => !o)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-[#161A29] text-sm font-semibold text-slate-900 dark:text-slate-100 transition-colors whitespace-nowrap shrink-0"
          >
            <span className="truncate max-w-[170px] sm:max-w-[240px]">
              {currentModel?.name || 'NOVA Core'}
            </span>
            <span className="hidden sm:inline text-xs font-normal text-slate-500 dark:text-slate-400">
              {currentModel?.providerLabel}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </button>

          {modelOpen && (
            <div className="absolute left-0 top-11 w-[320px] sm:w-[360px] max-h-[75vh] overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-[#151926] shadow-xl p-2 z-50">
              <div className="px-2.5 py-1.5 text-[11px] font-semibold tracking-wide text-slate-500 dark:text-slate-400">
                NOVA Engine
              </div>
              {novaModels.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    onSelectModel(m.id);
                    setModelOpen(false);
                  }}
                  className={`w-full flex items-start justify-between gap-3 p-2.5 rounded-xl text-left transition-colors ${
                    selectedModel === m.id
                      ? 'bg-indigo-50 dark:bg-indigo-950/50'
                      : 'hover:bg-slate-100 dark:hover:bg-[#1C2133]'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
                      <span>{m.name}</span>
                      <span className="text-[11px] font-normal text-slate-500 dark:text-slate-400">
                        {m.contextWindow} · Vision · Search
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">
                      {m.description}
                    </p>
                  </div>
                  {selectedModel === m.id && (
                    <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
                  )}
                </button>
              ))}

              <div className="mt-2 pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between px-2.5 py-1.5">
                <span className="text-[11px] font-semibold tracking-wide text-slate-500 dark:text-slate-400">
                  Groq LPU Models
                </span>
                {groqModels.some((m) => !m.available) && (
                  <button
                    type="button"
                    onClick={() => {
                      setModelOpen(false);
                      onOpenSettings('providers');
                    }}
                    className="inline-flex items-center gap-1 text-[11px] font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
                  >
                    <KeyRound className="w-3 h-3" />
                    Configure Groq key
                  </button>
                )}
              </div>

              <div className="space-y-0.5">
                {groqModels.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      if (!m.available) {
                        setModelOpen(false);
                        onOpenSettings('providers');
                        return;
                      }
                      onSelectModel(m.id);
                      setModelOpen(false);
                    }}
                    className={`w-full flex items-start justify-between gap-3 p-2.5 rounded-xl text-left transition-colors ${
                      selectedModel === m.id
                        ? 'bg-indigo-50 dark:bg-indigo-950/50'
                        : 'hover:bg-slate-100 dark:hover:bg-[#1C2133]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
                        <span className={!m.available ? 'opacity-70' : ''}>{m.name}</span>
                        <span className="text-[11px] font-normal text-slate-500 dark:text-slate-400">
                          {m.contextWindow}
                          {m.supportsVision ? ' · Vision' : ''}
                          {!m.available ? ' · Needs API key' : ''}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">
                        {m.description}
                      </p>
                    </div>
                    {selectedModel === m.id && (
                      <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1.5 shrink-0">
        {!sidebarOpen && (
          <button
            type="button"
            onClick={onNewChat}
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New chat</span>
          </button>
        )}

        {activeConversation && (activeConversation.messages?.length ?? 0) > 0 && (
          <>
            <button
              type="button"
              onClick={onShare}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700/80 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#161A29] transition-colors whitespace-nowrap"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Share</span>
            </button>

            <div ref={optionsRef} className="relative">
              <button
                type="button"
                onClick={() => setOptionsOpen((o) => !o)}
                className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#161A29] transition-colors"
                aria-label="More conversation options"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>

              {optionsOpen && (
                <div className="absolute right-0 top-10 w-48 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-[#151926] shadow-xl py-1 text-xs z-50">
                  <button
                    type="button"
                    onClick={() => {
                      onTogglePin();
                      setOptionsOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <Pin className="w-3.5 h-3.5" />
                    <span>{activeConversation.pinned ? 'Unpin conversation' : 'Pin conversation'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onRenamePrompt();
                      setOptionsOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    <span>Rename conversation</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onExportMarkdown();
                      setOptionsOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export as Markdown</span>
                  </button>
                  <div className="my-1 border-t border-slate-200 dark:border-slate-700/70" />
                  <button
                    type="button"
                    onClick={() => {
                      onDeleteConversation();
                      setOptionsOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete conversation</span>
                  </button>
                </div>
              )}
            </div>
          </>
        )}

        <button
          type="button"
          onClick={onCycleTheme}
          className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#161A29] transition-colors"
          title={`Theme: ${theme}`}
          aria-label={`Switch theme (current: ${theme})`}
        >
          {theme === 'light' ? (
            <Sun className="w-4 h-4" />
          ) : theme === 'dark' ? (
            <Moon className="w-4 h-4" />
          ) : (
            <Monitor className="w-4 h-4" />
          )}
        </button>

        <button
          type="button"
          onClick={() => onOpenSettings('general')}
          className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#161A29] transition-colors"
          title="Settings"
          aria-label="Open Settings"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
}
