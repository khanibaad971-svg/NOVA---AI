import type {
  AIModelInfo,
  Attachment,
  Conversation,
  MemoryItem,
  ProviderStatus,
  ToolId,
  UsageSummary,
  UserProfile,
  UserSettings,
} from '../types/nova';

const TOKEN_STORAGE_KEY = 'nova_auth_token';
const GUEST_CONVS_KEY = 'nova_guest_conversations';
const GUEST_SETTINGS_KEY = 'nova_guest_settings';
const GUEST_MEMORIES_KEY = 'nova_guest_memories';
export const THEME_STORAGE_KEY = 'nova_theme';

export const DEFAULT_SETTINGS: UserSettings = {
  theme: 'system',
  language: 'English',
  defaultModel: 'auto',
  customInstructionsAbout: '',
  customInstructionsStyle: '',
  memoryEnabled: true,
  enterToSend: true,
  fontSize: 'standard',
  voiceLang: 'en-US',
  ttsVoice: '',
  ttsRate: 1.0,
  ttsAutoPlay: false,
};

export function getAuthToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setAuthToken(token: string | null): void {
  try {
    if (token) localStorage.setItem(TOKEN_STORAGE_KEY, token);
    else localStorage.removeItem(TOKEN_STORAGE_KEY);
  } catch {
    // ignore storage quota errors
  }
}

export async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers = new Headers(options.headers || {});
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  if (!(options.body instanceof FormData) && options.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  const contentType = res.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await res.json() : await res.text();

  if (!res.ok) {
    const errMsg =
      typeof data === 'object' && data && 'error' in data
        ? String((data as { error: string }).error)
        : `Request failed (${res.status})`;
    const err = new Error(errMsg) as Error & { code?: string; status?: number };
    if (typeof data === 'object' && data && 'code' in data) {
      err.code = String((data as { code: string }).code);
    }
    err.status = res.status;
    throw err;
  }

  return data as T;
}

// Guest localStorage fallbacks
export function loadGuestConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem(GUEST_CONVS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveGuestConversations(convs: Conversation[]): void {
  try {
    // Strip huge base64 image dataUrls if nearing quota by keeping recent ones
    localStorage.setItem(GUEST_CONVS_KEY, JSON.stringify(convs));
  } catch {
    try {
      const trimmed = convs.slice(0, 15).map((c) => ({
        ...c,
        messages: (c.messages || []).map((m) => ({
          ...m,
          attachments: m.attachments?.map((a) => ({
            ...a,
            dataUrl: a.dataUrl && a.dataUrl.length > 200000 ? undefined : a.dataUrl,
          })),
        })),
      }));
      localStorage.setItem(GUEST_CONVS_KEY, JSON.stringify(trimmed));
    } catch {
      // ignore if still full
    }
  }
}

export function loadGuestSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(GUEST_SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS, theme: (localStorage.getItem(THEME_STORAGE_KEY) as UserSettings['theme']) || 'system' };
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveGuestSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(GUEST_SETTINGS_KEY, JSON.stringify(settings));
    localStorage.setItem(THEME_STORAGE_KEY, settings.theme);
  } catch {
    // ignore
  }
}

export function loadGuestMemories(): MemoryItem[] {
  try {
    const raw = localStorage.getItem(GUEST_MEMORIES_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveGuestMemories(memories: MemoryItem[]): void {
  try {
    localStorage.setItem(GUEST_MEMORIES_KEY, JSON.stringify(memories));
  } catch {
    // ignore
  }
}

// High-level API helpers
export const novaApi = {
  getModels: () => apiFetch<{ models: AIModelInfo[]; defaultModel: string }>('/api/models'),
  getMe: () => apiFetch<{ user: UserProfile | null }>('/api/auth/me'),
  getAuthProviders: () => apiFetch<{ google: boolean }>('/api/auth/providers'),
  signup: (name: string, email: string, password: string) =>
    apiFetch<{ user: UserProfile; token: string }>('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    }),
  login: (email: string, password: string) =>
    apiFetch<{ user: UserProfile; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  logout: () => apiFetch<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),
  updateProfile: (name: string, avatarColor: string) =>
    apiFetch<{ user: UserProfile }>('/api/auth/profile', {
      method: 'PATCH',
      body: JSON.stringify({ name, avatarColor }),
    }),
  changePassword: (currentPassword: string, newPassword: string) =>
    apiFetch<{ ok: boolean }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword }),
    }),
  forgotPassword: (email: string) =>
    apiFetch<{ ok: boolean; message: string; resetCode?: string }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),
  resetPassword: (code: string, newPassword: string) =>
    apiFetch<{ ok: boolean }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ code, newPassword }),
    }),
  deleteAccount: () => apiFetch<{ ok: boolean }>('/api/auth/account', { method: 'DELETE' }),

  listConversations: (q = '') =>
    apiFetch<{ conversations: Conversation[] }>(`/api/conversations${q ? `?q=${encodeURIComponent(q)}` : ''}`),
  getConversation: (id: string) =>
    apiFetch<{ conversation: Conversation }>(`/api/conversations/${encodeURIComponent(id)}`),
  createConversation: (title: string, model: string) =>
    apiFetch<{ conversation: Conversation }>('/api/conversations', {
      method: 'POST',
      body: JSON.stringify({ title, model }),
    }),
  updateConversation: (id: string, patch: { title?: string; pinned?: boolean; model?: string }) =>
    apiFetch<{ ok: boolean }>(`/api/conversations/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }),
  deleteConversation: (id: string) =>
    apiFetch<{ ok: boolean }>(`/api/conversations/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  clearConversations: () => apiFetch<{ ok: boolean }>('/api/conversations', { method: 'DELETE' }),
  shareConversation: (id: string) =>
    apiFetch<{ shareId: string }>(`/api/conversations/${encodeURIComponent(id)}/share`, { method: 'POST' }),
  getSharedConversation: (shareId: string) =>
    apiFetch<{ conversation: Conversation }>(`/api/share/${encodeURIComponent(shareId)}`),
  exportConversations: () =>
    apiFetch<{ exportedAt: string; conversations: Conversation[] }>('/api/conversations/export'),
  importConversations: (conversations: Conversation[]) =>
    apiFetch<{ ok: boolean; importedCount: number }>('/api/conversations/import', {
      method: 'POST',
      body: JSON.stringify({ conversations }),
    }),
  setFeedback: (messageId: string, feedback: 'up' | 'down' | null) =>
    apiFetch<{ ok: boolean }>(`/api/messages/${encodeURIComponent(messageId)}/feedback`, {
      method: 'PATCH',
      body: JSON.stringify({ feedback }),
    }),

  getSettings: () => apiFetch<{ settings: UserSettings }>('/api/settings'),
  saveSettings: (settings: Partial<UserSettings>) =>
    apiFetch<{ settings: UserSettings }>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    }),

  getMemories: () => apiFetch<{ memories: MemoryItem[] }>('/api/memories'),
  addMemory: (content: string) =>
    apiFetch<{ memory: MemoryItem }>('/api/memories', {
      method: 'POST',
      body: JSON.stringify({ content }),
    }),
  deleteMemory: (id: string) =>
    apiFetch<{ ok: boolean }>(`/api/memories/${encodeURIComponent(id)}`, { method: 'DELETE' }),

  getProviders: () => apiFetch<{ providers: ProviderStatus[] }>('/api/admin/providers'),
  updateProvider: (
    providerId: string,
    payload: {
      apiKey?: string;
      clearKey?: boolean;
      baseUrl?: string;
      enabled?: boolean;
      imageModel?: string;
      customModels?: Array<{ id: string; name: string; contextWindow?: string; supportsVision?: boolean }>;
    }
  ) =>
    apiFetch<{ providers: ProviderStatus[]; models: AIModelInfo[] }>(
      `/api/admin/providers/${encodeURIComponent(providerId)}`,
      { method: 'PUT', body: JSON.stringify(payload) }
    ),
  testGroq: (apiKey?: string, baseUrl?: string) =>
    apiFetch<{ ok: boolean; modelsCount?: number; error?: string }>('/api/admin/providers/groq/test', {
      method: 'POST',
      body: JSON.stringify({ apiKey, baseUrl }),
    }),
  getUsage: () => apiFetch<UsageSummary>('/api/usage'),

  uploadFiles: async (files: File[]): Promise<Attachment[]> => {
    const form = new FormData();
    for (const f of files) form.append('files', f);
    const res = await apiFetch<{ attachments: Attachment[] }>('/api/upload', {
      method: 'POST',
      body: form,
    });
    return res.attachments;
  },

  generateImage: (prompt: string) =>
    apiFetch<{ image: { url: string; prompt: string; provider: string } }>('/api/tools/generate-image', {
      method: 'POST',
      body: JSON.stringify({ prompt }),
    }),
};

export interface StreamHandlers {
  onConversation?: (conv: { id: string; title: string; isNew: boolean }) => void;
  onMeta?: (meta: {
    conversationId: string;
    userMessageId: string;
    assistantMessageId: string;
    model: string;
    tool: ToolId;
  }) => void;
  onToken: (text: string) => void;
  onSources?: (sources: Array<{ title: string; uri: string }>) => void;
  onCharts?: (charts: any[]) => void;
  onDone?: (payload: {
    assistantMessageId: string;
    actualModel: string;
    provider: string;
    aborted?: boolean;
  }) => void;
  onError: (message: string) => void;
}

export async function streamChat(
  body: Record<string, unknown>,
  signal: AbortSignal,
  handlers: StreamHandlers
): Promise<void> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (token) headers.Authorization = `Bearer ${token}`;

  let response: Response;
  try {
    response = await fetch('/api/chat/stream', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify(body),
      signal,
    });
  } catch (err) {
    if (signal.aborted || (err instanceof Error && err.name === 'AbortError')) {
      handlers.onDone?.({ assistantMessageId: '', actualModel: '', provider: '', aborted: true });
      return;
    }
    handlers.onError(err instanceof Error ? err.message : 'Network error connecting to NOVA AI server.');
    return;
  }

  if (!response.ok) {
    const errText = await response.text().catch(() => '');
    let msg = `Request failed (${response.status})`;
    try {
      const parsed = JSON.parse(errText);
      msg = parsed.error || msg;
    } catch {
      if (errText) msg = errText;
    }
    handlers.onError(msg);
    return;
  }

  if (!response.body) {
    handlers.onError('Stream response unavailable.');
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';

  const dispatchEvent = (eventName: string, rawData: string) => {
    try {
      const data = JSON.parse(rawData);
      switch (eventName) {
        case 'conversation':
          handlers.onConversation?.(data);
          break;
        case 'meta':
          handlers.onMeta?.(data);
          break;
        case 'token':
          if (typeof data.text === 'string') handlers.onToken(data.text);
          break;
        case 'sources':
          if (Array.isArray(data.sources)) handlers.onSources?.(data.sources);
          break;
        case 'charts':
          if (Array.isArray(data.charts)) handlers.onCharts?.(data.charts);
          break;
        case 'done':
          handlers.onDone?.(data);
          break;
        case 'error':
          handlers.onError(data.error || 'Stream error occurred.');
          break;
      }
    } catch {
      // ignore partial payload
    }
  };

  const processBlock = (block: string) => {
    let eventName = 'message';
    const dataLines: string[] = [];
    for (const line of block.split(/\r?\n/)) {
      if (line.startsWith('event:')) {
        eventName = line.slice(6).trim();
      } else if (line.startsWith('data:')) {
        dataLines.push(line.slice(5).trim());
      }
    }
    if (dataLines.length > 0) {
      dispatchEvent(eventName, dataLines.join('\n'));
    }
  };

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const blocks = buffer.split(/\r?\n\r?\n/);
      buffer = blocks.pop() ?? '';

      for (const block of blocks) {
        if (block.trim()) processBlock(block);
      }
    }

    buffer += decoder.decode();
    if (buffer.trim()) {
      for (const block of buffer.split(/\r?\n\r?\n/)) {
        if (block.trim()) processBlock(block);
      }
    }
  } catch (err) {
    if (signal.aborted || (err instanceof Error && err.name === 'AbortError')) {
      handlers.onDone?.({ assistantMessageId: '', actualModel: '', provider: '', aborted: true });
      return;
    }
    handlers.onError(err instanceof Error ? err.message : 'Connection interrupted while streaming.');
  }
}
