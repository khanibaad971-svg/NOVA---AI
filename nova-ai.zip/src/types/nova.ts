export type ThemeMode = 'light' | 'dark' | 'system';

export type ProviderId = 'groq' | 'gemini';

export type ToolId =
  | 'none'
  | 'web-search'
  | 'image-gen'
  | 'data-analysis'
  | 'code-assistant'
  | 'document-assistant';

export interface AIModelInfo {
  id: string;
  name: string;
  provider: ProviderId;
  providerLabel: string;
  description: string;
  contextWindow: string;
  supportsVision: boolean;
  supportsSearch: boolean;
  available: boolean;
  requiresKey?: boolean;
  isCustom?: boolean;
}

export interface Attachment {
  id: string;
  name: string;
  mimeType: string;
  size: number;
  kind: 'image' | 'document' | 'data';
  extractedText?: string;
  dataUrl?: string; // for images
  csvSummary?: {
    headers: string[];
    rowCount: number;
    numericStats: Array<{
      column: string;
      min: number;
      max: number;
      mean: number;
      sum: number;
    }>;
    sampleRows: Record<string, unknown>[];
  };
  pageCount?: number;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ChartSpec {
  title: string;
  type: 'bar' | 'line' | 'area' | 'pie';
  xKey: string;
  yKeys: string[];
  data: Array<Record<string, string | number>>;
}

export interface GeneratedImage {
  url: string;
  prompt: string;
  provider: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  model?: string;
  toolUsed?: ToolId;
  attachments?: Attachment[];
  sources?: GroundingSource[];
  charts?: ChartSpec[];
  generatedImages?: GeneratedImage[];
  feedback?: 'up' | 'down' | null;
  createdAt: string;
  isStreaming?: boolean;
  error?: string;
}

export interface Conversation {
  id: string;
  title: string;
  model: string;
  pinned: boolean;
  shareId?: string | null;
  createdAt: string;
  updatedAt: string;
  messages?: ChatMessage[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  avatarColor: string;
  createdAt: string;
}

export interface UserSettings {
  theme: ThemeMode;
  language: string;
  defaultModel: string;
  customInstructionsAbout: string;
  customInstructionsStyle: string;
  memoryEnabled: boolean;
  enterToSend: boolean;
  fontSize: 'compact' | 'standard' | 'comfortable';
  voiceLang: string;
  ttsVoice: string;
  ttsRate: number;
  ttsAutoPlay: boolean;
}

export interface MemoryItem {
  id: string;
  content: string;
  createdAt: string;
}

export interface ProviderStatus {
  providerId: string;
  label: string;
  configured: boolean;
  maskedKey: string | null;
  baseUrl: string;
  enabled: boolean;
  source: 'env' | 'database' | 'none';
  customModels: Array<{ id: string; name: string; contextWindow?: string; supportsVision?: boolean }>;
  imageModel?: string;
}

export interface UsageSummary {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  avgLatencyMs: number;
  byModel: Array<{ model: string; count: number; avgLatencyMs: number }>;
  recent: Array<{
    id: string;
    provider: string;
    model: string;
    latencyMs: number;
    status: string;
    createdAt: string;
  }>;
}
